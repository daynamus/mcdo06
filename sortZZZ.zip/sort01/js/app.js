var app = angular.module('zap', []);

app.controller('MainCtrl', function($scope, $filter) {
  $scope.name = 'World';
  $scope.flag = false;
  $scope.search = {
    language: {},
    business_unit: {}
  };
  $scope.languages = [{
    name: 'PH',
    _id: 0
  }, {
    name: 'CA',
    _id: 1
  }, {
    name: 'NA',
    _id: 2
  }];
  
  $scope.bu = [{
    name: 'GAME',
    _id: 1
  }, {
    name: 'BUSINESS',
    _id: 2
  }, {
    name: 'SPORT',
    _id: 5
  }];




  $scope.array = [ 
    {
    
      "author": "Michail",
      "title": "Alphabet's Q4 report shows slower than expected growth - GSMArena.com news - GSMArena.com",
      "description": "YouTube and Cloud revenues were lower than estimated.",
      "url": "https://www.gsmarena.com/alphabet_q4_report_shows_slower_than_expected_growth-news-41356.php",
      "urlToImage": "https://fdn.gsmarena.com/imgroot/news/20/02/alphabet-q4-2019-earnings-report/-476x249w4/gsmarena_002.jpg",
      "publishedAt": "2020-02-04T10:04:02Z",
      "content": "Googles parent company Alphabet put out its Q4 and 2019 fiscal year earnings report and the numbers show a slowdown in revenue growth despite an 18% jump in total revenues on a per-year basis. Revenue growth in the October-December period on the other hand w… [+1378 chars]",

      "datetime": 1580810642000
        "source": {
          "id": null,
          "name": "Gsmarena.com",
          "country": "PH",
          "category": "GAME"
      },
  }, {
      "source": {
          "id": null,
          "name": "Youtube.com",
          "country": "CA",
          "category": "BUSINESS"
      },
      "author": null,
      "title": "Korean fast-fashion brand Forever 21 finds new owner in 4 months after filing for bankruptcy - KOREA NOW",
      "description": "You can watch this video at https://koreanow.com Korea’s fast-fashion emporium, Forever 21 has found a new owner in just four months after it filed for bankr...",
      "url": "https://www.youtube.com/watch?v=qsIShs-3yII",
      "urlToImage": "https://i.ytimg.com/vi/qsIShs-3yII/maxresdefault.jpg",
      "publishedAt": "2020-02-04T09:30:03Z",
      "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",

      "datetime": 1580808603000
  }, {
      "source": {
          "id": null,
          "name": "Youtube.com",
          "country": "CA",
          "category": "BUSINESS",
      },
      "author": null,
      "title": "#MiningIndaba2020: How Cape Town is cashing in on the #MiningIndaba2020 - CNBCAfrica",
      "description": "The Mining Indaba kicked off in Cape Town this morning as nearly seven thousand delegates arrived to discuss projects plans and investment. It also creates a...",
      "url": "https://www.youtube.com/watch?v=7etK4hRB5W8",
      "urlToImage": "https://i.ytimg.com/vi/7etK4hRB5W8/maxresdefault.jpg",
      "publishedAt": "2020-02-04T09:17:38Z",
      "content": "The Mining Indaba kicked off in Cape Town this morning as nearly seven thousand delegates arrived to discuss projects plans and investment. It also creates a huge boost for Cape Towns economy. CNBC Africa reports on the eve of the conference.",

      "datetime": 1580807858000
  }
  ];


  $scope.$watch("search", function(n, o) {
    var selected = [];
    for (var language in n.source) {
      if (n.source[source]) {
        selected.push(true);
      }
    }
    for (var unit in n.unit) {
      if (n.unit[unit]) {
        selected.push(true);
      }
    }
    if (selected.length) {
      $scope.search.needFilter = true;
    } else {
      $scope.search.needFilter = false;
    }
  }, true);
}).
filter('myFilter', function() {
  return function(items, search) {
    var filterItems = {
      search: search,
      result: []
    };
    
    if (!search.needFilter) {
      return items;
    }
    
    angular.forEach(items, function(value, key) {
      if (this.search.source[value.source.country] === true || this.search.souce[value.source.category] === true) {
        this.result.push(value);
      }
    }, filterItems);
    return filterItems.result;
  };
});