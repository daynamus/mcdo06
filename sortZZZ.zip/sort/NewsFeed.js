﻿$scope.array = [
{
    "source": {
        "id": null,
        "name": "Gsmarena.com"
    },
    "author": "Michail",
    "title": "Alphabet's Q4 report shows slower than expected growth - GSMArena.com news - GSMArena.com",
    "description": "YouTube and Cloud revenues were lower than estimated.",
    "url": "https://www.gsmarena.com/alphabet_q4_report_shows_slower_than_expected_growth-news-41356.php",
    "urlToImage": "https://fdn.gsmarena.com/imgroot/news/20/02/alphabet-q4-2019-earnings-report/-476x249w4/gsmarena_002.jpg",
    "publishedAt": "2020-02-04T10:04:02Z",
    "content": "Googles parent company Alphabet put out its Q4 and 2019 fiscal year earnings report and the numbers show a slowdown in revenue growth despite an 18% jump in total revenues on a per-year basis. Revenue growth in the October-December period on the other hand w… [+1378 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580810642000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Korean fast-fashion brand Forever 21 finds new owner in 4 months after filing for bankruptcy - KOREA NOW",
    "description": "You can watch this video at https://koreanow.com Korea’s fast-fashion emporium, Forever 21 has found a new owner in just four months after it filed for bankr...",
    "url": "https://www.youtube.com/watch?v=qsIShs-3yII",
    "urlToImage": "https://i.ytimg.com/vi/qsIShs-3yII/maxresdefault.jpg",
    "publishedAt": "2020-02-04T09:30:03Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "ph",
    "category": "business",
    "datetime": 1580808603000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "#MiningIndaba2020: How Cape Town is cashing in on the #MiningIndaba2020 - CNBCAfrica",
    "description": "The Mining Indaba kicked off in Cape Town this morning as nearly seven thousand delegates arrived to discuss projects plans and investment. It also creates a...",
    "url": "https://www.youtube.com/watch?v=7etK4hRB5W8",
    "urlToImage": "https://i.ytimg.com/vi/7etK4hRB5W8/maxresdefault.jpg",
    "publishedAt": "2020-02-04T09:17:38Z",
    "content": "The Mining Indaba kicked off in Cape Town this morning as nearly seven thousand delegates arrived to discuss projects plans and investment. It also creates a huge boost for Cape Towns economy. CNBC Africa reports on the eve of the conference.",
    "country": "ph",
    "category": "business",
    "datetime": 1580807858000
}, {
    "source": {
        "id": "techradar",
        "name": "TechRadar"
    },
    "author": "Vasile Tiple",
    "title": "Robotic Process Automation to transform legal sector - Techradar",
    "description": "How is RPA going to disrupt legal services",
    "url": "https://www.techradar.com/news/robotic-process-automation-to-transform-legal-sector",
    "urlToImage": "https://cdn.mos.cms.futurecdn.net/niUTnNiqNihgKRYSj6qE4C-1200-80.jpg",
    "publishedAt": "2020-02-04T09:08:00Z",
    "content": "The increased pressure faced by law firms to provide their services quicker and at a lower cost for customers means there is a significant demand to adapt the way they work, and even become more efficient. As one of the longest established professions, the le… [+5702 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580807280000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Coronavirus cases surpass 20000 in China, continues to spread worldwide - ARIRANG NEWS",
    "description": "중국 신종코로나 두달만에 사망 420명•확진 2만명 넘어서 The daily number of deaths reported in China is getting bigger and bigger. With those announced early this morning, the tota...",
    "url": "https://www.youtube.com/watch?v=xbYAdVbDjzM",
    "urlToImage": "https://i.ytimg.com/vi/xbYAdVbDjzM/maxresdefault.jpg",
    "publishedAt": "2020-02-04T08:09:08Z",
    "content": "420 2 \r\nThe daily number of deaths reported in China is getting bigger and bigger.With those announced early this morning, the total is now more than 420.A person in Hong Kong has also died from the virus,... only the second death outside of the Chinese mainl… [+1575 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580803748000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "S. Korea's consumer prices up 1.5% y/y in Jan. - ARIRANG NEWS",
    "description": "1월 소비자물가 1.5% 상승...13개월만에 1% 넘어 South Korea's consumer inflation was just zero-point-four percent last year,... marking it the lowest on-year rise since 1965...",
    "url": "https://www.youtube.com/watch?v=uLp8dUDoARc",
    "urlToImage": "https://i.ytimg.com/vi/uLp8dUDoARc/maxresdefault.jpg",
    "publishedAt": "2020-02-04T08:09:08Z",
    "content": "1 1.5% ...13 1% \r\nSouth Korea's consumer inflation was just zero-point-four percent last year,... marking it the lowest on-year rise since 1965.However, the latest figures show consumer prices in January made their fastest gain in over a year.Kim Hyesung repo… [+1489 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580803748000
}, {
    "source": {
        "id": "techcrunch",
        "name": "TechCrunch"
    },
    "author": "Steve O'Hear",
    "title": "Azimo, the money transfer service, secures €20M debt finance from the European Investment Bank - TechCrunch",
    "description": "Azimo, the money transfer service that is HQ’d in London but has the majority of its staff based in based in Poland, has secured €20 million in debt from the European Investment Bank (EIB), the lending arm of the European Union. The financing is supported by …",
    "url": "http://techcrunch.com/2020/02/04/azimo-eib/",
    "urlToImage": "https://techcrunch.com/wp-content/uploads/2019/08/01_Azimo.jpg?w=711",
    "publishedAt": "2020-02-04T08:01:11Z",
    "content": "Azimo, the money transfer service that is HQ’d in London but has the majority of its staff based in based in Poland, has secured 20 million in debt from the European Investment Bank (EIB), the lending arm of the European Union.\r\nThe financing is supported by … [+2216 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580803271000
}, {
    "source": {
        "id": null,
        "name": "Fxstreet.com"
    },
    "author": "Pablo Piovano",
    "title": "Gold Futures: Downside seen as corrective - FXStreet",
    "description": "Traders scaled back their open interest positions by almost 3.2K contracts on Monday in light of advanced data from CME Group. In the same line, volum",
    "url": "https://www.fxstreet.com/news/gold-futures-downside-seen-as-corrective-202002040717",
    "urlToImage": "https://editorial.blob.core.windows.net/images/Markets/Commodities/Metals/Gold/aurum-37842316_Large.jpg",
    "publishedAt": "2020-02-04T07:17:00Z",
    "content": "Note: All information on this page is subject to change. The use of this website constitutes acceptance of our user agreement. Please read our privacy policy and legal disclaimer.\r\nTrading foreign exchange on margin carries a high level of risk and may not be… [+1278 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580800620000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Evelyn Taft's Weather Forecast (Feb. 3) - CBS Los Angeles",
    "description": "Evelyn Taft takes a look at the latest weather forecast.",
    "url": "https://www.youtube.com/watch?v=Zz15YNVN6TE",
    "urlToImage": "https://i.ytimg.com/vi/Zz15YNVN6TE/maxresdefault.jpg",
    "publishedAt": "2020-02-04T07:08:12Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "ph",
    "category": "business",
    "datetime": 1580800092000
}, {
    "source": {
        "id": "cnbc",
        "name": "CNBC"
    },
    "author": "Sam Meredith",
    "title": "BP full-year net profit falls 21% on weak oil and gas prices - CNBC",
    "description": "Energy giant BP reported stronger-than-anticipated full-year net profit on Tuesday.",
    "url": "https://www.cnbc.com/2020/02/04/bp-earnings-q4-2019.html",
    "urlToImage": "https://image.cnbcfm.com/api/v1/image/103353975-GettyImages-169952811.jpg?v=1532564193",
    "publishedAt": "2020-02-04T07:04:00Z",
    "content": "Energy giant BP reported better-than-expected full-year net profit on Tuesday, outperforming analyst expectations despite lower oil and gas prices.\r\nThe U.K.-based oil and gas company posted full-year underlying replacement cost profit, used as a proxy for ne… [+3433 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580799840000
}, {
    "source": {
        "id": "techcrunch",
        "name": "TechCrunch"
    },
    "author": "Steve O'Hear",
    "title": "Dixa, the customer engagement platform, picks up $36M Series B - TechCrunch",
    "description": "Dixa, the customer engagement platform, has closed $36 million in Series B funding. Leading the round is Notion Capital, with participation from existing investors Project A Ventures and SEED Capital. The Copenhagen and now London-based startup says it will u…",
    "url": "http://techcrunch.com/2020/02/03/dixa-series-b/",
    "urlToImage": "https://techcrunch.com/wp-content/uploads/2020/01/4.jpg?w=601",
    "publishedAt": "2020-02-04T07:00:44Z",
    "content": "Dixa, the customer engagement platform, has closed $36 million in Series B funding. Leading the round is Notion Capital, with participation from existing investors Project A Ventures and SEED Capital.\r\nThe Copenhagen and now London-based startup says it will … [+2425 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580799644000
}, {
    "source": {
        "id": null,
        "name": "Nocamels.com"
    },
    "author": null,
    "title": "JVP Celebrates Grand Opening Of International Cyber Center In New York | Technology News - NoCamels - Israeli Innovation News",
    "description": "The international venture capital firm led by Dr. Erel Margalit is helping NYC position itself as a global capital of cybersecurity innovation.",
    "url": "https://nocamels.com/2020/02/jvp-opening-international-cyber-center-new-york/",
    "urlToImage": "https://nocamels.com/wp-content/uploads/2020/02/jpv-partners-1s-photo-shahar-azran-1024x683.jpg",
    "publishedAt": "2020-02-04T06:54:55Z",
    "content": "Jerusalem Venture Partners (JVP), the international venture capital firm led by one of Israel’s leading social and tech entrepreneurs Dr. Erel Margalit, marked the grand opening of the International Cyber Center in New York City’s SOHO neighborhood in Manhatt… [+11014 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580799295000
}, {
    "source": {
        "id": null,
        "name": "Fxstreet.com"
    },
    "author": "Pablo Piovano",
    "title": "Hong Kong: GDP contracted 1.2% in 2019 – UOB - FXStreet",
    "description": "UOB Group’s Economist Ho Woei Chen, CFA, assessed the GDP figures in Hong Kong during last year. Key Quotes “Hong Kong’s advance 4Q19 GDP contraction",
    "url": "https://www.fxstreet.com/news/hong-kong-gdp-contracted-12-in-2019-uob-202002040631",
    "urlToImage": "https://editorial.blob.core.windows.net/images/Macroeconomics/EconomicIndicator/EconomicHealth/GDP/graphs-and-charts-stock-image-gm489590395-39592386_Large.jpg",
    "publishedAt": "2020-02-04T06:31:00Z",
    "content": "UOB Group’s Economist Ho Woei Chen, CFA, assessed the GDP figures in Hong Kong during last year.\r\n“Hong Kong’s advance 4Q19 GDP contraction turned out to be better than market’s expectation but in line with our forecast, at -2.9% y/y (Bloomberg: -3.9%, 3Q19: … [+1366 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580797860000
}, {
    "source": {
        "id": null,
        "name": "Coingeek.com"
    },
    "author": null,
    "title": "The next Genesis: Bitcoin's two beginnings - CoinGeek",
    "description": "Kurt Wuckert Jr. talks about Bitcoin’s second beginning—Genesis—and why it’s been a long time coming.",
    "url": "https://coingeek.com/the-next-genesis-bitcoins-two-beginnings/",
    "urlToImage": "https://coingeek.com/wp-content/uploads/2020/01/the-next-genesis-bitcoins-two-beginnings.jpg",
    "publishedAt": "2020-02-04T06:16:35Z",
    "content": "Let there be light.\r\n…and there was light. And God saw that the light was good. And God separated the light from the darkness. – Book of Genesis, Chapter 1.\r\nGenesis is the name of the original block of Bitcoinhard coded with a cryptic headline from The Times… [+8204 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580796995000
}, {
    "source": {
        "id": "al-jazeera-english",
        "name": "Al Jazeera English"
    },
    "author": "Al Jazeera",
    "title": "Huawei, ZTE urge US to not designate them national security risks - Al Jazeera America",
    "description": "Huawei said the US regulator's action was 'unlawful', while ZTE said it has spent millions on a compliance programme.",
    "url": "https://www.aljazeera.com/ajimpact/huawei-zte-urge-designate-national-security-risks-200204044352716.html",
    "urlToImage": "https://www.aljazeera.com/mritems/Images/2019/11/22/37d230753e8b40bca9e108641e272f1f_18.jpg",
    "publishedAt": "2020-02-04T06:11:00Z",
    "content": "Huawei Technologies Co Ltd and ZTE Corp have asked the United States Federal Communications Commission (FCC) not to finalise its designation of the China tech giants as risks to US national security.\r\nIn November, the FCC voted 5-0 to initially designate Huaw… [+1946 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580796660000
}, {
    "source": {
        "id": null,
        "name": "Caixinglobal.com"
    },
    "author": null,
    "title": "Luckin Refutes Short Seller's Fraud Allegations - Caixin Global",
    "description": "",
    "url": "https://www.caixinglobal.com/2020-02-04/luckin-refutes-short-sellers-fraud-allegations-101511375.html",
    "urlToImage": "http://img.caixin.com/2020-02-04/1580795343808895_560_373.jpg",
    "publishedAt": "2020-02-04T06:07:41Z",
    "content": "Luckin Coffee has come under the spotlight recently due to an anonymous report alleging that the coffee maker has fabricated its financial figures.\r\nThe unattributed 89-page report was posted on Twitter on Friday by short seller Muddy Waters Research, who sai… [+1591 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580796461000
}, {
    "source": {
        "id": null,
        "name": "Sciencealert.com"
    },
    "author": "Carly Cassella",
    "title": "Cigarettes Produce Invisible Chemical Emissions Even After They've Been Extinguished - ScienceAlert",
    "description": "Cigarettes aren't just toxic when they're being smoked. Even when the butts are scrunched up and cold, new research has found they continue to emit harmful compounds in the air.",
    "url": "https://www.sciencealert.com/cigarettes-produce-invisible-chemical-emissions-even-after-they-ve-been-extinguished",
    "urlToImage": "https://www.sciencealert.com/images/2020-02/processed/cigarettebuttsashtray_1024.jpg",
    "publishedAt": "2020-02-04T06:01:29Z",
    "content": "Cigarettes aren't just toxic when they're being smoked. Even when the butts are scrunched up and cold, new research has found they continue to emit harmful compounds in the air.\r\nIn the first 24 hours alone, scientists say a used cigarette butt will produce 1… [+3217 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580796089000
}, {
    "source": {
        "id": null,
        "name": "France24.com"
    },
    "author": "France 24",
    "title": "Macau to close casinos for two weeks over virus - FRANCE 24",
    "description": "",
    "url": "https://www.france24.com/en/20200204-macau-to-close-casinos-for-two-weeks-over-virus",
    "urlToImage": "https://s.france24.com/media/display/a77b6b30-4713-11ea-8249-005056a98db9/w:1240/p:16x9/83ab9ad26f36554f74fcd73c3a60361b264b3bce.jpg",
    "publishedAt": "2020-02-04T06:00:00Z",
    "content": "Macau (AFP)\r\nMacau on Tuesday said it will temporarily close down all casinos as the gambling hub battles the deadly coronavirus, cutting off the lifeblood of the city's economy.\r\nThe move came as the former Portuguese colony confirmed its tenth confirmed cas… [+2003 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580796000000
}, {
    "source": {
        "id": "the-next-web",
        "name": "The Next Web"
    },
    "author": "Ivan Mehta",
    "title": "This new AI model will badmouth you for putting trash in the wrong bin - The Next Web",
    "description": "When I’m at airports, I often get confused as to which trash and recycling bin I should throw my rubbish into. A new solution from a Canadian AI company, Initutaive AI, might come in handy. The firm has developed Oscar, an image-detection based AI, that recog…",
    "url": "https://thenextweb.com/neural/2020/02/04/this-new-ai-model-will-badmouth-you-for-putting-trash-in-the-wrong-bin/",
    "urlToImage": "https://img-cdn.tnwcdn.com/image/neural?filter_last=1&fit=1280%2C640&url=https%3A%2F%2Fcdn0.tnwcdn.com%2Fwp-content%2Fblogs.dir%2F1%2Ffiles%2F2020%2F02%2FGarbage-badmouth.png&signature=160310386fbafddfe8c0343e9c9b5220",
    "publishedAt": "2020-02-04T05:38:00Z",
    "content": "When Im at airports, I often get confused as to which trash and recycling bin I should throw my rubbish into. A new solution from a Canadian AI company, Initutaive AI, might come in handy.\r\nThe firm has developed Oscar, an image-detection based AI, that recog… [+1657 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580794680000
}, {
    "source": {
        "id": null,
        "name": "Jewishlifenews.com"
    },
    "author": null,
    "title": "Global ContinuoGlucose Monitoring (CGM) Market Report 2019 – Industry Capacity, Manufacture, Value, Consumption, Status and Prediction 2025 - Jewish Life News",
    "description": null,
    "url": "https://jewishlifenews.com/uncategorized/global-continuoglucose-monitoring-cgm-market-report-2019-industry-capacity-manufacture-value-consumption-status-and-prediction-2025/",
    "urlToImage": null,
    "publishedAt": "2020-02-04T05:29:21Z",
    "content": "Dataintelo.com, has added the latest research on ContinuoGlucose Monitoring (CGM) Market, which offers a concise outline of the market valuation, industry size, SWOT analysis, revenue approximation, and the regional outlook of this business vertical. The repo… [+6105 chars]",
    "country": "ph",
    "category": "business",
    "datetime": 1580794161000
}, {
    "source": {
        "id": null,
        "name": "Gamesradar.com"
    },
    "author": "Matt Maytum",
    "title": "Fast and Furious 9 director Justin Lin talks #JusticeForHan - GamesRadar",
    "description": "Exclusive: Total Film spoke to Lin about the movie: “I felt like we needed to correct something”",
    "url": "https://www.gamesradar.com/fast-and-furious-9-interview-justin-lin-han/",
    "urlToImage": "https://cdn.mos.cms.futurecdn.net/GerqaL5pTJXCiiKLFEJ22k-1200-80.jpg",
    "publishedAt": "2020-02-04T10:18:00Z",
    "content": "It wasn’t just the action set-pieces in the Fast and Furious 9 trailer that had jaws dropping: the plot twists were equally gasp-inducing. As well as introducing John Cena as Dom Toretto’s long-lost brother, Jakob, the trailer also revealed that Han (Sung Kan… [+2650 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580811480000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "BTS Breaks Justin Bieber's Billboard Social 50 Chart Record After Nearly Three Years | MEAWW - MEAWW",
    "description": "SUBSCRIBE → https://goo.gl/BJk3aj Facebook → https://www.facebook.com/meawwcom/ Twitter → https://twitter.com/meawwcom Instagram → https://www.instagram.com/...",
    "url": "https://www.youtube.com/watch?v=cUOvT3h3Szw",
    "urlToImage": "https://i.ytimg.com/vi/cUOvT3h3Szw/maxresdefault.jpg",
    "publishedAt": "2020-02-04T10:10:19Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580811019000
}, {
    "source": {
        "id": null,
        "name": "Cheatsheet.com"
    },
    "author": "Robert Arissen",
    "title": "Prince Charles' Reaction to Prince Harry's Birth Is Heartbreaking - Showbiz Cheat Sheet",
    "description": "Find out why Prince Charles was bummed out by the birth of his youngest son.",
    "url": "https://www.cheatsheet.com/entertainment/prince-charles-reaction-to-prince-harrys-birth-is-heartbreaking.html/",
    "urlToImage": "https://www.cheatsheet.com/wp-content/uploads/2020/01/prince-harry-song-1024x689.jpg",
    "publishedAt": "2020-02-04T07:43:34Z",
    "content": "From all outward appearances, Prince Charles seems to have a perfect life! Not only is he the future king of Great Britain, but he has two handsome sons, four wonderful grandchildren, a huge fan base, and a wife who loves him dearly. \r\nJudging from the genuin… [+4854 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580802214000
}, {
    "source": {
        "id": null,
        "name": "Inquirer.net"
    },
    "author": "Associated Press",
    "title": "Shows canceled as virus outbreak spooks Asian entertainers - INQUIRER.net",
    "description": "SEOUL — Concerts and shows are being canceled, not just in China but across much of Asia, as a virus outbreak that has killed more than 300 people and reached more then 20 countries spooks the",
    "url": "https://www.inquirer.net",
    "urlToImage": "https://entertainment.inquirer.net/files/2020/02/Kpop-620x437.jpg",
    "publishedAt": "2020-02-04T06:35:00Z",
    "content": "In this June 29, 2019, file photo, Taiwanese singer Jolin Tsai cheers for her awards of the Song of the Year and Album of the Year at the 30th Golden Melody Awards in Taipei, Taiwan. Concerts and shows are being canceled, not just in China but across much of … [+2590 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580798100000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Sandra Gonzalez, CNN",
    "title": "Jennifer Lopez reflects on halftime show with message about what makes America 'truly great' - CNN",
    "description": "Jennifer Lopez is reflecting on her big moment at the Super Bowl on Sunday with an empowering message for the young girls who took the stage with her last night and everywhere.",
    "url": "https://www.cnn.com/2020/02/04/entertainment/jennifer-lopez-super-bowl-halftime/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200202191141-jennifer-lopez-and-emme-super-tease.jpg",
    "publishedAt": "2020-02-04T06:07:00Z",
    "content": null,
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580796420000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "BTS drops 2nd trailer, “Outro: Ego”, for upcoming new album “Map of the Soul:7” - KOREA NOW",
    "description": "You can watch this video at https://koreanow.com Finally! On Monday, BTS dropped the second trailer “Outro: Ego” for its upcoming album, “Map of the Soul:7.”...",
    "url": "https://www.youtube.com/watch?v=eXz4YEhoCO0",
    "urlToImage": "https://i.ytimg.com/vi/eXz4YEhoCO0/hqdefault.jpg",
    "publishedAt": "2020-02-04T05:57:30Z",
    "content": "You can watch this video at https://koreanow.com\r\nFinally! On Monday, BTS dropped the second trailer Outro: Ego for its upcoming album, Map of the Soul:7. Following SUGAs Interlude: Shadow, J-hopes Outro: Ego is different in form. Watch this video to find out… [+5 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580795850000
}, {
    "source": {
        "id": "bleacher-report",
        "name": "Bleacher Report"
    },
    "author": "Adam Wells",
    "title": "Ricochet Wins Triple Threat Match, Will Face Brock Lesnar at WWE Super ShowDown - Bleacher Report",
    "description": "Ricochet finally gets his chance to take down  Brock    Lesnar     when the two superstars square off for the    WWE    Championship at Super    ShowDown    on Feb. 27...",
    "url": "https://bleacherreport.com/articles/2874636-ricochet-wins-triple-threat-match-will-face-brock-lesnar-at-wwe-super-showdown",
    "urlToImage": "https://img.bleacherreport.net/img/images/photos/003/850/801/hi-res-0a9da7fd605b9ac740aa584135432a20_crop_exact.jpg?w=1200&h=1200&q=75",
    "publishedAt": "2020-02-04T05:25:02Z",
    "content": "Etsuo Hara/Getty Images\r\nRicochet finally gets his chance to take down Brock Lesnar when the two superstars square off for the WWE Championship at Super ShowDown on Feb. 27.\r\nThe One and Only earned a shot at the title on Monday's episode of Raw by defeating … [+876 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580793902000
}, {
    "source": {
        "id": null,
        "name": "Pitchfork.com"
    },
    "author": "Madison Bloom",
    "title": "Kamaiyah Announces New Mixtape Got It Made, Shares New Song With Trina: Listen - Pitchfork",
    "description": "The new project from the Oakland rapper arrives later this month",
    "url": "https://pitchfork.com/news/kamaiyah-announces-new-mixtapeandnbspgot-itandnbspmade-shares-new-song-with-trina-listen/",
    "urlToImage": "https://media.pitchfork.com/photos/5e38a8e0ee3f2e0008bc7c65/2:1/w_790/Kamaiyah.jpg",
    "publishedAt": "2020-02-04T05:02:00Z",
    "content": "Oakland rapper Kamaiyah has announced her latest project. Her third release Got It Made arrives February 21. Shes also shared a new track with Trina called Set It Up. Check out Kamaiyahs cover art for the record, and listen to the new song below.\r\nGot It Made… [+308 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580792520000
}, {
    "source": {
        "id": null,
        "name": "Cheatsheet.com"
    },
    "author": "Trey Mangum",
    "title": "Here's Everything We Know About Netflix's Upcoming Adam Sandler Film, 'Hubie Halloween' - Showbiz Cheat Sheet",
    "description": "Though he didn't get an Oscar nomination for Uncut Gems, Adam Sandler is undeterred. He's back at it and has just inked a new deal with Netflix to continue to star in films for the service. One of his upcoming films is Hubie Halloween.",
    "url": "https://www.cheatsheet.com/entertainment/heres-everything-we-know-about-netflixs-upcoming-adam-sandler-film-hubie-halloween.html/",
    "urlToImage": "https://www.cheatsheet.com/wp-content/uploads/2020/02/Adam-Sandler-1024x721.jpg",
    "publishedAt": "2020-02-04T04:31:02Z",
    "content": "Though he didn’t get an Oscar nomination for Uncut Gems,Adam Sandler is undeterred. He’s back at it and has just inked a new deal with Netflix to continue to star in films for the service. One of his upcoming films is Hubie Halloween. \r\nAdam Sandler | ANGELA … [+3141 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580790662000
}, {
    "source": {
        "id": null,
        "name": "Techinasia.com"
    },
    "author": null,
    "title": "SE Asian firms pivot to Hong Kong for capital, with eye on Greater Bay Area - Tech in Asia",
    "description": null,
    "url": "https://www.techinasia.com/singapore-asean-hong-kong-capital",
    "urlToImage": null,
    "publishedAt": "2020-02-04T04:03:00Z",
    "content": null,
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580788980000
}, {
    "source": {
        "id": null,
        "name": "Talentrecap.com"
    },
    "author": "Jill O'Rourke",
    "title": "‘AGT Champions’ Semifinals: The Results Will Shock You! - Talent Recap",
    "description": "Got Talent | Twelve acts competed in the \"AGT Champions\" semifinals, but only six could move on to the finals. Find out the shocking results!",
    "url": "https://talentrecap.com/agt-champions-semifinals-the-results-will-shock-you/",
    "urlToImage": "https://talentrecap.com/wp-content/uploads/2020/02/Marcelito-Pomoy-AGT-Champions-semifinals.png",
    "publishedAt": "2020-02-04T03:23:43Z",
    "content": "AGT: The Champions Season 2 continued on Monday night, as 12 acts competed in the semifinals. The contestants were challenged to step things up from their preliminary performances. Some of them did, and some of them didn’t.\r\nNEW ‘AGT CHAMPIONS’ VOTING SYSTEM … [+4740 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580786623000
}, {
    "source": {
        "id": "google-news",
        "name": "Google News"
    },
    "author": null,
    "title": "Where To Watch Every Mission Impossible Movie Online | ScreenRant - Screen Rant",
    "description": null,
    "url": "https://news.google.com/__i/rss/rd/articles/CBMiTmh0dHBzOi8vc2NyZWVucmFudC5jb20vbWlzc2lvbi1pbXBvc3NpYmxlLXdhdGNoLWV2ZXJ5LW1vdmllLW9ubGluZS10b20tY3J1aXNlL9IBUmh0dHBzOi8vc2NyZWVucmFudC5jb20vbWlzc2lvbi1pbXBvc3NpYmxlLXdhdGNoLWV2ZXJ5LW1vdmllLW9ubGluZS10b20tY3J1aXNlL2FtcC8?oc=5",
    "urlToImage": null,
    "publishedAt": "2020-02-04T03:03:22Z",
    "content": null,
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580785402000
}, {
    "source": {
        "id": null,
        "name": "Ringsidenews.com"
    },
    "author": "H Jenkins",
    "title": "Goldberg Returning To WWE SmackDown This Week - Ringside News",
    "description": "We're about to find out who's next for Goldberg. During a Raw commercial break this week they aired a spot for Friday Night SmackDown where a big return was revealed.Click here for our complete WWE Raw coverage.Goldberg will be back on WWE television",
    "url": "https://www.ringsidenews.com/2020/02/03/goldberg-returning-to-wwe-smackdown-this-week/",
    "urlToImage": "https://www.ringsidenews.com/wp-content/uploads/2019/08/goldberg-85484.png",
    "publishedAt": "2020-02-04T02:29:00Z",
    "content": "We’re about to find out who’s next for Goldberg. During a Raw commercial break this week they aired a spot for Friday Night SmackDown where a big return was revealed.\r\nClick here for our complete WWE Raw coverage.\r\nGoldberg will be back on WWE television this… [+237 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580783340000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Theresa Waldrop and Rebekah Riess, CNN",
    "title": "FBI offers $10,000 for info on armed robber dubbed the 'Scream Bandit' - CNN",
    "description": "The FBI is offering a reward of as much as $10,000 for information leading to the arrest and conviction of a robber dubbed the \"Scream Bandit\" after a string of armed robberies of gas stations.",
    "url": "https://www.cnn.com/2020/02/03/us/scream-bandit-fbi-reward/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200203180735-scream-bandit-super-tease.jpg",
    "publishedAt": "2020-02-04T02:22:00Z",
    "content": null,
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580782920000
}, {
    "source": {
        "id": null,
        "name": "Rappler.com"
    },
    "author": "https://www.facebook.com/AFPnewsenglish",
    "title": "Pamela Anderson and new husband split after just 12 days - Rappler",
    "description": "'Baywatch' star Pamela Anderson and 'Batman' producer Jon Peters call their marriage quits 12 days after tying the knot on January 20",
    "url": "https://www.rappler.com/entertainment/news/250921-pamela-anderson-new-husband-split-after-12-days",
    "urlToImage": "https://assets.rappler.com/612F469A6EA84F6BAE882D2B94A4B421/img/FDCBFCB025924AC58DF0EB118D543174/000_1oo4o9-1.jpg",
    "publishedAt": "2020-02-04T01:55:00Z",
    "content": null,
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580781300000
}, {
    "source": {
        "id": null,
        "name": "Ultimateclassicrock.com"
    },
    "author": "coreyirwin",
    "title": "Julian Lennon Reveals Cancer Scare That Left Him 'Shaking Inside' - Ultimate Classic Rock",
    "description": "Julian Lennon detailed a recent cancer scare that left him ‘Shaking inside’ in a Facebook message posted in February 2020.",
    "url": "https://ultimateclassicrock.com/julian-lennon-cancer-scare/",
    "urlToImage": "https://townsquare.media/site/295/files/2020/02/Julian-Lennon.jpg?w=1200&h=0&zc=1&s=0&a=t&q=89",
    "publishedAt": "2020-02-04T01:43:53Z",
    "content": "Julian Lennon has detailed a recent cancer scare which left him shaking inside.\r\nJulian -- the son of John Lennon -- detailed the ordeal in a post to his Facebook page. I went to visit my dermatologist, here in LA, when she noticed a little bump on my head th… [+1702 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580780633000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Joaquin Phoenix Curtsies To Prince William In Chummy BAFTAs Moment We Can't Stop Watching - Access",
    "description": "Now this is the friendship we never knew we needed! Joaquin Phoenix proved he knows how to greet the royals when giving Prince William a curtsy during their ...",
    "url": "https://www.youtube.com/watch?v=AnM0EkevLe4",
    "urlToImage": "https://i.ytimg.com/vi/AnM0EkevLe4/maxresdefault.jpg",
    "publishedAt": "2020-02-04T01:32:35Z",
    "content": null,
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580779955000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "The 11 Biggest Details Revealed in Marvel's Big Game Spot! (Nerdist News w/ Dan Casey) - Nerdist",
    "description": "After months of anticipation and speculation, fans finally got their first official look at the slate of Marvel television series heading to Disney+. In a pr...",
    "url": "https://www.youtube.com/watch?v=fNfzrF7e5JE",
    "urlToImage": "https://i.ytimg.com/vi/fNfzrF7e5JE/maxresdefault.jpg",
    "publishedAt": "2020-02-04T01:20:29Z",
    "content": "After months of anticipation and speculation, fans finally got their first official look at the slate of Marvel television series heading to Disney+. In a promo spot that aired during the big game, footage from WandaVision, Falcon and the Winter Soldier, and … [+737 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580779229000
}, {
    "source": {
        "id": "google-news",
        "name": "Google News"
    },
    "author": null,
    "title": "No Time To Die Trailer Debunks Rami Malek Classic Villain Rumor - Screen Rant",
    "description": null,
    "url": "https://news.google.com/__i/rss/rd/articles/CBMiTmh0dHBzOi8vc2NyZWVucmFudC5jb20vbm8tdGltZS1kaWUtamFtZXMtYm9uZC1kci1uby1yYW1pLW1hbGVrLXJ1bW9yLWRlYnVua2VkL9IBUmh0dHBzOi8vc2NyZWVucmFudC5jb20vbm8tdGltZS1kaWUtamFtZXMtYm9uZC1kci1uby1yYW1pLW1hbGVrLXJ1bW9yLWRlYnVua2VkL2FtcC8?oc=5",
    "urlToImage": null,
    "publishedAt": "2020-02-04T01:15:12Z",
    "content": null,
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580778912000
}, {
    "source": {
        "id": null,
        "name": "Tvline.com"
    },
    "author": "Kimberly Roots, Kimberly Roots",
    "title": "'The Masked Singer' Season 3, Episode 2: Spoilers and Clues - TVLine",
    "description": "Mask and ye shall receive: Now that The Masked Singer is back, so too is our roundup of the most pertinent clues about the competitors’ true identities.",
    "url": "https://tvline.com/2020/02/03/the-masked-singer-season-3-episode-2-clues-spoilers/",
    "urlToImage": "https://pmctvline2.files.wordpress.com/2020/02/the-masked-singer-season-3-episode-2-spoilers-clues-dw.jpg?w=615",
    "publishedAt": "2020-02-04T00:46:00Z",
    "content": "Mask and ye shall receive: Now that The MaskedSinger is back, so too is our roundup of the most pertinent clues about the competitors’ true identities.\r\nSunday’s post-Super Bowl Season 3 premiere introduced us to six of this go-around’s 18 contestants: White … [+962 chars]",
    "country": "ph",
    "category": "entertainment",
    "datetime": 1580777160000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Overseas Filipino Workers in Macau raise concern over travel ban - CNN Philippines",
    "description": "Overseas Filipino Workers in Macau raising concerns on the travel ban amid the coronavirus outbreak. They are appealing to the government to help them return...",
    "url": "https://www.youtube.com/watch?v=TFIav2nCdlk",
    "urlToImage": "https://i.ytimg.com/vi/TFIav2nCdlk/maxresdefault.jpg",
    "publishedAt": "2020-02-04T10:44:14Z",
    "content": "Overseas Filipino Workers in Macau raising concerns on the travel ban amid the coronavirus outbreak. They are appealing to the government to help them return home.",
    "country": "ph",
    "category": "general",
    "datetime": 1580813054000
}, {
    "source": {
        "id": null,
        "name": "Thejakartapost.com"
    },
    "author": "The Jakarta Post",
    "title": "Thailand confirms six new coronavirus cases, including four Thais - The Jakarta Post - Jakarta Post",
    "description": "Thailand confirmed six new cases of the new coronavirus on Tuesday, four of them Thai nationals and two Chinese, bringing the total to 25, the highest number outside China.",
    "url": "https://www.thejakartapost.com/news/2020/02/04/thailand-confirms-six-new-coronavirus-cases-including-four-thais.html",
    "urlToImage": "https://img.jakpost.net/c/2020/02/04/2020_02_04_85896_1580804250._large.jpg",
    "publishedAt": "2020-02-04T10:40:00Z",
    "content": "Thailand confirmed six new cases of the new coronavirus on Tuesday, four of them Thai nationals and two Chinese, bringing the total to 25, the highest number outside China.\r\nThe four Thais included a couple who visited Japan and two drivers who picked up Chin… [+1030 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580812800000
}, {
    "source": {
        "id": null,
        "name": "Abs-cbn.com"
    },
    "author": "Jan Yumul, ABS-CBN News",
    "title": "HK, Macau OFWs appeal to PH gov't to reconsider 2019 n-CoV travel ban - ABS-CBN News",
    "description": "HONG KONG - Stranded Hong Kong-based OFWs and Hong Kong permanent residents who are Philippine passport holders have appealed to President Duterte to reconsider the 2019-nCoV travel ban.",
    "url": "https://news.abs-cbn.com/overseas/02/04/20/hk-macau-ofws-appeal-to-ph-govt-to-reconsider-2019-n-cov-travel-ban",
    "urlToImage": "https://sa.kapamilya.com/absnews/abscbnnews/media/2020/news/02/04/20200204-travel-ban-1.jpg",
    "publishedAt": "2020-02-04T09:32:00Z",
    "content": "HONG KONG - Stranded Hong Kong-based overseas Filipino workers and Hong Kong permanent residents who are Philippine passport holders have appealed to President Rodrigo Duterte to reconsider his 2019 novel coronavirus (2019-nCoV) travel ban as uncertainties ha… [+10070 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580808720000
}, {
    "source": {
        "id": null,
        "name": "Abs-cbn.com"
    },
    "author": "ABS-CBN News",
    "title": "Patients checked for new coronavirus in PH rise to 105 - ABS-CBN News",
    "description": "MANILA - The number of patients under investigation (PUIs) for the 2019 Novel Coronavirus (2019-nCoV) has risen to 105, a Department of Health report at noon on Tuesday showed.",
    "url": "https://news.abs-cbn.com/news/02/04/20/patients-checked-for-new-coronavirus-in-ph-rises-to-105",
    "urlToImage": "https://sa.kapamilya.com/absnews/abscbnnews/media/2020/news/01/30/20200128-coronavirus-monitoring-san-lazaro-md-8137.jpg",
    "publishedAt": "2020-02-04T09:28:00Z",
    "content": "MANILA - The number of patients under investigation (PUIs) for the 2019 Novel Coronavirus (2019-nCoV) has risen to 105, a Department of Health (DOH) report at noon on Tuesday showed. \r\nA DOH situational report showed 25 additional patients were being checked … [+1888 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580808480000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Analysis by Stephen Collinson, CNN",
    "title": "Iowa Democratic vote-reporting meltdown hands opening to Trump - CNN",
    "description": "The Democratic 2020 crusade to oust President Donald Trump could not have got off to a more disastrous and embarrassing start.",
    "url": "https://www.cnn.com/2020/02/04/politics/election-2020-iowa-caucuses-democrats-donald-trump/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200203232525-34-iowa-caucuses-2020-super-tease.jpg",
    "publishedAt": "2020-02-04T09:13:00Z",
    "content": null,
    "country": "ph",
    "category": "general",
    "datetime": 1580807580000
}, {
    "source": {
        "id": null,
        "name": "Inquirer.net"
    },
    "author": null,
    "title": "DVMF intensifies ASF monitoring against pork products from Davao Region, Luzon - INQUIRER.net",
    "description": "CEBU CITY, Philippines -- The Department of Veterinary Medicine and Fisheries (DVMF) has intensified its monitoring of pork products sold in Cebu City following the confirmation of African Swine Fever",
    "url": "https://cebudailynews.inquirer.net/286053/dvmf-intensifies-asf-monitoring-against-pork-products-from-davao-region-luzon",
    "urlToImage": "https://cebudailynews.inquirer.net/files/2019/10/10-21-ASF.jpeg",
    "publishedAt": "2020-02-04T09:06:00Z",
    "content": "CEBU CITY, Philippines — The Department of Veterinary Medicine and Fisheries (DVMF) has intensified its monitoring of pork products sold in Cebu City following the confirmation of African Swine Fever (ASF) in Davao Occidental on January 31.\r\nDoctor Jennifer L… [+1393 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580807160000
}, {
    "source": {
        "id": null,
        "name": "Abs-cbn.com"
    },
    "author": "ABS-CBN News",
    "title": "Healing priest Fr. Suarez dies of heart attack - ABS-CBN News",
    "description": "Filipino Catholic healing priest Rev. Fr. Fernando Suarez passed away on Tuesday, a spokesperson of his organization has confirmed.",
    "url": "https://news.abs-cbn.com/news/02/04/20/healing-priest-fr-suarez-dies-of-heart-attack",
    "urlToImage": "https://sa.kapamilya.com/absnews/abscbnnews/media/2020/news/02/04/20200204-fr.jpg",
    "publishedAt": "2020-02-04T09:03:00Z",
    "content": "MANILA - Filipino Catholic healing priest Fr. Fernando Suarez passed away on Tuesday at the age of 52, a spokesperson of his organization confirmed. \r\nBased on initial reports, Suarez was playing tennis at the Alabang Country Club when he collapsed. He was br… [+1310 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580806980000
}, {
    "source": {
        "id": null,
        "name": "Inquirer.net"
    },
    "author": "Christia Marie Ramos",
    "title": "Sotto shows film on nCoV as 'bioweapon' vs China; Locsin calls it 'craziest video' - INQUIRER.net",
    "description": "MANILA, Philippines — “This is an example of the craziest video I have ever seen.”\r\n\r\n\r\n\r\nThese were the first words uttered by Foreign Affairs Secretary Teodoro Locsin Jr. after",
    "url": "https://www.inquirer.net",
    "urlToImage": "https://newsinfo.inquirer.net/files/2020/02/locsin-sotto-620x434.jpg",
    "publishedAt": "2020-02-04T08:40:00Z",
    "content": "This combination photo shows DFA Secretary Teodoro Locsin Jr. (left) and Senate President Vicente Sotto III (right). INQUIRER FILE\r\nMANILA, Philippines This is an example of the craziest video I have ever seen.\r\nThese were the first words uttered by Foreign A… [+3256 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580805600000
}, {
    "source": {
        "id": "the-verge",
        "name": "The Verge"
    },
    "author": "Sam Byford",
    "title": "Xiaomi spin-off Poco returns with the 120Hz X2 for $225 - The Verge",
    "description": "Xiaomi spin-off Poco has launched its second phone, the Poco X2. It’s another attempt from the company to produce a high-performance, low-cost phone for the extremely competitive Indian market.",
    "url": "https://www.theverge.com/2020/2/4/21122022/xiaomi-poco-x2-announced-price-specs-realme-redmi-k30",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/f0LYr0CTk71mdNACjVgkt-fSYYI=/0x170:2524x1491/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19683159/EP6arUcUYAEiDrD.jpeg",
    "publishedAt": "2020-02-04T08:10:58Z",
    "content": "Poco is aiming directly at Realme\r\nThe Poco X2 and its spec sheet\r\nPoco\r\nXiaomi spin-off brand Poco has launched its second phone, the Poco X2. Its another attempt from the company to produce a high-performance, low-cost phone for the extremely competitive In… [+3438 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580803858000
}, {
    "source": {
        "id": null,
        "name": "Cnnphilippines.com"
    },
    "author": null,
    "title": "Kai Sotto gets US NCAA Division I offer from Georgia Bulldogs - CNN Philippines",
    "description": "A top basketball school in the US has expressed interest in the Filipino teen star.",
    "url": "http://cnnphilippines.com/sports/2020/2/4/kai-sotto-georgia-bulldogs-us-ncaa-division-I-offer.html",
    "urlToImage": "http://cnnphilippines.com/.imaging/mte/demo-cnn-new/750x450/dam/cnn/2020/2/4/Kai-Sotto_CNNPH.jpg/jcr:content/Kai-Sotto_CNNPH.jpg",
    "publishedAt": "2020-02-04T08:08:30Z",
    "content": "(CNN Philippines, February 4) Playing for The Skills Factory, a team based in Atlanta, Georgia, has been helping Kai Sotto increase his stock for college basketball.\r\nThe 7-foot-2 wunderkind has received an offer from Georgia Bulldogs, an NCAA Division 1 scho… [+359 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580803710000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Sarah Moon and Hollie Silverman, CNN",
    "title": "The bodies of Kobe Bryant and 8 others killed in helicopter crash have been released to their families - CNN",
    "description": "The bodies of Kobe Bryant, his daughter Gianna, and seven other people killed in a helicopter crash last month in Calabasas, California, have been released to their families, according to the website for the Los Angeles County Medical Examiner-Coroner.",
    "url": "https://www.cnn.com/2020/02/04/us/kobe-bryant-crash-bodies-911-calls-released/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200128093456-helicopter-crash-victims-split-super-tease.jpg",
    "publishedAt": "2020-02-04T07:01:00Z",
    "content": "(CNN)The bodies of Kobe Bryant, his daughter Gianna, and seven other people killed in a helicopter crash last month in Calabasas, California, have been released to their families, according to the website for the Los Angeles County Medical Examiner-Coroner.\r\n… [+2357 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580799660000
}, {
    "source": {
        "id": null,
        "name": "Gsmarena.com"
    },
    "author": "Sagar",
    "title": "Unlocked Samsung Galaxy S9+ gets Android 10 in the US - GSMArena.com news - GSMArena.com",
    "description": "The update weighs around 1.9GB in size and comes with January 2020 Android security patch.",
    "url": "https://www.gsmarena.com/samsung_galaxy_s9_s9_plus_android_10_us_unlocked-news-41352.php",
    "urlToImage": "https://fdn.gsmarena.com/imgroot/news/19/12/samsung-galaxy-s9-duo-fourth-android-10-beta/-476x249w4/gsmarena_002.jpg",
    "publishedAt": "2020-02-04T06:54:01Z",
    "content": "Samsung released the Android 10-based One UI 2.0 update for the Galaxy S9 and S9+ last week in the US, but only for the carrier-locked units. Now, the company has expanded the rollout for the unlocked S9+ units as well.\r\nThe firmware for the unlocked units sp… [+462 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580799241000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Coronavirus tally in outbreak epicentre Wuhan, China may just be 'tip of the iceberg' - South China Morning Post",
    "description": "Subscribe to our YouTube channel for free here: https://sc.mp/subscribe-youtube With 2,345 new cases reported in China’s central province of Hubei as of midn...",
    "url": "https://www.youtube.com/watch?v=l3uQYgeMyxQ",
    "urlToImage": "https://i.ytimg.com/vi/l3uQYgeMyxQ/maxresdefault.jpg",
    "publishedAt": "2020-02-04T06:18:50Z",
    "content": "Subscribe to our YouTube channel for free here: https://sc.mp/subscribe-youtube\r\nWith 2,345 new cases reported in Chinas central province of Hubei as of midnight February 3, 2020, medical experts warned that the official number of coronavirus infections might… [+425 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580797130000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Sandra Gonzalez, CNN",
    "title": "Jennifer Lopez reflects on halftime show with message about what makes America 'truly great' - CNN",
    "description": "Jennifer Lopez is reflecting on her big moment at the Super Bowl on Sunday with an empowering message for the young girls who took the stage with her last night and everywhere.",
    "url": "https://www.cnn.com/2020/02/04/entertainment/jennifer-lopez-super-bowl-halftime/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200202191141-jennifer-lopez-and-emme-super-tease.jpg",
    "publishedAt": "2020-02-04T06:07:00Z",
    "content": null,
    "country": "ph",
    "category": "general",
    "datetime": 1580796420000
}, {
    "source": {
        "id": null,
        "name": "France24.com"
    },
    "author": "France 24",
    "title": "Macau to close casinos for two weeks over virus - FRANCE 24",
    "description": "",
    "url": "https://www.france24.com/en/20200204-macau-to-close-casinos-for-two-weeks-over-virus",
    "urlToImage": "https://s.france24.com/media/display/a77b6b30-4713-11ea-8249-005056a98db9/w:1240/p:16x9/83ab9ad26f36554f74fcd73c3a60361b264b3bce.jpg",
    "publishedAt": "2020-02-04T06:00:00Z",
    "content": "Macau (AFP)\r\nMacau on Tuesday said it will temporarily close down all casinos as the gambling hub battles the deadly coronavirus, cutting off the lifeblood of the city's economy.\r\nThe move came as the former Portuguese colony confirmed its tenth confirmed cas… [+2003 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580796000000
}, {
    "source": {
        "id": null,
        "name": "Rappler.com"
    },
    "author": null,
    "title": "Phivolcs records 3rd Taal Volcano harmonic tremor in less than a week - Rappler",
    "description": "A harmonic tremor, a type of volcanic earthquake where the shaking is prolonged, indicates the movement of magma. Taal Volcano stays under Alert Level 3 on Tuesday, February 4.",
    "url": "https://www.rappler.com/nation/250936-phivolcs-advisory-taal-volcano-status-february-4-2020",
    "urlToImage": "https://assets.rappler.com/5A9197F256CC4C228CB2CFDBD5E9C572/img/76068B6310764BC3B2BB52DC50E1BBD8/afp-20200118-taal-volcano.jpg",
    "publishedAt": "2020-02-04T05:45:00Z",
    "content": null,
    "country": "ph",
    "category": "general",
    "datetime": 1580795100000
}, {
    "source": {
        "id": "bleacher-report",
        "name": "Bleacher Report"
    },
    "author": "Adam Wells",
    "title": "Ricochet Wins Triple Threat Match, Will Face Brock Lesnar at WWE Super ShowDown - Bleacher Report",
    "description": "Ricochet finally gets his chance to take down  Brock    Lesnar     when the two superstars square off for the    WWE    Championship at Super    ShowDown    on Feb. 27...",
    "url": "https://bleacherreport.com/articles/2874636-ricochet-wins-triple-threat-match-will-face-brock-lesnar-at-wwe-super-showdown",
    "urlToImage": "https://img.bleacherreport.net/img/images/photos/003/850/801/hi-res-0a9da7fd605b9ac740aa584135432a20_crop_exact.jpg?w=1200&h=1200&q=75",
    "publishedAt": "2020-02-04T05:25:02Z",
    "content": "Etsuo Hara/Getty Images\r\nRicochet finally gets his chance to take down Brock Lesnar when the two superstars square off for the WWE Championship at Super ShowDown on Feb. 27.\r\nThe One and Only earned a shot at the title on Monday's episode of Raw by defeating … [+876 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580793902000
}, {
    "source": {
        "id": null,
        "name": "Koamnewsnow.com"
    },
    "author": null,
    "title": "'Parentese,' not traditional baby talk, boosts a baby's language development - KoamNewsNow.com",
    "description": "Internationally known early learning researcher Patricia Kuhl, the co-director of the Institute for Learning & Brain Sciences at the University of Washington, shares video from an older experiment to illustrate a baby’s preference for motherese, a form of bab…",
    "url": "https://www.koamnewsnow.com/i/parentese-not-traditional-baby-talk-boosts-a-babys-language-development/",
    "urlToImage": "https://images.koamnewsnow.com/wp-content/uploads/2020/02/200203161610-study-babies-prefer-mother-baby-talk-00000000-live-video1.jpg",
    "publishedAt": "2020-02-04T04:39:57Z",
    "content": "February 3, 2020 10:37 PM\r\nPosted: February 3, 2020 10:37 PM\r\nInternationally known early learning researcher Patricia Kuhl, the co-director of the Institute for Learning &amp; Brain Sciences at the University of Washington, shares video from an older experim… [+5828 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580791197000
}, {
    "source": {
        "id": null,
        "name": "Cnnphilippines.com"
    },
    "author": null,
    "title": "Delay in cremation of coronavirus patient as operators 'backing out' – DOH - CNN Philippines",
    "description": "'There were many groups who initially said they would cremate, they would bury in the Chinese cemetery only to find out later on that they changed their minds. They don't want to cremate anymore,” Health Secretary Francisco Duque III says",
    "url": "http://cnnphilippines.com/news/2020/2/4/Chinese-coronavirus-patient-cremation-delayed.html",
    "urlToImage": "http://cnnphilippines.com/.imaging/mte/demo-cnn-new/750x450/dam/cnn/2020/2/3/san-lazaro-facade.jpg/jcr:content/san%20lazaro%20facade.jpg",
    "publishedAt": "2020-02-04T03:51:58Z",
    "content": "Metro Manila (CNN Philippines, February 4) Technical problems have hounded the burial and cremation procedure for the Chinese man who died of novel coronavirus (2019-nCoV) in the Philippines, with several operators backing out from previous deals, the Health … [+2900 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580788318000
}, {
    "source": {
        "id": null,
        "name": "Cnnphilippines.com"
    },
    "author": null,
    "title": "Second death outside of mainland China from coronavirus recorded in Hong Kong - CNN Philippines",
    "description": "A second patient with the novel coronavirus has died outside of mainland China, in the semi-autonomous Chinese city of Hong Kong, according to Hong Kong public broadcaster RTHK.",
    "url": "http://cnnphilippines.com/world/2020/2/4/Novel-coronavirus-Hong-Kong-death.html",
    "urlToImage": "http://cnnphilippines.com/.imaging/mte/demo-cnn-new/750x450/dam/cnn/2020/2/4/Coronavirus-Hong-Kong_br_CNNPH.png/jcr:content/Coronavirus-Hong-Kong_br_CNNPH.png",
    "publishedAt": "2020-02-04T03:47:05Z",
    "content": "(CNN) A second patient with the Wuhan coronavirus has died outside of mainland China, in the semi-autonomous Chinese city of Hong Kong, according to Hong Kong public broadcaster RTHK.\r\nRTHK reported that a 39-year-old man died Tuesday. He is said to have trav… [+488 chars]",
    "country": "ph",
    "category": "general",
    "datetime": 1580788025000
}, {
    "source": {
        "id": null,
        "name": "Thejakartapost.com"
    },
    "author": "The Jakarta Post",
    "title": "Thailand confirms six new coronavirus cases, including four Thais - The Jakarta Post - Jakarta Post",
    "description": "Thailand confirmed six new cases of the new coronavirus on Tuesday, four of them Thai nationals and two Chinese, bringing the total to 25, the highest number outside China.",
    "url": "https://www.thejakartapost.com/news/2020/02/04/thailand-confirms-six-new-coronavirus-cases-including-four-thais.html",
    "urlToImage": "https://img.jakpost.net/c/2020/02/04/2020_02_04_85896_1580804250._large.jpg",
    "publishedAt": "2020-02-04T10:40:00Z",
    "content": "Thailand confirmed six new cases of the new coronavirus on Tuesday, four of them Thai nationals and two Chinese, bringing the total to 25, the highest number outside China.\r\nThe four Thais included a couple who visited Japan and two drivers who picked up Chin… [+1030 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580812800000
}, {
    "source": {
        "id": null,
        "name": "Theconversation.com"
    },
    "author": "Julie Connolly",
    "title": "Carbon monoxide poisons thousands every year – and there are no good treatments - The Conversation UK",
    "description": "Could we treat carbon monoxide poisoning with light?",
    "url": "http://theconversation.com/carbon-monoxide-poisons-thousands-every-year-and-there-are-no-good-treatments-125337",
    "urlToImage": "https://images.theconversation.com/files/305900/original/file-20191209-90557-1bi9p2d.jpg?ixlib=rb-1.1.0&rect=5%2C348%2C3747%2C1856&q=45&auto=format&w=1356&h=668&fit=crop",
    "publishedAt": "2020-02-04T10:26:00Z",
    "content": "Carbon monoxide is an undetectable yet lethal gas, often produced by incomplete combustion of carbon-based fuels, such as coal, gas and wood. It kills about 60 people a year in the UK, according to the NHS. \r\nAlthough statistics on unintentional exposure to c… [+5195 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580811960000
}, {
    "source": {
        "id": null,
        "name": "Who.int"
    },
    "author": null,
    "title": "Nurses administer most cervical cancer screening in England - World Health Organization",
    "description": "“The screening programme is set up to be delivered by primary care in England, and although general practitioners can conduct cervical screening and do so on occasions, this is not the best use of a doctor’s time. There are not enough general practitioner doc…",
    "url": "http://www.euro.who.int/en/health-topics/Health-systems/pages/news/news/2020/2/nurses-administer-most-cervical-cancer-screening-in-england",
    "urlToImage": "http://www.euro.who.int/__data/assets/image/0005/243581/who-europe-250.png",
    "publishedAt": "2020-02-04T10:22:57Z",
    "content": "“The screening programme is set up to be delivered by primary care in England, and although general practitioners can conduct cervical screening and do so on occasions, this is not the best use of a doctor’s time. There are not enough general practitioner doc… [+4353 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580811777000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Sandee LaMotte and Kristen Rogers, CNN",
    "title": "Babies are willing to give up food, showing altruism begins in infancy, study says - CNN",
    "description": "The beginnings of altruism appear to begin early, occurring even among infants who are developmentally primed to have temper tantrums, a new study finds.",
    "url": "https://www.cnn.com/2020/02/04/health/altruistic-infants-wellness/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200203185534-babies-share-food-stock-super-tease.jpg",
    "publishedAt": "2020-02-04T10:08:00Z",
    "content": null,
    "country": "ph",
    "category": "health",
    "datetime": 1580810880000
}, {
    "source": {
        "id": null,
        "name": "Nytimes.com"
    },
    "author": "Nicholas Bakalar",
    "title": "Why Fruits and Vegetables May Lower Alzheimer’s Risk - The New York Times",
    "description": "Flavonols, found in fruits and vegetables, were tied to a lower risk of Alzheimer’s disease.",
    "url": "https://www.nytimes.com/2020/02/04/well/mind/why-fruits-and-vegetables-may-lower-alzheimers-risk.html",
    "urlToImage": "https://static01.nyt.com/images/2016/10/20/well/well_pog_mind/well_pog_mind-facebookJumbo.jpg",
    "publishedAt": "2020-02-04T10:00:00Z",
    "content": "Flavonols, a large class of compounds found in most fruits and vegetables, may be associated with a reduced risk for Alzheimers disease. Flavonols are known to have antioxidant and anti-inflammatory effects, and animal studies have suggested they may improve … [+871 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580810400000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "CytoSeek - next generation cell therapies for cancer - University of Bristol",
    "description": "Cancer touches the lives of many people worldwide, but current treatments can result in damaging side effects. University of Bristol spinout company CytoSeek...",
    "url": "https://www.youtube.com/watch?v=BUGj_zCa-Mo",
    "urlToImage": "https://i.ytimg.com/vi/BUGj_zCa-Mo/maxresdefault.jpg",
    "publishedAt": "2020-02-04T09:58:32Z",
    "content": "Cancer touches the lives of many people worldwide, but current treatments can result in damaging side effects. University of Bristol spinout company CytoSeek are working to revolutionise #cancer#therapies that target only cancer cells and leave healthy cells … [+131 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580810312000
}, {
    "source": {
        "id": null,
        "name": "Lexology.com"
    },
    "author": "Laura Lawless",
    "title": "Pandemic or Pandemonium? Employers Brace for the Coronavirus (US) - Lexology",
    "description": "You can’t escape the panic spreading through mass and social media regarding the 2020 Wuhan Novel Coronavirus, a virus that has resulted in fatalities…",
    "url": "https://www.lexology.com/library/detail.aspx?g=61a02591-e3ec-4e23-8bed-77c3ff9bf40e",
    "urlToImage": "https://www.lexology.com/images/share/lexology-facebook.png",
    "publishedAt": "2020-02-04T09:42:11Z",
    "content": "You can’t escape the panic spreading through mass and social media regarding the 2020 Wuhan Novel Coronavirus, a virus that has resulted in fatalities in China and infected thousands worldwide. Symptoms mimic that of influenza (fever, cough), but can include … [+5607 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580809331000
}, {
    "source": {
        "id": null,
        "name": "Thejakartapost.com"
    },
    "author": "The Jakarta Post",
    "title": "WHO forecasts 81 percent cancer jump in poorer countries - The Jakarta Post - Jakarta Post",
    "description": "The UN health agency on Tuesday warned cancer cases would rise by 81 percent in low- and middle-income countries by 2040 because of a lack of investment in prevention and care.",
    "url": "https://www.thejakartapost.com/life/2020/02/04/who-forecasts-81-percent-cancer-jump-in-poorer-countries.html",
    "urlToImage": "https://img.jakpost.net/c/2019/06/03/2019_06_03_73796_1559536524._large.jpg",
    "publishedAt": "2020-02-04T08:09:00Z",
    "content": "The UN health agency on Tuesday warned cancer cases would rise by 81 percent in low- and middle-income countries by 2040 because of a lack of investment in prevention and care.\r\nThe Geneva-based World Health Organization (WHO) said in a report that these coun… [+1691 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580803740000
}, {
    "source": {
        "id": null,
        "name": "Asianews.network"
    },
    "author": "China Daily",
    "title": "Experts from across globe join forces - asianews.network",
    "description": "Scientists from US, UK, China make notable progress as drugs go through clinical trials.\r\n\r\n\r\n\r\n\r\n\r\n\r\nAs the novel coronavirus spreads through China, time is of the essence, and researchers around the world are joining forces to find a speedy cure.\r\n\r\nWhile t…",
    "url": "https://asianews.network/2020/02/04/experts-from-across-globe-join-forces/",
    "urlToImage": "https://asianews.network/wp-content/uploads/2019/12/5df5b8fea310cf3e97abb87e.jpeg",
    "publishedAt": "2020-02-04T07:20:00Z",
    "content": "As the novel coronavirus spreads through China, time is of the essence, and researchers around the world are joining forces to find a speedy cure.\r\nWhile there is no effective medication or vaccine yet, scientists from the United States, the United Kingdom, C… [+4758 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580800800000
}, {
    "source": {
        "id": null,
        "name": "News-medical.net"
    },
    "author": null,
    "title": "First-line psychotherapies show limited effectiveness for treating military-related PTSD - News-Medical.net",
    "description": "A review of recent clinical trials paints a sobering picture of the usefulness of first-line psychotherapies in treating active duty military personnel and veterans with Post-Traumatic Stress Disorder.",
    "url": "https://www.news-medical.net/news/20200204/First-line-psychotherapies-show-limited-effectiveness-for-treating-military-related-PTSD.aspx",
    "urlToImage": "https://www.news-medical.net/image.axd?picture=2014%2f7%2fStress-620x480.jpg",
    "publishedAt": "2020-02-04T07:17:00Z",
    "content": "A review of recent clinical trials paints a sobering picture of the usefulness of first-line psychotherapies in treating active duty military personnel and veterans with Post-Traumatic Stress Disorder (PTSD).\r\nLed by researchers at NYU Grossman School of Medi… [+2986 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580800620000
}, {
    "source": {
        "id": null,
        "name": "Qz.com"
    },
    "author": "Mary Hui",
    "title": "Wuhan coronavirus: Mask shortage illustrates basic economic theory - Quartz",
    "description": "Global shortages, price gouging, rationing—it's all there.",
    "url": "https://qz.com/1793749/wuhan-coronavirus-mask-shortage-illustrates-basic-economic-theory/",
    "urlToImage": "https://cms.qz.com/wp-content/uploads/2020/01/AP_20030193176792.jpg?quality=75&strip=all&w=1400",
    "publishedAt": "2020-02-04T06:53:00Z",
    "content": "Even small changes in China have global effects.\r\nAcross China and in Hong Kong, but also as far afield as San Francisco and Rome, stores shelves have been swept clean of face masks amid surging demand. This has given rise to a simple question, but no easy an… [+5337 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580799180000
}, {
    "source": {
        "id": null,
        "name": "Topgear.com.ph"
    },
    "author": null,
    "title": "Here's how commuters can keep safe from coronavirus - Top Gear Philippines",
    "description": "Putting a little effort into prevention will go a long way",
    "url": "https://www.topgear.com.ph/features/feature-articles/coronavirus-commuter-safety-a2690-20200204-lfrm",
    "urlToImage": "http://images.summitmedia-digital.com/topgear/images/2020/02/04/novel-coronavirus-commuter-motorist-safety-tips-1580779763.jpg",
    "publishedAt": "2020-02-04T06:37:05Z",
    "content": "At the end of December 2019, a novel strain of coronavirus (nCoV) was reported in Wuhan, China. A coronavirus is just one type of over 200 viruses that cause the common cold. This particular strain is related to the Severe Acute Respiratory Syndrome-coronavir… [+5714 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580798225000
}, {
    "source": {
        "id": null,
        "name": "News-medical.net"
    },
    "author": null,
    "title": "Liquid biopsy independently associated with melanoma relapse, study shows - News-Medical.net",
    "description": "A study at The University of Texas MD Anderson Cancer Center showed that circulating tumor cells, a form of liquid biopsy, was independently associated with melanoma relapse, suggesting CTC assessment may be useful in identifying patients at risk for relapse …",
    "url": "https://www.news-medical.net/news/20200204/Liquid-biopsy-independently-associated-with-melanoma-relapse-study-shows.aspx",
    "urlToImage": "https://www.news-medical.net/image.axd?picture=2014%2f7%2fMelanoma-620x480.jpg",
    "publishedAt": "2020-02-04T06:12:00Z",
    "content": "A study at The University of Texas MD Anderson Cancer Center showed that circulating tumor cells (CTCs), a form of liquid biopsy, was independently associated with melanoma relapse, suggesting CTC assessment may be useful in identifying patients at risk for r… [+2111 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580796720000
}, {
    "source": {
        "id": null,
        "name": "Sciencealert.com"
    },
    "author": "Carly Cassella",
    "title": "Cigarettes Produce Invisible Chemical Emissions Even After They've Been Extinguished - ScienceAlert",
    "description": "Cigarettes aren't just toxic when they're being smoked. Even when the butts are scrunched up and cold, new research has found they continue to emit harmful compounds in the air.",
    "url": "https://www.sciencealert.com/cigarettes-produce-invisible-chemical-emissions-even-after-they-ve-been-extinguished",
    "urlToImage": "https://www.sciencealert.com/images/2020-02/processed/cigarettebuttsashtray_1024.jpg",
    "publishedAt": "2020-02-04T06:01:29Z",
    "content": "Cigarettes aren't just toxic when they're being smoked. Even when the butts are scrunched up and cold, new research has found they continue to emit harmful compounds in the air.\r\nIn the first 24 hours alone, scientists say a used cigarette butt will produce 1… [+3217 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580796089000
}, {
    "source": {
        "id": null,
        "name": "Trtworld.com"
    },
    "author": "TRTWorld",
    "title": "Dog sleuths sniff out crop disease hitting citrus trees - TRT World",
    "description": "Dog sleuths are faster, cheaper and more accurate than people collecting hundreds of leaves for lab analysis, according to the study in the Proceedings of National Academies of Sciences.",
    "url": "https://www.trtworld.com/life/dog-sleuths-sniff-out-crop-disease-hitting-citrus-trees-33467",
    "urlToImage": "https://cdni0.trtworld.com/w480/h270/q75/71429_USAarchivetexask9afp_1580790901518.jpeg",
    "publishedAt": "2020-02-04T04:37:04Z",
    "content": "Dog sleuths are faster, cheaper and more accurate than people collecting hundreds of leaves for lab analysis, according to the study in the Proceedings of National Academies of Sciences.\r\nIn one experiment in a Texas grapefruit orchard, trained dogs were accu… [+2400 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580791024000
}, {
    "source": {
        "id": null,
        "name": "Koreaherald.com"
    },
    "author": "Herald",
    "title": "Korean coronavirus patients stable, to be discharged soon: KCDC - The Korea Herald",
    "description": "The first 15 patients of the new coronavirus infections in Korea are stable as they were diagnosed and treated in the early stages, health authorities said Tuesday.  One of the patients has fully recovered and is waiting to be discharged from hospital, the Ko…",
    "url": "http://www.koreaherald.com/view.php?ud=20200204000583",
    "urlToImage": "http://res.heraldm.com/content/image/2020/02/04/20200204000440_0.jpg",
    "publishedAt": "2020-02-04T04:34:27Z",
    "content": "The first 15 patients of the new coronavirus infections in Korea are stable as they were diagnosed and treated in the early stages, health authorities said Tuesday.One of the patients has fully recovered and is waiting to be discharged from hospital, the Kore… [+1869 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580790867000
}, {
    "source": {
        "id": null,
        "name": "Cgtn.com"
    },
    "author": "",
    "title": "A more vile enemy than virus - CGTN",
    "description": "In our modern, borderless world, we aren't living in villages anymore. Even though we may pay a price dealing with strangers, we still do, and we are better off because of it.",
    "url": "https://news.cgtn.com/news/2020-02-04/A-more-vile-enemy-than-virus-NNRY9uwNC8/index.html",
    "urlToImage": "https://video.cgtn.com/news/3151444e3445444f77456a4e354d444f3341444f31457a6333566d54/video/c54d4955b6444f3abdc71e854820b265/c54d4955b6444f3abdc71e854820b265-1.jpeg",
    "publishedAt": "2020-02-04T04:25:47Z",
    "content": "First a city with a population of 11 million was shut down and then a country of 1.4 billion people came to a halt. Most people have shown concern and understanding. Whenever there is a public health concern, people tend to react strongly, however some have a… [+2648 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580790347000
}, {
    "source": {
        "id": null,
        "name": "Coconuts.co"
    },
    "author": "CoconutsBali",
    "title": "'We don't know anything': Bali pig farmers raise concerns on increasing swine deaths, officials yet to announce lab results - Coconuts",
    "description": "Nearly 1,200 pigs across Bali have reportedly died since the end of December, according to data from the Agriculture and Food Agency in Bali, with officials suspecting they may have died from a virus, though this has yet to be confirmed “From...",
    "url": "https://coconuts.co/bali/news/we-dont-know-anything-bali-pig-farmers-raise-concerns-on-increasing-swine-deaths-officials-yet-to-announce-lab-results/",
    "urlToImage": "https://coconuts.co/wp-content/uploads/2020/02/Pig-Died-Tabanan.jpg",
    "publishedAt": "2020-02-04T04:15:59Z",
    "content": "Nearly 1,200 pigs across Bali have reportedly died since the end of December, according to data from the Agriculture and Food Agency in Bali, with officials suspecting they may have died from a virus, though this has yet to be confirmed.\r\nFrom the observation… [+1542 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580789759000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "UMass Boston student with coronavirus took right steps, school says - WCVB Channel 5 Boston",
    "description": "Campus health officials say the risk to the university's community is low thanks to that student's decision to go straight to the school's health center. Sub...",
    "url": "https://www.youtube.com/watch?v=BTfaNy9jUew",
    "urlToImage": "https://i.ytimg.com/vi/BTfaNy9jUew/hqdefault.jpg",
    "publishedAt": "2020-02-04T03:54:31Z",
    "content": "Campus health officials say the risk to the university's community is low thanks to that student's decision to go straight to the school's health center.\r\nSubscribe to WCVB on YouTube now for more: http://bit.ly/1e8lAMZ\r\nGet more Boston news: http://www.wcvb.… [+119 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580788471000
}, {
    "source": {
        "id": null,
        "name": "News-medical.net"
    },
    "author": null,
    "title": "Behavioral therapy assisted by a smartphone app helps patients with binge eating disorders - News-Medical.net",
    "description": "Behavioral therapy assisted by a smartphone app, delivered via telemedicine by a health coach, was an effective treatment for several symptoms of binge eating disorders, according to a study conducted by researchers from the Icahn School of Medicine at Mount …",
    "url": "https://www.news-medical.net/news/20200203/Behavioral-therapy-assisted-by-a-smartphone-app-helps-patients-with-binge-eating-disorders.aspx",
    "urlToImage": "https://www.news-medical.net/image.axd?picture=2014%2f7%2fEating_Disorder-620x480.jpg",
    "publishedAt": "2020-02-04T03:28:00Z",
    "content": "Behavioral therapy assisted by a smartphone app, delivered via telemedicine by a health coach, was an effective treatment for several symptoms of binge eating disorders, according to a study conducted by researchers from the Icahn School of Medicine at Mount … [+4548 chars]",
    "country": "ph",
    "category": "health",
    "datetime": 1580786880000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Science X staff",
    "title": "Is human cooperativity an outcome of competition between cultural groups? - Phys.org",
    "description": "It may not always seem so, but scientists are convinced that humans are unusually cooperative. Unlike other animals, we cooperate not just with kith and kin, but also with genetically unrelated strangers. Consider how often we rely on the good behavior of acq…",
    "url": "https://phys.org/news/2020-02-human-cooperativity-outcome-competition-cultural.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/hires/2020/ishumancoope.jpg",
    "publishedAt": "2020-02-04T10:00:05Z",
    "content": "It may not always seem so, but scientists are convinced that humans are unusually cooperative. Unlike other animals, we cooperate not just with kith and kin, but also with genetically unrelated strangers. Consider how often we rely on the good behavior of acq… [+5300 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580810405000
}, {
    "source": {
        "id": null,
        "name": "Spacedaily.com"
    },
    "author": null,
    "title": "UNH researchers find clues to how hazardous space radiation begins - Space Daily",
    "description": "Durham NH (SPX) Feb 04, 2020 - \r\nScientists at the University of New Hampshire have unlocked one of the mysteries of how particles from flares on the sun accumulate at early stages in the energization of hazardous radiation that is",
    "url": "http://www.spacedaily.com/reports/UNH_researchers_find_clues_to_how_hazardous_space_radiation_begins_999.html",
    "urlToImage": "http://www.spxdaily.com/images-bg/nasa-parker-solar-probe-sun-corona-space-artwork-bg.jpg",
    "publishedAt": "2020-02-04T08:38:03Z",
    "content": "Scientists at the University of New Hampshire have unlocked one of the mysteries of how particles from flares on the sun accumulate at early stages in the energization of hazardous radiation that is harmful to astronauts, satellites and electronic equipment i… [+4379 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580805483000
}, {
    "source": {
        "id": null,
        "name": "Ecns.cn"
    },
    "author": null,
    "title": "NASA to broadcast solar orbiter launch, prelaunch activities(1/1) - ecns",
    "description": "",
    "url": "http://www.ecns.cn/hd/2020-02-04/detail-ifztewca0595796.shtml",
    "urlToImage": null,
    "publishedAt": "2020-02-04T07:55:08Z",
    "content": "This handout illustration image provided by NASA and obtained February 3, 2020 shows the Solar Orbiter. - NASA is targeting 11:03 p.m. EST on February 9, 2020 for the launch of Solar Orbiter, an international collaborative mission between ESA (European Space … [+677 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580802908000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Science X staff",
    "title": "'Oldest bamboo' fossil from Eocene Patagonia turns out to be a conifer - Phys.org",
    "description": "A fossilised leafy branch from the early Eocene in Patagonia described in 1941 is still often cited as the oldest bamboo fossil and the main fossil evidence for a Gondwanan origin of bamboos. However, a recent examination by Dr. Peter Wilf from Pennsylvania S…",
    "url": "https://phys.org/news/2020-02-oldest-bamboo-fossil-eocene-patagonia.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/2020/oldestbamboo.jpg",
    "publishedAt": "2020-02-04T07:44:33Z",
    "content": "A fossilised leafy branch from the early Eocene in Patagonia described in 1941 is still often cited as the oldest bamboo fossil and the main fossil evidence for a Gondwanan origin of bamboos. However, a recent examination by Dr. Peter Wilf from Pennsylvania S… [+3574 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580802273000
}, {
    "source": {
        "id": null,
        "name": "Theguardian.com"
    },
    "author": "Graham Readfearn",
    "title": "Global heating a serious threat to the world's climate refuges, study finds - The Guardian",
    "description": "Biodiversity hotspots with millions of years of climate stability could be among the world’s hardest hit regions",
    "url": "https://www.theguardian.com/environment/2020/feb/04/global-heating-a-serious-threat-to-the-worlds-climate-refuges-study-finds",
    "urlToImage": "https://i.guim.co.uk/img/media/cd66b159f255d2c23c13ed21177ff04c4419efc5/0_78_5416_3250/master/5416.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=72902cf799bc28d3b5c17e610abad2ad",
    "publishedAt": "2020-02-04T07:43:00Z",
    "content": "Biodiversity hotspots that have given species a safe haven from changing climates for millions of years will come under threat from human-driven global heating, a new study has found.\r\nSpecies that have evolved in tropical regions such Australias wet tropics,… [+3920 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580802180000
}, {
    "source": {
        "id": null,
        "name": "Techexplorist.com"
    },
    "author": "https://www.facebook.com/malewar.amit",
    "title": "Turning metals into insulators using a new quantum switch - Tech Explorist",
    "description": "Scientists have demonstrated an entirely new way to precisely control such electrical currents by leveraging the interaction between an electron's spin and its orbital rotation around the nucleus.",
    "url": "https://www.techexplorist.com/turning-metals-insulators-new-quantum-switch/29746/",
    "urlToImage": "https://www.techexplorist.com/wp-content/uploads/2020/02/traffic-jam.jpg",
    "publishedAt": "2020-02-04T06:54:53Z",
    "content": "Scientists from the University of British Columbia have recently demonstrated a whole new way to precisely control electrical currents by leveraging the interaction between an electron’s spin, and it’s orbital rotation around the nucleus. They have discovered… [+2957 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580799293000
}, {
    "source": {
        "id": null,
        "name": "Spaceflightnow.com"
    },
    "author": null,
    "title": "Cygnus departs space station, deploys CubeSats - Spaceflight Now",
    "description": null,
    "url": "https://spaceflightnow.com/2020/02/03/cygnus-departs-space-station-deploys-cubesats/",
    "urlToImage": null,
    "publishedAt": "2020-02-04T05:46:48Z",
    "content": "Northrop Grumman’s Cygnus cargo craft departed the International Space Station Friday before raising its orbit and deploying multiple CubeSats. Credit: Oleg Skripochka/Roscosmos\r\nA Northrop Grumman Cygnus cargo craft departed the International Space Station F… [+9135 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580795208000
}, {
    "source": {
        "id": null,
        "name": "Econotimes.com"
    },
    "author": null,
    "title": "NASA: Agency shows what Earth will look like with no bodies of water through simulation - EconoTimes",
    "description": "Although space agency NASA is more about learning about what occurs outside Earth, they also take note of what is happening to the planet on an environmental aspect. A new report reveals that through a simulation, NASA...",
    "url": "https://www.econotimes.com/nasa-agency-shows-what-earth-will-look-like-with-no-bodies-of-water-through-simulation-1573934",
    "urlToImage": "https://s1.econotimes.com/assets/uploads/202002049129bfce6862f0206_th_1024x0.jpg",
    "publishedAt": "2020-02-04T05:14:49Z",
    "content": "Although space agency NASA is more about learning about what occurs outside Earth, they also take note of what is happening to the planet on an environmental aspect. A new report reveals that through a simulation, NASA shows us what the planet would look like… [+2126 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580793289000
}, {
    "source": {
        "id": null,
        "name": "Econotimes.com"
    },
    "author": null,
    "title": "Asteroids: Space rock hurtling towards Earth burns up at atmosphere above California - EconoTimes",
    "description": "There is a very slim chance of an asteroid actually hitting Earth, according to scientists. However, a new report reveals that an asteroid may have attempted to enter the Earths atmosphere, but burned up upon contact above...",
    "url": "https://www.econotimes.com/Asteroids-Space-rock-hurtling-towards-Earth-burns-up-at-atmosphere-above-California-1573935",
    "urlToImage": "https://s1.econotimes.com/assets/uploads/20200204b144054111e76edbf_th_1024x0.jpg",
    "publishedAt": "2020-02-04T05:14:49Z",
    "content": "There is a very slim chance of an asteroid actually hitting Earth, according to scientists. However, a new report reveals that an asteroid may have attempted to enter the Earth’s atmosphere, but burned up upon contact above California.\r\nExpress reports that a… [+1782 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580793289000
}, {
    "source": {
        "id": null,
        "name": "Spacenews.com"
    },
    "author": "Jeff Foust",
    "title": "Report highlights progress in heliophysics despite budget challenges - SpaceNews",
    "description": "An independent review has concluded that NASA and other agencies have done a good job implementing the most recent decadal survey for space physics.",
    "url": "https://spacenews.com/report-highlights-progress-in-heliophysics-despite-budget-challenges/",
    "urlToImage": "https://spacenews.com/wp-content/uploads/2020/02/imap.jpg",
    "publishedAt": "2020-02-04T05:01:12Z",
    "content": "SANTA CLARA, Calif. An independent review has concluded that NASA and other agencies have generally done a good job implementing the most recent decadal survey for space physics, despite funding for such programs that was lower than predicted.\r\nThe report by … [+3527 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580792472000
}, {
    "source": {
        "id": null,
        "name": "Scitechdaily.com"
    },
    "author": null,
    "title": "Physics Researchers Discover Sand Dunes Can ‘Communicate’ With Each Other - SciTechDaily",
    "description": "Even though they are inanimate objects, sand dunes can 'communicate' with each other. A team from the University of Cambridge has found that as they move, sand dunes interact with and repel their downstream neighbors. Using an experimental dune 'racetrack', t…",
    "url": "https://scitechdaily.com/physics-researchers-discover-sand-dunes-can-communicate-with-each-other/",
    "urlToImage": "https://scitechdaily.com/images/Sand-Dunes.jpg",
    "publishedAt": "2020-02-04T05:00:21Z",
    "content": "Even though they are inanimate objects, sand dunes can ‘communicate’ with each other. A team from the University of Cambridge has found that as they move, sand dunes interact with and repel their downstream neighbors.\r\nUsing an experimental dune ‘racetrack’, … [+4517 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580792421000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Science X staff",
    "title": "Feeding bluebirds helps fend off parasites - Phys.org",
    "description": "If you feed the birds in your backyard, you may be doing more than just making sure they have a source of food: you may be helping baby birds give parasites the boot.",
    "url": "https://phys.org/news/2020-02-bluebirds-fend-parasites.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/hires/2020/feedingblueb.jpg",
    "publishedAt": "2020-02-04T05:00:01Z",
    "content": "If you feed the birds in your backyard, you may be doing more than just making sure they have a source of food: you may be helping baby birds give parasites the boot.\r\nNew research published in the Journal of Applied Ecology from UConn assistant professor of … [+4228 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580792401000
}, {
    "source": {
        "id": null,
        "name": "Koamnewsnow.com"
    },
    "author": null,
    "title": "'Parentese,' not traditional baby talk, boosts a baby's language development - KoamNewsNow.com",
    "description": "Internationally known early learning researcher Patricia Kuhl, the co-director of the Institute for Learning & Brain Sciences at the University of Washington, shares video from an older experiment to illustrate a baby’s preference for motherese, a form of bab…",
    "url": "https://www.koamnewsnow.com/i/parentese-not-traditional-baby-talk-boosts-a-babys-language-development/",
    "urlToImage": "https://images.koamnewsnow.com/wp-content/uploads/2020/02/200203161610-study-babies-prefer-mother-baby-talk-00000000-live-video1.jpg",
    "publishedAt": "2020-02-04T04:39:57Z",
    "content": "February 3, 2020 10:37 PM\r\nPosted: February 3, 2020 10:37 PM\r\nInternationally known early learning researcher Patricia Kuhl, the co-director of the Institute for Learning &amp; Brain Sciences at the University of Washington, shares video from an older experim… [+5828 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580791197000
}, {
    "source": {
        "id": null,
        "name": "Inquisitr.com"
    },
    "author": "Rachel Tsoumbakos",
    "title": "Arctic Permafrost Is Thawing So Quickly That Massive Sinkholes Are Occurring - The Inquisitr",
    "description": "Referred to as ‘thermokarst’ it is believed scientists are underestimating the effects of thawing permafrost by as much as 50 percent in some areas of the Arctic. According to a new ...",
    "url": "https://www.inquisitr.com/5872129/arctic-permafrost-thawing-sinkholes/",
    "urlToImage": "https://cdn.inquisitr.com/wp-content/uploads/2020/02/Arctic-landscape.jpg",
    "publishedAt": "2020-02-04T01:39:41Z",
    "content": "Referred to as 'thermokarst' it is believed scientists are underestimating the effects of thawing permafrost by as much as 50 percent in some areas of the Arctic.\r\nAccording to a new study, many climate scientists using calculations on the degree of permafros… [+2980 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580780381000
}, {
    "source": {
        "id": null,
        "name": "Digitaljournal.com"
    },
    "author": null,
    "title": "Innovation helped ancient Siberian hunters survive the Ice Age - Digital Journal",
    "description": "Heat-resistant pots began to appear in the Amur region in the Russian Far East between roughly 16,000 and 12,000 years ago, as the Ice Age slightly eased. However, research indicates there was no single point of origin for the world's oldest pottery.",
    "url": "http://www.digitaljournal.com/tech-and-science/science/innovation-helped-ancient-siberian-hunters-survive-the-ice-age/article/566478",
    "urlToImage": "http://www.digitaljournal.com/img/8/4/3/0/8/3/i/4/5/3/p-large/ice-2_8.JPG",
    "publishedAt": "2020-02-04T01:11:39Z",
    "content": "<table><tr><td><table><tr><td>Heat-resistant pots began to appear in the Amur region in the Russian Far East between roughly 16,000 and 12,000 years ago, as the Ice Age slightly eased. However, research indicates there was no single point of origin for the wo… [+3792 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580778699000
}, {
    "source": {
        "id": null,
        "name": "Eurasiareview.com"
    },
    "author": "https://www.eurasiareview.com/author/admin/",
    "title": "Past Climate Safe Havens Now Most Vulnerable - Eurasia Review",
    "description": "The profound threat of future climate change to biodiversity demands that scientists seek ever more effective ways to identify the most vulnerable species, communities, and ecosystems. In a new stu…",
    "url": "https://www.eurasiareview.com/04022020-past-climate-safe-havens-now-most-vulnerable/",
    "urlToImage": "https://www.eurasiareview.com/wp-content/uploads/2019/12/b-35.jpg",
    "publishedAt": "2020-02-04T00:05:00Z",
    "content": "The profound threat of future climate change to biodiversity demands that scientists seek ever more effective ways to identify the most vulnerable species, communities, and ecosystems.\r\nIn a new study, published in Nature Climate Change, an international team… [+2259 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580774700000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Sean Martin",
    "title": "Weather warning: Earth could be hit by MINI ICE-AGE as Sun ‘hibernates’ - Express.co.uk",
    "description": "EARTH could be braced for a ‘mini ICE-AGE' as experts warn a solar minimum could last until the 2050s.",
    "url": "https://www.express.co.uk/news/science/1237178/weather-warning-ice-age-earth-sun-hibernates-solar-minimum-long-range-forecast",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/151/750x445/1237178.jpg",
    "publishedAt": "2020-02-04T00:01:00Z",
    "content": null,
    "country": "ph",
    "category": "science",
    "datetime": 1580774460000
}, {
    "source": {
        "id": null,
        "name": "Universetoday.com"
    },
    "author": "https://www.facebook.com/evan.gough.3",
    "title": "NASA Astronaut Jessica Meir Took a Space Selfie, Capturing her Reflection in the Space Station - Universe Today",
    "description": "NASA astronaut Jessica Meir had a spare moment to capture some selfies during her last spacewalk. She can't hide her smile!",
    "url": "https://www.universetoday.com/144860/nasa-astronaut-jessica-meir-took-a-space-selfie-capturing-her-reflection-in-the-space-station/",
    "urlToImage": "https://www.universetoday.com/wp-content/uploads/2020/02/EPPeDebXsAA-D3S.jpg",
    "publishedAt": "2020-02-03T23:40:00Z",
    "content": "In 2006, astronomers spotted the telltale sign of a supernova detonating in the galaxy NGC 1260, located about 240 million light-years away in the constellation of Perseus. As telescopes around the world turned their collective light-gathering power on the ex… [+2076 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580773200000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Rob Picheta, CNN",
    "title": "Texting more dangerous for pedestrians than listening to music or speaking on the phone - CNN",
    "description": "We can all agree that walking behind someone who's buried in their phone is annoying. Now scientists are suggesting it's dangerous, too.",
    "url": "https://www.cnn.com/2020/02/03/health/texting-pedestrian-safety-study-wellness-scli-intl/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/170729164127-cell-phone-walking-file-super-tease.jpg",
    "publishedAt": "2020-02-03T23:32:00Z",
    "content": null,
    "country": "ph",
    "category": "science",
    "datetime": 1580772720000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Gisela Crespo, CNN",
    "title": "Scientists find another threat to Greenland's glaciers lurking beneath the ice - CNN",
    "description": "Warm ocean water moving underneath Greenland's glaciers is causing its vast ice sheet to melt even faster.",
    "url": "https://www.cnn.com/2020/02/03/world/greenland-glaciers-melting-underwater/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200203145600-01-warm-underwater-glaciers-melting-super-tease.jpg",
    "publishedAt": "2020-02-03T23:10:00Z",
    "content": "(CNN)Scientists have long known that higher air temperatures are contributing to the surface melting on Greenland's ice sheet.\r\nBut a new study has found another threat that has begun attacking the ice from below: Warm ocean water moving underneath the vast g… [+2346 chars]",
    "country": "ph",
    "category": "science",
    "datetime": 1580771400000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "NBA Top 10 Plays of the Night | February 3, 2020 - NBA",
    "description": "Check out the top 10 plays of the night from around the league on Feb. 3 featuring Ja Morant, Jimmy Butler, Kevin Porter Jr. and more! Subscribe to the NBA: ...",
    "url": "https://www.youtube.com/watch?v=4oaH108MQeQ",
    "urlToImage": "https://i.ytimg.com/vi/4oaH108MQeQ/hqdefault.jpg",
    "publishedAt": "2020-02-04T08:26:58Z",
    "content": "Check out the top 10 plays of the night from around the league on Feb. 3 featuring Ja Morant, Jimmy Butler, Kevin Porter Jr. and more!\r\nSubscribe to the NBA: https://on.nba.com/2JX5gSN\r\nFull Game Highlights Playlist: https://on.nba.com/2rjGMge\r\nFor news, stor… [+149 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580804818000
}, {
    "source": {
        "id": null,
        "name": "Nytimes.com"
    },
    "author": "Trish Bendix",
    "title": "Stephen Colbert Tells a Tale of 2 Kansas Cities - The New York Times",
    "description": "“Oh, I know Missouri,” Colbert said on Monday, channeling President Trump. “It’s the Show-Me State because you have to show me where it is on the map.”",
    "url": "https://www.nytimes.com/2020/02/04/arts/television/late-night-colbert-trump-kansas-city.html",
    "urlToImage": "https://static01.nyt.com/images/2020/02/04/arts/04latenight/04latenight-facebookJumbo.png",
    "publishedAt": "2020-02-04T08:20:00Z",
    "content": "Heres the thing you already know: The Kansas City Chiefs are based in Kansas City, Missouri. [Imitating Trump] Oh, I know Missouri. Its the Show-Me State because you have to show me where it is on the map. Is it the one let me ask you this, let me ask you thi… [+625 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580804400000
}, {
    "source": {
        "id": null,
        "name": "Cnnphilippines.com"
    },
    "author": null,
    "title": "Kai Sotto gets US NCAA Division I offer from Georgia Bulldogs - CNN Philippines",
    "description": "A top basketball school in the US has expressed interest in the Filipino teen star.",
    "url": "http://cnnphilippines.com/sports/2020/2/4/kai-sotto-georgia-bulldogs-us-ncaa-division-I-offer.html",
    "urlToImage": "http://cnnphilippines.com/.imaging/mte/demo-cnn-new/750x450/dam/cnn/2020/2/4/Kai-Sotto_CNNPH.jpg/jcr:content/Kai-Sotto_CNNPH.jpg",
    "publishedAt": "2020-02-04T08:08:30Z",
    "content": "(CNN Philippines, February 4) Playing for The Skills Factory, a team based in Atlanta, Georgia, has been helping Kai Sotto increase his stock for college basketball.\r\nThe 7-foot-2 wunderkind has received an offer from Georgia Bulldogs, an NCAA Division 1 scho… [+359 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580803710000
}, {
    "source": {
        "id": null,
        "name": "Counterpunch.org"
    },
    "author": null,
    "title": "Can Roger Federer Beat Greta? - CounterPunch",
    "description": "How much more is there to say in praise of Swiss icon Roger Federer? Biggest winner in tennis history with 20 Grand Slam titles; Olympic medallist and Davis Cup victor; often called the greatest player of all time (GOAT); devoted father and husband; elegant o…",
    "url": "https://www.counterpunch.org/2020/02/04/can-roger-federer-beat-greta/",
    "urlToImage": "https://www.counterpunch.org/wp-content/dropzone/2018/06/cp-og-logo.png",
    "publishedAt": "2020-02-04T07:54:58Z",
    "content": "How much more is there to say in praise of Swiss icon Roger Federer? Biggest winner in tennis history with 20 Grand Slam titles; Olympic medallist and Davis Cup victor; often called the greatest player of all time (GOAT); devoted father and husband; elegant o… [+3835 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580802898000
}, {
    "source": {
        "id": null,
        "name": "Foxsportsasia.com"
    },
    "author": "https://www.facebook.com/foxsportsasia/",
    "title": "Reports: Chelsea target open for move to Premier League - FOX Sports Asia",
    "description": "Premier League giants Chelsea’s target Timo Werner has revealed that he is open for a move to England. The RB Leipzig’s striker is one of the hottest young property in Europe and has been attracting interest from a number of clubs in the continent in the rece…",
    "url": "https://www.foxsportsasia.com/football/bundesliga/1228594/reports-chelsea-target-open-to-premier-league-move-timo-werner/",
    "urlToImage": "https://www.foxsportsasia.com/uploads/2020/02/GettyImages-1196517036.jpg",
    "publishedAt": "2020-02-04T07:49:04Z",
    "content": "Premier League giants Chelseas target Timo Werner has revealed that he is open for a move to England. The RB Leipzigs striker is one of the hottest young property in Europe and has been attracting interest from a number of clubs in the continent in the recent… [+919 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580802544000
}, {
    "source": {
        "id": null,
        "name": "Denverstiffs.com"
    },
    "author": "Ryan Blackburn",
    "title": "Nuggets Numbers - The 2020 NBA Trade Deadline - Denver Stiffs",
    "description": "Ryan discusses recent rumors surrounding Jrue Holiday, Robert Covington, and some rotation questions moving forward",
    "url": "https://www.denverstiffs.com/2020/2/4/21122023/denver-nuggets-numbers-the-2020-nba-trade-deadline-jrue-holiday-robert-covington",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/6Y1c5ojuxVJ24ipc_SNlBzbXgmI=/0x219:1112x801/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19683144/Screen_Shot_2019_10_04_at_12.06.50_AM.png",
    "publishedAt": "2020-02-04T07:14:42Z",
    "content": "As the NBA Trade Deadline edges ever closer, the Denver Nuggets find themselves in an interesting spot. They may acquire a player, they may move current players to free up time in the rotation. There are many questions surrounding the Nuggets, the first of wh… [+547 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580800482000
}, {
    "source": {
        "id": "espn-cric-info",
        "name": "ESPN Cric Info"
    },
    "author": null,
    "title": "Match Preview New Zealand vs India, 1st ODI 2020 - ESPNcricinfo",
    "description": "Read and watch preview for 1st ODI 2020, India tour of New Zealand 2019/20 only on ESPNcricinfo.com",
    "url": "https://www.espncricinfo.com/series/19322/preview/1187682/new-zealand-vs-india-1st-odi-india-in-new-zealand-2019-20",
    "urlToImage": "https://a.espncdn.com/i/cricket/cricinfo/1214877_900x506.jpg",
    "publishedAt": "2020-02-04T07:03:36Z",
    "content": "Big Picture\r\nNovember 25, 2019. The last time New Zealand actually won a game. They've been winless in nine matches across formats since, and injuries have weakened them further. Their captain and premier batsman Kane Williamson has now joined Trent Boult, Lo… [+4857 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580799816000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Sarah Moon and Hollie Silverman, CNN",
    "title": "The bodies of Kobe Bryant and 8 others killed in helicopter crash have been released to their families - CNN",
    "description": "The bodies of Kobe Bryant, his daughter Gianna, and seven other people killed in a helicopter crash last month in Calabasas, California, have been released to their families, according to the website for the Los Angeles County Medical Examiner-Coroner.",
    "url": "https://www.cnn.com/2020/02/04/us/kobe-bryant-crash-bodies-911-calls-released/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200128093456-helicopter-crash-victims-split-super-tease.jpg",
    "publishedAt": "2020-02-04T07:01:00Z",
    "content": "(CNN)The bodies of Kobe Bryant, his daughter Gianna, and seven other people killed in a helicopter crash last month in Calabasas, California, have been released to their families, according to the website for the Los Angeles County Medical Examiner-Coroner.\r\n… [+2357 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580799660000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Post Game Report: Kristaps Porzingis - Dallas Mavericks",
    "description": "Mavs Kristaps Porzingis speaks to media after the Dallas Mavericks defeat the Indiana Pacers on the road.",
    "url": "https://www.youtube.com/watch?v=9jY9gDrZLAs",
    "urlToImage": "https://i.ytimg.com/vi/9jY9gDrZLAs/maxresdefault.jpg",
    "publishedAt": "2020-02-04T06:57:28Z",
    "content": null,
    "country": "ph",
    "category": "sports",
    "datetime": 1580799448000
}, {
    "source": {
        "id": "bleacher-report",
        "name": "Bleacher Report"
    },
    "author": "Dan Favale",
    "title": "New York Knicks Have Become NBA's Most Interesting Team Ahead of Trade Deadline - Bleacher Report",
    "description": "Trying to figure out what the  New York Knicks  will do next is not an exercise for the faint of heart. If they are not the  NBA 's single most unpredictable team, they're pretty darn close...",
    "url": "https://bleacherreport.com/articles/2874629-new-york-knicks-have-become-nbas-most-interesting-team-ahead-of-trade-deadline",
    "urlToImage": "https://img.bleacherreport.net/img/images/photos/003/850/799/hi-res-3b39b552d0716d5c4f835fb0e6b2be44_crop_exact.jpg?w=1200&h=1200&q=75",
    "publishedAt": "2020-02-04T06:44:12Z",
    "content": "Sarah Stier/Getty Images\r\nTrying to figure out what the New York Knicks will do next is not an exercise for the faint of heart. If they are not the NBA's single most unpredictable team, they're pretty darn close.\r\nExpecting them to make the wrong decision(s) … [+10465 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580798652000
}, {
    "source": {
        "id": null,
        "name": "Nbcsports.com"
    },
    "author": null,
    "title": "Report: Dubs rejected two firsts from T-Wolves for D-Lo - NBCSports.com",
    "description": "There's a bottleneck forming ahead of Thursday's NBA trade deadline, and the Warriors reportedly are at the center of it.",
    "url": "https://www.nbcsports.com/bayarea/warriors/nba-rumors-warriors-nixed-timberwolves-dangelo-russell-trade-offer",
    "urlToImage": "https://www.nbcsports.com/bayarea/sites/csnbayarea/files/2020/02/03/dlotwolvesusatsi.jpg",
    "publishedAt": "2020-02-04T06:38:57Z",
    "content": "As Steve Kerr walked into Capital One Arena on Monday night for a game against the Wizards, the Warriors' coach was at least mildly concerned with how his roster would respond to being subjected to relentless trade buzz.\r\nIt affects everybody, Kerr told repor… [+4117 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580798337000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "SPURS at CLIPPERS | FULL GAME HIGHLIGHTS | February 3, 2020 - NBA",
    "description": "SPURS at CLIPPERS | FULL GAME HIGHLIGHTS | February 3, 2020 The L.A. Clippers defeated the San Antonio Spurs, 108-105. Kawhi Leonard recorded 22 PTS, 6 REB a...",
    "url": "https://www.youtube.com/watch?v=CoBlWB2_VJY",
    "urlToImage": "https://i.ytimg.com/vi/CoBlWB2_VJY/maxresdefault.jpg",
    "publishedAt": "2020-02-04T06:01:49Z",
    "content": "SPURS at CLIPPERS | FULL GAME HIGHLIGHTS | February 3, 2020\r\nThe L.A. Clippers defeated the San Antonio Spurs, 108-105. Kawhi Leonard recorded 22 PTS, 6 REB and 7 AST for the Clippers, while Paul George added 19 PTS, a season-high 12 REB, and 8 AST in the vic… [+487 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580796109000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "TIMBERWOLVES at KINGS | FULL GAME HIGHLIGHTS | February 3, 2020 - NBA",
    "description": "TIMBERWOLVES at KINGS | FULL GAME HIGHLIGHTS | February 3, 2020 The Sacramento Kings defeated the Minnesota Timberwolves, 113-109. De’Aaron Fox led the way f...",
    "url": "https://www.youtube.com/watch?v=K6Y-5CZNMd0",
    "urlToImage": "https://i.ytimg.com/vi/K6Y-5CZNMd0/maxresdefault.jpg",
    "publishedAt": "2020-02-04T05:51:01Z",
    "content": null,
    "country": "ph",
    "category": "sports",
    "datetime": 1580795461000
}, {
    "source": {
        "id": null,
        "name": "Spin.ph"
    },
    "author": null,
    "title": "PBA News: Poy Erram, AC Soberano lead way as NLEX beats Korea University - Sports Interactive Network Philippines",
    "description": "Poy Erram, AC Soberano lead way as NLEX beats Korea University",
    "url": "https://www.spin.ph/basketball/pba/ac-soberano-shines-as-nlex-beats-korea-university-in-tuneup-match-a795-20200204",
    "urlToImage": "http://contents.spin.ph/image/resize/image/2020/02/04/ac-soberano-ja-1580792019.webp",
    "publishedAt": "2020-02-04T04:58:42Z",
    "content": "NLEX won over Korea University, 88-78, on Tuesday in a tune-up game at The Upper Deck.\r\nPoy Erram led the Road Warriors with 21 points.\r\nRookie AC Soberano was also a bright spot for NLEX as he had 12 points, and Jericho Cruz picked up 10 points for the Road … [+195 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580792322000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "The most unbelievable shots from the 2020 Australian Open - Australian Open TV",
    "description": "The most bonkers, unbelievable, 'wish you were there' shots from AO20",
    "url": "https://www.youtube.com/watch?v=WuYwPzKXAdU",
    "urlToImage": "https://i.ytimg.com/vi/WuYwPzKXAdU/maxresdefault.jpg",
    "publishedAt": "2020-02-04T04:36:35Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580790995000
}, {
    "source": {
        "id": "bleacher-report",
        "name": "Bleacher Report"
    },
    "author": "Scott Polacek",
    "title": "Robert Covington Trade Rumors: Clippers Engaged in Ongoing Talks for T-Wolves F - Bleacher Report",
    "description": "The  Los Angeles Clippers  are reportedly among the number of teams that are interested in  Minnesota Timberwolves  forward  Robert Covington  leading up to Thursday's trade deadline...",
    "url": "https://bleacherreport.com/articles/2874630-robert-covington-trade-rumors-clippers-engaged-in-ongoing-talks-for-t-wolves-f",
    "urlToImage": "https://img.bleacherreport.net/img/images/photos/003/850/795/hi-res-3ef40922d94fb5c4344024c0c107c54a_crop_exact.jpg?w=1200&h=1200&q=75",
    "publishedAt": "2020-02-04T04:08:16Z",
    "content": "Andy Clayton-King/Associated Press\r\nThe Los Angeles Clippers are reportedly among the number of teams that are interested in Minnesota Timberwolves forward Robert Covington leading up to Thursday's trade deadline.\r\nAccording to Sean Deveney of Heavy.com, the … [+1494 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580789296000
}, {
    "source": {
        "id": null,
        "name": "Pippenainteasy.com"
    },
    "author": "Andrew Miller",
    "title": "Chicago Bulls: 2020 Trade Deadline wish list - Pippen Ain't Easy",
    "description": "The main goals at hand for the Chicago Bulls entering the 2020 trade deadline should be to continue the progression of the rebuild and stack draft capital....",
    "url": "https://pippenainteasy.com/2020/02/03/chicago-bulls-2020-trade-deadline-wish-list/",
    "urlToImage": "https://imagesvc.timeincapp.com/v3/fan/image?url=https://pippenainteasy.com/wp-content/uploads/getty-images/2016/04/1198213662.jpeg&",
    "publishedAt": "2020-02-04T03:44:00Z",
    "content": "Chicago Bulls (Photo by Anatoliy Cherkasov/NurPhoto via Getty Images)\r\nLess than one week away now from the 2020 NBA trade deadline, the Chicago Bulls are likely to assume the role of sellers. Theyve had an up and down run since the turn of the calendar year,… [+1288 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580787840000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "PISTONS at GRIZZLIES | FULL GAME HIGHLIGHTS | February 3, 2020 - NBA",
    "description": "PISTONS at GRIZZLIES | FULL GAME HIGHLIGHTS | February 3, 2020 The Memphis Grizzlies defeated the Detroit Pistons, 96-82. Jonas Valanciunas recorded 26 PTS, ...",
    "url": "https://www.youtube.com/watch?v=Z1oFUD8fzSQ",
    "urlToImage": "https://i.ytimg.com/vi/Z1oFUD8fzSQ/maxresdefault.jpg",
    "publishedAt": "2020-02-04T03:21:52Z",
    "content": "Sign in to report inappropriate content.\r\nSign in",
    "country": "ph",
    "category": "sports",
    "datetime": 1580786512000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "PH tennis star eyes next Juniors Grand Slams - CNN Philippines",
    "description": "Filipino tennis star Alex Eala is looking forward to competing in another Grand Slam Tournament. That's after she won a Junior Doubles title in the recently ...",
    "url": "https://www.youtube.com/watch?v=cP5aTKJ5yGo",
    "urlToImage": "https://i.ytimg.com/vi/cP5aTKJ5yGo/maxresdefault.jpg",
    "publishedAt": "2020-02-04T03:13:17Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580785997000
}, {
    "source": {
        "id": null,
        "name": "Atptour.com"
    },
    "author": null,
    "title": "ATP Results: Carlos Taberner Upsets Fernando Verdasco In Cordoba - ATP Tour",
    "description": "World No. 198 Carlos Taberner sprung Monday’s biggest upset at the Cordoba Open, defeating seventh seed Fernando Verdasco 4-6, 6-1, 6-4 after one hour and 48 minutes to earn just his second ATP Tour victory.",
    "url": "https://www.atptour.com/en/news/verdasco-cuevas-cordoba-2020-monday",
    "urlToImage": "www.atptour.com/-/media/images/news/2020/02/04/02/50/taberner-cordoba-2020-monday.jpg",
    "publishedAt": "2020-02-04T03:07:14Z",
    "content": "World No. 198 Carlos Taberner sprung Monday’s biggest upset at the Cordoba Open, defeating seventh seed Fernando Verdasco 4-6, 6-1, 6-4 after one hour and 48 minutes to earn just his second ATP Tour victory.\r\nThe qualifier was competing in his first tour-leve… [+1337 chars]",
    "country": "ph",
    "category": "sports",
    "datetime": 1580785634000
}, {
    "source": {
        "id": "the-verge",
        "name": "The Verge"
    },
    "author": "Tom Warren",
    "title": "Google admits it sent private videos in Google Photos to strangers - The Verge",
    "description": "Google has revealed it accidentally sent some private videos stored in Google Photos to strangers. The mishap happened for five days last year, and has since been fixed.",
    "url": "https://www.theverge.com/2020/2/4/21122044/google-photos-privacy-breach-takeout-data-video-strangers",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/x5bPoUvbJhKWBIxX7LV2j_Bpi_8=/0x146:2040x1214/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19287010/acastro_191014_1777_google_pixel_0005.0.jpg",
    "publishedAt": "2020-02-04T09:37:30Z",
    "content": "The privacy breach affected a small number of Google Photos users\r\nIllustration by Alex Castro / The Verge\r\nGoogle is alerting some users of its Google Photos service that theyve had their private videos sent to strangers by the search giant. Googles Takeout … [+1209 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580809050000
}, {
    "source": {
        "id": null,
        "name": "Androidauthority.com"
    },
    "author": null,
    "title": "Deal: LG G7 ThinQ is a steal for under $300 from Amazon - Android Authority",
    "description": "You're getting wireless charging, quad DAC hardware, and IP68 water/dust resistance for the price.",
    "url": "https://www.androidauthority.com/lg-g7-thinq-deal-amazon-1080061/",
    "urlToImage": "https://cdn57.androidauthority.net/wp-content/uploads/2018/05/LG-G7-Review-2-920x470.jpg",
    "publishedAt": "2020-02-04T09:27:34Z",
    "content": "Amazon\r\nOlder high-end phones are a sure-fire way to get a feature-filled smartphone experience at a cheaper price, and the LG G7 made our list of older flagships still worth buying today.\r\nAmazon and LG are sweetening the deal even more though, as the LG G7 … [+961 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580808454000
}, {
    "source": {
        "id": null,
        "name": "Inquirer.net"
    },
    "author": "Cha Lino",
    "title": "Artist creates traffic jams on Google Maps - INQUIRER.net",
    "description": "An artist placed 99 secondhand smartphones in a cart and walked around Germany to create a virtual traffic jam in Google Maps.",
    "url": "https://www.inquirer.net",
    "urlToImage": "https://technology.inquirer.net/files/2020/02/Screen-Shot-2020-02-04-at-4.07.21-PM-620x345.png",
    "publishedAt": "2020-02-04T09:14:00Z",
    "content": "Simon Weckert’s “Google Maps Hacks”. Image: Twitter/@simon_deliver\r\nAn artist in Germany put to the test how Google Maps affects its users way of life by creating virtual traffic jams through 99 smartphones in a cart. \r\nSimon Weckert, a Berlin-based artist, w… [+2799 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580807640000
}, {
    "source": {
        "id": "the-verge",
        "name": "The Verge"
    },
    "author": "Sam Byford",
    "title": "Xiaomi spin-off Poco returns with the 120Hz X2 for $225 - The Verge",
    "description": "Xiaomi spin-off Poco has launched its second phone, the Poco X2. It’s another attempt from the company to produce a high-performance, low-cost phone for the extremely competitive Indian market.",
    "url": "https://www.theverge.com/2020/2/4/21122022/xiaomi-poco-x2-announced-price-specs-realme-redmi-k30",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/f0LYr0CTk71mdNACjVgkt-fSYYI=/0x170:2524x1491/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19683159/EP6arUcUYAEiDrD.jpeg",
    "publishedAt": "2020-02-04T08:10:58Z",
    "content": "Poco is aiming directly at Realme\r\nThe Poco X2 and its spec sheet\r\nPoco\r\nXiaomi spin-off brand Poco has launched its second phone, the Poco X2. Its another attempt from the company to produce a high-performance, low-cost phone for the extremely competitive In… [+3438 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580803858000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "This Is An E-Bike For E-Bike Haters | Specialized's 16.9kg Turbo Levo SL - BikeRadar",
    "description": "While most full-suspension e-bikes weigh well over 20 kg, the new striped-down Specialized Turbo Levo SL weighs as little as 16.9 kg (S-Works model, size sma...",
    "url": "https://www.youtube.com/watch?v=cu3Hu4VZDNw",
    "urlToImage": "https://i.ytimg.com/vi/cu3Hu4VZDNw/maxresdefault.jpg",
    "publishedAt": "2020-02-04T08:00:09Z",
    "content": null,
    "country": "ph",
    "category": "technology",
    "datetime": 1580803209000
}, {
    "source": {
        "id": null,
        "name": "9to5google.com"
    },
    "author": null,
    "title": "Google app 10.95 preps unified Assistant settings, dark theme tweaks [APK Insight] - 9to5Google",
    "description": "The latest beta of the Google app rolled out this evening with continued development on a handful of features that we've been tracking. Google app 10.95...",
    "url": "https://9to5google.com/2020/02/03/google-app-10-95-apk-insight-teardown/",
    "urlToImage": "https://9to5google.com/wp-content/uploads/sites/4/2020/02/APK-Insight-Google-App-10-95.jpg?resize=1024,512",
    "publishedAt": "2020-02-04T07:34:00Z",
    "content": "The latest beta version of the Google app rolled out this evening with continued development on a handful of features that we’ve been tracking. Google app 10.95 provides our first look at Hey Google sensitivity and a unified Assistant settings list. There are… [+2671 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580801640000
}, {
    "source": {
        "id": null,
        "name": "Androidauthority.com"
    },
    "author": null,
    "title": "Here's why Xiaomi hasn't delivered a 100W charging phone just yet - Android Authority",
    "description": "It seems like battery degradation is the biggest reason why 100W charging isn't on the market just yet.",
    "url": "https://www.androidauthority.com/xiaomi-100w-charging-degradation-1080016/",
    "urlToImage": "https://cdn57.androidauthority.net/wp-content/uploads/2019/03/xiaomi-100-watt-charging-comparison-weibo-920x470.jpg",
    "publishedAt": "2020-02-04T07:27:59Z",
    "content": "Weibo/Bin Lin\r\nXiaomi made waves almost a year ago when it revealed that it was working on 100W charging technology, capable of charging a 4,000mAh battery in 17 minutes. The company said Redmi phones would get the tech first, but we haven’t heard anything el… [+1403 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580801279000
}, {
    "source": {
        "id": "the-verge",
        "name": "The Verge"
    },
    "author": "Sam Byford",
    "title": "PlayStation 4 sales are slowing as PS5 looms this year - The Verge",
    "description": "Sony’s PlayStation 4 sales were down 25 percent year on year this holiday season, as the company prepares for the 2020 launch of the PS5.",
    "url": "https://www.theverge.com/2020/2/4/21122005/ps4-sales-sony-earnings-q3-2019-ps5",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/m6RJCCL9rgTbH3aefb8YSIQOTxI=/0x146:2040x1214/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19683131/IMG_1561.jpg",
    "publishedAt": "2020-02-04T07:00:14Z",
    "content": "Down 25 percent year on year\r\nSonys PlayStation 4 sales were down 25 percent year on year this holiday season, with the company shipping 6.1 million units for a total of 108.9 million as of the end of 2019. Its the lowest holiday quarter for the PS4 since its… [+1428 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580799614000
}, {
    "source": {
        "id": null,
        "name": "Gsmarena.com"
    },
    "author": "Sagar",
    "title": "Unlocked Samsung Galaxy S9+ gets Android 10 in the US - GSMArena.com news - GSMArena.com",
    "description": "The update weighs around 1.9GB in size and comes with January 2020 Android security patch.",
    "url": "https://www.gsmarena.com/samsung_galaxy_s9_s9_plus_android_10_us_unlocked-news-41352.php",
    "urlToImage": "https://fdn.gsmarena.com/imgroot/news/19/12/samsung-galaxy-s9-duo-fourth-android-10-beta/-476x249w4/gsmarena_002.jpg",
    "publishedAt": "2020-02-04T06:54:01Z",
    "content": "Samsung released the Android 10-based One UI 2.0 update for the Galaxy S9 and S9+ last week in the US, but only for the carrier-locked units. Now, the company has expanded the rollout for the unlocked S9+ units as well.\r\nThe firmware for the unlocked units sp… [+462 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580799241000
}, {
    "source": {
        "id": null,
        "name": "Slashgear.com"
    },
    "author": "Ewdison Then",
    "title": "Motorla Razr first impressions are unflattering - SlashGear",
    "description": "Although the Galaxy Z Flip has been rumored far longer, Motorola beat Samsung to the punch by announcing and launching its reborn Razr clamshell ahead of time. Motorola and parent Lenovo have admit…",
    "url": "https://www.slashgear.com/motorla-razr-first-impressions-are-unflattering-03608357/",
    "urlToImage": "https://scdn.slashgear.com/wp-content/uploads/2020/02/motorola-razr-2019-69.jpg",
    "publishedAt": "2020-02-04T03:16:49Z",
    "content": "Although the Galaxy Z Flip has been rumored far longer, Motorola beat Samsung to the punch by announcing and launching its reborn Razr clamshell ahead of time. Motorola and parent Lenovo have admittedly been playing around foldables just as long as anyone els… [+1571 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580786209000
}, {
    "source": {
        "id": null,
        "name": "Androidauthority.com"
    },
    "author": "https://www.facebook.com/browncscott",
    "title": "Realme TV could be on the way, likely at MWC 2020 - Android Authority",
    "description": "If it does land, it probably would be mostly for the Indian market.",
    "url": "https://www.androidauthority.com/realme-tv-1079823/",
    "urlToImage": "https://cdn57.androidauthority.net/wp-content/uploads/2019/07/realme-3i-review-phone-logo-920x470.jpg",
    "publishedAt": "2020-02-04T02:00:25Z",
    "content": "Realme has been releasing a steady stream of highly-regarded smartphones (and some mobile accessories) for just under two years now. It appears the company is ready to expand its portfolio significantly in 2020, and a Realme TV could be one of the first new p… [+1091 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580781625000
}, {
    "source": {
        "id": null,
        "name": "Cnnphilippines.com"
    },
    "author": null,
    "title": "Somewhere, someone is still using a Blackberry phone. They're about to be very disappointed - CNN Philippines",
    "description": "Sorry, BlackBerry fans. The iconic, full-keyboard smartphones may be disappearing once again.",
    "url": "http://cnnphilippines.com/business/2020/2/4/BlackBerry-stop-sales.html",
    "urlToImage": "http://cnnphilippines.com/.imaging/mte/demo-cnn-new/750x450/dam/cnn/2020/2/4/BlackBerry-Smartphone_CNNPH.jpg/jcr:content/BlackBerry-Smartphone_CNNPH.jpg",
    "publishedAt": "2020-02-04T01:57:12Z",
    "content": "(CNN)  Sorry, BlackBerry fans. The iconic, full-keyboard smartphones may be disappearing once again.\r\nTCL Communication, the electronics company that has been making BlackBerry smartphones, said Monday that the partnership has ended and it will stop selling B… [+2320 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580781432000
}, {
    "source": {
        "id": "google-news",
        "name": "Google News"
    },
    "author": null,
    "title": "Mortal Kombat: Every Character Confirmed For The Movie Reboot - Screen Rant",
    "description": null,
    "url": "https://news.google.com/__i/rss/rd/articles/CBMiR2h0dHBzOi8vc2NyZWVucmFudC5jb20vbW9ydGFsLWtvbWJhdC1tb3ZpZS1yZWJvb3QtY2hhcmFjdGVycy1jb25maXJtZWQv0gFLaHR0cHM6Ly9zY3JlZW5yYW50LmNvbS9tb3J0YWwta29tYmF0LW1vdmllLXJlYm9vdC1jaGFyYWN0ZXJzLWNvbmZpcm1lZC9hbXAv?oc=5",
    "urlToImage": null,
    "publishedAt": "2020-02-04T01:16:38Z",
    "content": null,
    "country": "ph",
    "category": "technology",
    "datetime": 1580778998000
}, {
    "source": {
        "id": null,
        "name": "Macrumors.com"
    },
    "author": "Juli Clover",
    "title": "Apple TV App Now Available on Select 2019 LG TVs - MacRumors",
    "description": "LG today announced that the Apple TV app and accompanying Apple TV+ streaming service are now available on select 2019 LG TVs in the United States...",
    "url": "https://www.macrumors.com/2020/02/03/apple-tv-app-select-2019-lg-tvs/",
    "urlToImage": "https://images.macrumors.com/article-new/2020/02/lgtvsappletvapp.jpg",
    "publishedAt": "2020-02-04T01:16:00Z",
    "content": "LG today announced that the Apple TV app and accompanying ‌Apple TV‌+ streaming service are now available on select 2019 LG TVs in the United States and more than 80 other countries.\r\nThe addition of the ‌Apple TV‌ app to LG's 2019 TV lineup follows the CES d… [+880 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580778960000
}, {
    "source": {
        "id": null,
        "name": "Sciencealert.com"
    },
    "author": "David Nield",
    "title": "New Research Explains How Solar Panels Could Soon Be Generating Power at Night - ScienceAlert",
    "description": "As beneficial as current solar panel technology has been in our quest to switch to renewable energy, such panels can't generate electricity at night. Now, new research suggests it could be possible to design panels that can operate around the clock.",
    "url": "https://www.sciencealert.com/here-s-how-solar-panels-could-soon-be-generating-power-at-night",
    "urlToImage": "https://www.sciencealert.com/images/2020-02/processed/012-solar-panel-night_1024.jpg",
    "publishedAt": "2020-02-04T01:14:09Z",
    "content": "As beneficial as current solar panel technology has been in our quest to switch to renewable energy, such panels can't generate electricity at night. Now, new research suggests it could be possible to design panels that can operate around the clock.\r\nUnder op… [+2918 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580778849000
}, {
    "source": {
        "id": null,
        "name": "Kotaku.com"
    },
    "author": "Riley MacLeod",
    "title": "Fortnite Players Divided Over Whether Streamer Cheated In Charity Tournament - Kotaku",
    "description": "Streamer Nicholas “NickEh30” Amyoony has been accused of cheating during a Fortnite game in last week’s charity Twitch Rivals Streamer Bowl. In a clip circulating online, Nick and his duos partner, NFL player David Morgan, can be heard discussing what sounds …",
    "url": "https://kotaku.com/fortnite-players-divided-over-whether-streamer-cheated-1841436221",
    "urlToImage": "https://i.kinja-img.com/gawker-media/image/upload/c_fill,f_auto,fl_progressive,g_center,h_675,pg_1,q_80,w_1200/io6xlnqibikngnxopa5d.png",
    "publishedAt": "2020-02-04T00:30:00Z",
    "content": "Streamer Nicholas NickEh30 Amyoony has been accused of cheating during a Fortnite game in last weeks charity Twitch Rivals Streamer Bowl. In a clip circulating online, Nick and his duos partner, NFL player David Morgan, can be heard discussing what sounds lik… [+4988 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580776200000
}, {
    "source": {
        "id": null,
        "name": "Kotaku.com"
    },
    "author": "Luke Plunkett",
    "title": "WarCraft 3's Remaster Is So Unpopular Blizzard Is Offering Instant Refunds [Update: Blizzard Responds] - Kotaku",
    "description": "So loud has  uproar among fans been, and so damning the shortfalls of the project that Blizzard has begun offering instant refunds to anyone who bought WarCraft 3: Reforged.",
    "url": "https://kotaku.com/warcraft-3s-remake-is-so-bad-blizzard-is-offering-insta-1841434474",
    "urlToImage": "https://i.kinja-img.com/gawker-media/image/upload/c_fill,f_auto,fl_progressive,g_center,h_675,pg_1,q_80,w_1200/ckvgf6xmijzirhzeonqt.jpg",
    "publishedAt": "2020-02-04T00:00:00Z",
    "content": "So loud has uproar among fans been, and so damning the shortfalls of the project that Blizzard has begun offering instant refunds to anyone who bought WarCraft 3: Reforged.Normally refunds have to go through a process of actually finding out what was wrong wi… [+4431 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580774400000
}, {
    "source": {
        "id": "google-news",
        "name": "Google News"
    },
    "author": null,
    "title": "Temtem Permanently Bans 900 Player Accounts | Screen Rant - Screen Rant",
    "description": null,
    "url": "https://news.google.com/__i/rss/rd/articles/CBMiSmh0dHBzOi8vc2NyZWVucmFudC5jb20vdGVtdGVtLWRldmVsb3Blci1iYW5zLTkwMC1wbGF5ZXJzLWNoZWF0aW5nLWFwcGVhbHMv0gFOaHR0cHM6Ly9zY3JlZW5yYW50LmNvbS90ZW10ZW0tZGV2ZWxvcGVyLWJhbnMtOTAwLXBsYXllcnMtY2hlYXRpbmctYXBwZWFscy9hbXAv?oc=5",
    "urlToImage": null,
    "publishedAt": "2020-02-03T23:58:23Z",
    "content": null,
    "country": "ph",
    "category": "technology",
    "datetime": 1580774303000
}, {
    "source": {
        "id": null,
        "name": "Gematsu.com"
    },
    "author": "Sal Romano",
    "title": "Hero Must Die. Again launches February 26 for PS4 and PC, February 27 for Switch - Gematsu",
    "description": "class=”alignnone size-full wp-image-307033″ /> Hero Must Die. Again will launch for PlayStation 4 and PC via Steam on February 26, and for Switch on February 27, publisher Degica Games announced. It will support English and Japanese language options. Here is …",
    "url": "https://www.gematsu.com/2020/02/hero-must-die-again-launches-february-26-for-ps4-and-pc-february-27-for-switch",
    "urlToImage": "https://www.gematsu.com/wp-content/uploads/2020/02/Hero-Must-Die-Again_02-03-20.jpg",
    "publishedAt": "2020-02-03T23:54:13Z",
    "content": "class=alignnone size-full wp-image-307033 /&gt;\r\nHero Must Die. Again will launch for PlayStation 4 and PC via Steam on February 26, and for Switch on February 27, publisher Degica Games announced. It will support English and Japanese language options. \r\nHere… [+1226 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580774053000
}, {
    "source": {
        "id": null,
        "name": "9to5google.com"
    },
    "author": null,
    "title": "Kate Spade Sport Review: A compact Wear OS smartwatch w/ customization at its core - 9to5Google",
    "description": "Kate Spade is under Fossil's umbrella of Wear OS smartwatches, but unlike many of them the Sport appeals to women with some handy customization too.",
    "url": "https://9to5google.com/2020/02/03/kate-spade-sport-review-wear-os/",
    "urlToImage": "https://9to5google.com/wp-content/uploads/sites/4/2020/02/kate_spade_sport_wear_os_1.jpg?resize=1024,512",
    "publishedAt": "2020-02-03T23:45:00Z",
    "content": "Unlike Android, Googles Wear OS is pretty locked down to OEM customization, but thankfully, apps and watchfaces can help make one watch unique when compared to others. For the past several weeks, Ive been able to see through my wifes usage how the Kate Spade … [+4986 chars]",
    "country": "ph",
    "category": "technology",
    "datetime": 1580773500000
}, {
    "source": {
        "id": "reuters",
        "name": "Reuters"
    },
    "author": "Kevin Yao",
    "title": "Exclusive: As virus fallout widens, China readies more measures to stabilize economy - sources - Reuters",
    "description": "Chinese policymakers are readying measures to support an economy jolted by a coronavirus outbreak that is expected to have a devastating impact on first-quarter growth, policy sources said.",
    "url": "https://www.reuters.com/article/us-china-health-economy-exclusive-idUSKBN1ZY103",
    "urlToImage": "https://s4.reutersmedia.net/resources/r/?m=02&d=20200204&t=2&i=1485623062&w=1200&r=LYNXMPEG130N8",
    "publishedAt": "2020-02-04T09:24:00Z",
    "content": "BEIJING (Reuters) - Chinese policymakers are readying measures to support an economy jolted by a coronavirus outbreak that is expected to have a devastating impact on first-quarter growth, policy sources said. \r\nThe sources said the government is debating whe… [+4854 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580808240000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Coronavirus cases surpass 20000 in China, continues to spread worldwide - ARIRANG NEWS",
    "description": "중국 신종코로나 두달만에 사망 420명•확진 2만명 넘어서 The daily number of deaths reported in China is getting bigger and bigger. With those announced early this morning, the tota...",
    "url": "https://www.youtube.com/watch?v=xbYAdVbDjzM",
    "urlToImage": "https://i.ytimg.com/vi/xbYAdVbDjzM/maxresdefault.jpg",
    "publishedAt": "2020-02-04T08:09:08Z",
    "content": "420 2 \r\nThe daily number of deaths reported in China is getting bigger and bigger.With those announced early this morning, the total is now more than 420.A person in Hong Kong has also died from the virus,... only the second death outside of the Chinese mainl… [+1575 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580803748000
}, {
    "source": {
        "id": "cnbc",
        "name": "CNBC"
    },
    "author": "Sam Meredith",
    "title": "BP full-year net profit falls 21% on weak oil and gas prices - CNBC",
    "description": "Energy giant BP reported stronger-than-anticipated full-year net profit on Tuesday.",
    "url": "https://www.cnbc.com/2020/02/04/bp-earnings-q4-2019.html",
    "urlToImage": "https://image.cnbcfm.com/api/v1/image/103353975-GettyImages-169952811.jpg?v=1532564193",
    "publishedAt": "2020-02-04T07:04:00Z",
    "content": "Energy giant BP reported better-than-expected full-year net profit on Tuesday, outperforming analyst expectations despite lower oil and gas prices.\r\nThe U.K.-based oil and gas company posted full-year underlying replacement cost profit, used as a proxy for ne… [+3433 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580799840000
}, {
    "source": {
        "id": null,
        "name": "Yahoo.com"
    },
    "author": null,
    "title": "Elon Musk Getting Richer Faster Than Any Other Billionaire This Year - Yahoo Finance",
    "description": "Tesla Inc. (NASDAQ: TSLA ) founder and chief executive officer Elon Musk is getting richer faster than any other billionaire in 2020 so far. What Happened Musk has added $13.5 billion to his net worth ...",
    "url": "https://finance.yahoo.com/news/elon-musk-getting-richer-faster-034405741.html",
    "urlToImage": "https://s.yimg.com/cv/apiv2/social/images/yahoo_default_logo.png",
    "publishedAt": "2020-02-04T06:50:34Z",
    "content": "Tesla Inc. (NASDAQ: TSLA) founder and chief executive officer Elon Musk is getting richer faster than any other billionaire in 2020 so far.\r\nWhat Happened\r\nMusk has added $13.5 billion to his net worth this year by Monday, according to the Bloomberg Billionai… [+1593 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580799034000
}, {
    "source": {
        "id": null,
        "name": "Hollywoodreporter.com"
    },
    "author": "Gavin J. Blair",
    "title": "Sony Film Unit Posts $51M Quarterly Profit, Down 50 Percent - Hollywood Reporter",
    "description": "Overall revenue at Sony Corp. was up 3 percent at $22.6 billion, while operating profit was down 20 percent at $2.76 billion. Net profit for the October-to-December quarter was down 46 percent to $2.1 billion.",
    "url": "https://www.hollywoodreporter.com/news/sony-film-unit-posts-51m-quarterly-profit-down-50-percent-1276170",
    "urlToImage": "https://cdn1.thr.com/sites/default/files/2019/08/jumanji_the_next_level_-_publicity_still_2-_h_2019.jpg",
    "publishedAt": "2020-02-04T06:12:21Z",
    "content": "Sony's film unit recorded a $51 million (6.2 billion yen) profit for the October-to-December quarter, down from $107 million in the same quarter the previous year.\r\nSales for the division were down 12 percent to $2.17 billion.\r\nJumanji: The Next Level, which … [+2332 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580796741000
}, {
    "source": {
        "id": null,
        "name": "Investing.com"
    },
    "author": null,
    "title": "Stocks firmer as China's markets recoup some virus losses - Investing.com",
    "description": "Stocks firmer as China's markets recoup some virus losses",
    "url": "https://www.investing.com/news/stock-market-news/asia-shares-fragile-amid-china-worries-oil-sinks-2075006",
    "urlToImage": "https://i-invdn-com.akamaized.net/trkd-images/LYNXMPEG1305Z_L.jpg",
    "publishedAt": "2020-02-04T06:05:00Z",
    "content": "By Wayne Cole and Tomo Uetake\r\nSYDNEY/TOKYO (Reuters) - Asian stocks bounced on Tuesday with Chinese markets reversing some of their previous plunge amid official efforts to calm virus fears, although investor sentiment remained fragile with oil near 13-month… [+4750 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580796300000
}, {
    "source": {
        "id": null,
        "name": "Yahoo.com"
    },
    "author": null,
    "title": "Tesla's battery supplier stocks surge on Panasonic's first Gigafactory profit - Yahoo Finance",
    "description": "TOKYO/SEOUL (Reuters) - Tesla Inc shares and those of its Asian battery suppliers rallied sharply after Panasonic Corp said its automotive battery venture with Tesla was in the black for the first time.  Tesla itself soared 20% on Monday in its largest one-da…",
    "url": "https://finance.yahoo.com/news/teslas-battery-supplier-stocks-surge-031048577.html",
    "urlToImage": "https://s.yimg.com/uu/api/res/1.2/r9m0sYhzOGmkhhucEuqvjA--~B/aD01NDY7dz04MDA7c209MTthcHBpZD15dGFjaHlvbg--/https://media.zenfs.com/en-US/reuters.com/9b749a1ea5982272cb92795e5fa0a9be",
    "publishedAt": "2020-02-04T03:21:38Z",
    "content": "By Makiko Yamazaki and Hyunjoo Jin\r\nTOKYO/SEOUL (Reuters) - Tesla Inc shares and those of its Asian battery suppliers rallied sharply after Panasonic Corp said its automotive battery venture with Tesla was in the black for the first time.\r\nTesla itself soared… [+2679 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580786498000
}, {
    "source": {
        "id": null,
        "name": "Vulture.com"
    },
    "author": "Dan Reilly",
    "title": "Everything to Know About McMillion$ and the McDonald’s Monopoly Game Scam - Vulture",
    "description": "An infamous con that involved Florida men, Italian mobsters, Mormons, drug dealers, strip clubs, and a zany FBI sting.",
    "url": "http://www.vulture.com/2020/02/mcdonalds-monopoly-game-fraud-true-story.html",
    "urlToImage": "https://pixel.nymag.com/imgs/daily/vulture/2020/02/03/03-mcdonalds-monopoly-explainer.w1200.h630.jpg",
    "publishedAt": "2020-02-04T03:00:00Z",
    "content": "From 1989 to 2001, there were almost no legitimate winners of the high-value game pieces in the McDonalds Monopoly game. I mean, how crazy-bullshit is that?\r\nThats FBI Special Agent Doug Mathewss assessment of the $24 million fraud scheme thats the focus of H… [+11979 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580785200000
}, {
    "source": {
        "id": null,
        "name": "Channel3000.com"
    },
    "author": null,
    "title": "Madison area Hy-Vee locations to no longer be open 24 hours a day - Channel3000.com - WISC-TV3",
    "description": "Starting next week, all Madison area Hy-Vee locations will no longer be open 24 hours a day.",
    "url": "https://www.channel3000.com/madison-area-hy-vee-locations-to-no-longer-be-open-24-hours-a-day/",
    "urlToImage": "https://www.channel3000.com/content/uploads/2019/12/moneywatch-hy-vee-recall20170116132842_5612016_ver1-0.jpg",
    "publishedAt": "2020-02-04T02:56:00Z",
    "content": "Posted: February 3, 2020 8:56 PM\r\nMADISON, Wis. — Starting next week, all Madison area Hy-Vee locations will no longer be open 24 hours a day.\r\nBeginning Feb. 10, the three local grocery stores will now be open 5 a.m. until midnight, seven days a week.\r\nThe c… [+220 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580784960000
}, {
    "source": {
        "id": null,
        "name": "Yahoo.com"
    },
    "author": null,
    "title": "Alphabet shares fall as Google misses on sales, YouTube revenue disappoints - Yahoo Finance",
    "description": "Alphabet Inc's  new Chief Executive Sundar Pichai unveiled sales figures that investors have long demanded, but shares fell 5% as Google's advertising business and the new data about YouTube and Google Cloud broadly disappointed.  Pichai had sought to counter…",
    "url": "https://finance.yahoo.com/news/alphabet-shares-fall-google-misses-021109336.html",
    "urlToImage": "https://s.yimg.com/uu/api/res/1.2/ok0Oh3EnAEloPUeqrJ_fLQ--~B/aD01Mzg7dz04MDA7c209MTthcHBpZD15dGFjaHlvbg--/https://media.zenfs.com/en-US/reuters.com/7edf4f8fa78f551f1f1f5759f2db863d",
    "publishedAt": "2020-02-04T02:26:15Z",
    "content": "By Paresh Dave and Munsif Vengattil\r\nSAN FRANCISCO (Reuters) - Alphabet Inc's &lt;GOOGL.O&gt; new Chief Executive Sundar Pichai unveiled sales figures that investors have long demanded, but shares fell 5% as Google's advertising business and the new data abou… [+5165 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580783175000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Geneva Sands, CNN",
    "title": "At least one person turned away at US border as coronavirus travel restrictions implemented - CNN",
    "description": "A Canadian citizen was turned away at the northern border as a part of President Donald Trump's temporary ban on people who have visited China before their arrival in the United States, acting Homeland Security Deputy Secretary Ken Cuccinelli said Monday.",
    "url": "https://www.cnn.com/2020/02/03/politics/border-coronavirus-travel-restrictions/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200124123909-cbp-officer-file-super-tease.jpg",
    "publishedAt": "2020-02-04T02:22:00Z",
    "content": "(CNN)A Canadian citizen was turned away at the northern border as a part of President Donald Trump's temporary ban on people who have visited China before their arrival in the United States, acting Homeland Security Deputy Secretary Ken Cuccinelli said Monday… [+3386 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580782920000
}, {
    "source": {
        "id": "the-hill",
        "name": "The Hill"
    },
    "author": "John Bowden",
    "title": "Walgreens settles for $7.5M after employee charged with impersonating pharmacist | TheHill - The Hill",
    "description": "Walgreens has settled for $7.5 million with California authorities after a woman was charged with...",
    "url": "https://thehill.com/policy/healthcare/481303-walgreens-settles-for-75m-after-employee-charged-with-impersonating",
    "urlToImage": "https://thehill.com/sites/default/files/article_images/taxwalgreens_1.jpg",
    "publishedAt": "2020-02-04T02:12:15Z",
    "content": "Walgreens has settled for $7.5 million with California authorities after a woman was charged with impersonating a pharmacist at the store and illegally filling more than half a million prescriptions.\r\nThe Associated Press reported Monday that the settlement c… [+1272 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580782335000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Analysis by Joshua Berlinger, CNN Business",
    "title": "Six months of protests wrecked Hong Kong's economy. A virus scare is the last thing this city needs - CNN",
    "description": "Months of increasingly violent protests and a bruising US-China trade war pushed Hong Kong into a recession last year for the first time in a decade. Now the coronavirus outbreak threatens to derail things once again.",
    "url": "https://www.cnn.com/2020/02/03/business/hong-kong-economy-coronavirus-intl-hnk/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200130224820-01-coronavirus-hong-kong-0129-super-tease.jpg",
    "publishedAt": "2020-02-04T01:52:00Z",
    "content": null,
    "country": "us",
    "category": "business",
    "datetime": 1580781120000
}, {
    "source": {
        "id": null,
        "name": "Wthr.com"
    },
    "author": "https://www.facebook.com/WTHR13/",
    "title": "Amazon operations facility to bring 800 jobs to Greenfield - Business News - WTHR",
    "description": "The operations facility will receive and ship products to other Amazon fulfillment centers.",
    "url": "https://www.wthr.com/article/amazon-operations-facility-bring-800-jobs-greenfield",
    "urlToImage": "https://www.wthr.com/sites/default/files/styles/article_image/public/2020/01/27/obj_amazon_logo_ap_reed_saxon_web.jpg?itok=rmFH1sWH",
    "publishedAt": "2020-02-04T01:22:45Z",
    "content": "GREENFIELD, Ind. (WTHR) Amazon will be building a new operations facility in Greenfield.\r\nThe company told Eyewitness News on Monday that the facility would mean more than 800 full-time positions.\r\nThe operations facility will receive and ship products to oth… [+201 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580779365000
}, {
    "source": {
        "id": null,
        "name": "Newsbtc.com"
    },
    "author": null,
    "title": "Bitcoin is Brewing the Perfect Storm for a Parabolic Mid-2020 Rally - newsBTC",
    "description": "The confluence of multiple bullish factors does seem to suggest that a new Bitcoin (BTC) bull-favoring cycle is right around the corner.",
    "url": "https://www.newsbtc.com/2020/02/04/bitcoin-is-brewing-the-perfect-storm-for-a-parabolic-mid-2020-rally/",
    "urlToImage": "https://www.newsbtc.com/wp-content/uploads/2020/02/shutterstock_387639436-2-1200x780.jpg",
    "publishedAt": "2020-02-04T01:12:57Z",
    "content": "2020 has been Bitcoins year, with the cryptocurrency posting massive gains throughout January as bulls attempt to lay the groundwork for BTC to see parabolic gains throughout the rest of the year.\r\nIt is important to note that there is currently a multitude o… [+2800 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580778777000
}, {
    "source": {
        "id": null,
        "name": "Abc7ny.com"
    },
    "author": null,
    "title": "Delays persist for NJ Transit, Amtrak customers out of Penn Station - WABC-TV",
    "description": "Service is back to normal at New York's Penn Station after an outage caused rolling delays during the Monday evening rush.",
    "url": "https://abc7ny.com/5901586",
    "urlToImage": "https://cdn.abcotvs.com/dip/images/5901994_020320-wabc-pennstationdelays-img.jpg?w=1600",
    "publishedAt": "2020-02-04T01:08:42Z",
    "content": "NEW YORK (WABC) -- Service is back to normal at New York's Penn Station after an outage caused rolling delays during the Monday evening rush.Major delays impacted New Jersey Transit and Amtrak customers as commuters tried to get home.\r\nAmtrak said power was l… [+529 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580778522000
}, {
    "source": {
        "id": null,
        "name": "Yahoo.com"
    },
    "author": null,
    "title": "3 Dividend-Paying Stocks for Investors to Buy to Fight Off Market Uncertainty - Yahoo Finance",
    "description": "Check out these three dividend-paying stocks that investors might want to buy to help combat coronavirus-based market pullback fears...",
    "url": "https://finance.yahoo.com/news/3-dividend-paying-stocks-investors-000412781.html",
    "urlToImage": "https://s.yimg.com/uu/api/res/1.2/6OLWy6t6jQwzim8pIl3hPw--~B/aD00MDA7dz02MzU7c209MTthcHBpZD15dGFjaHlvbg--/https://media.zenfs.com/en-us/zacks.com/1b52d31540a4ef5a5795817baf5f79d2",
    "publishedAt": "2020-02-04T00:45:00Z",
    "content": "The Dow, S&amp;P 500, and Nasdaq all climbed Monday to help them bounce back from a tough Friday and a rough week. Clearly, coronavirus worries seem set to linger over global markets as investors wait for clarity about the spread and potential impact on econo… [+6555 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580777100000
}, {
    "source": {
        "id": null,
        "name": "Thepointsguy.com"
    },
    "author": "Zach Wichter",
    "title": "China Eastern, Hainan Airlines suspend U.S. flights over coronavirus concerns - The Points Guy",
    "description": "Chinese carriers China Eastern Airlines and Hainan Airlines have suspended some flights to North America as airlines across the globe scale back service to mainland China amid the coronavirus health scare. A collection of international airlines — including al…",
    "url": "http://thepointsguy.com/news/china-eastern-hainan-airlines-suspend-u-s-flights-over-coronavirus-concerns/",
    "urlToImage": "https://i2.wp.com/thepointsguy.com/wp-content/uploads/2018/11/A350-900-China-Eastern-take-off.jpg?fit=991%2C690px&ssl=1",
    "publishedAt": "2020-02-04T00:05:53Z",
    "content": "Chinese carriers China Eastern Airlines and Hainan Airlines have suspended some flights to North America as airlines across the globe scale back service to mainland China amid the coronavirus health scare.\r\nA collection of international airlines including all… [+2715 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580774753000
}, {
    "source": {
        "id": "cnbc",
        "name": "CNBC"
    },
    "author": "Tyler Clifford",
    "title": "Zoom Video Communications CEO says products are seeing 'record usage' as stock pops 15% amid coronavirus fears - CNBC",
    "description": "\"I had to shut down my phone, because, actually, almost everyone is calling us,\" given the coronavirus, Zoom Video Communications CEO Eric Yuan says.",
    "url": "https://www.cnbc.com/2020/02/03/zoom-video-is-seeing-record-usage-amid-coronavirus-fears-ceo-says.html",
    "urlToImage": "https://image.cnbcfm.com/api/v1/image/105860099-1555602062093rtx6s9mu.jpg?v=1555602142",
    "publishedAt": "2020-02-03T23:58:00Z",
    "content": "Zoom Video Communications CEO Eric Yuan told CNBC his phone was off the hook on Monday as the company's stock popped double digits.\r\nShares of the cloud-based video conferencing and collaboration provider surged nearly 15% during the trading day as the corona… [+2878 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580774280000
}, {
    "source": {
        "id": null,
        "name": "Wdbj7.com"
    },
    "author": "Kate Capodanno",
    "title": "Earth Fare employees shocked, worried about store closings - WDBJ7",
    "description": "Earth Fare employees will be out of a job within the next several weeks after the company announced it would be shutting down all 50 of its locations.",
    "url": "https://www.wdbj7.com/content/news/Earth-Fare-employees-shocked-worried-about-store-closings-567536661.html",
    "urlToImage": "https://media.graytvinc.com/images/020320+Earth+Fare.JPG",
    "publishedAt": "2020-02-03T23:57:43Z",
    "content": "ROANOKE, Va. (WDBJ7) - Earth Fare employees will be out of a job within the next several weeks after the company announced it would be shutting down all 50 of its locations.\r\nThe North Carolina based health and wellness supermarket made the announcement Monda… [+1541 chars]",
    "country": "us",
    "category": "business",
    "datetime": 1580774263000
}, {
    "source": {
        "id": null,
        "name": "Tmz.com"
    },
    "author": "TMZ Staff",
    "title": "R. Kelly's Ex Azriel Clary Diving Into Advocacy & Music to Help Others - TMZ",
    "description": "Azriel Clary plans to own her trauma and help others heal in the wake of R. Kelly.",
    "url": "https://www.tmz.com/2020/02/04/r-kelly-ex-girlfriend-azriel-clary-advocacy-abuse-org-music-future/",
    "urlToImage": "https://imagez.tmz.com/image/c8/16by9/2020/02/03/c8acae5d8e9444839f95275597f3bf01_xl.jpg",
    "publishedAt": "2020-02-04T08:50:00Z",
    "content": "R. Kelly's ex-girlfriend, Azriel Clary, already has the wheels in motion to not only help herself heal but to do the same for others ... and her plan includes multimedia and advocacy.\r\nTMZ has learned about the next steps Azriel plans to take as she recovers … [+1544 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580806200000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Will Arnett on Vaping, Being Honored in Canada & LEGO Masters - Jimmy Kimmel Live",
    "description": "Will talks about his terrible idea for a vape company, his prefabricated house, “BoJack Horseman,” Trump’s strange posture, getting a star on the Canada Walk...",
    "url": "https://www.youtube.com/watch?v=NABull8SODE",
    "urlToImage": "https://i.ytimg.com/vi/NABull8SODE/maxresdefault.jpg",
    "publishedAt": "2020-02-04T08:30:00Z",
    "content": "Will talks about his terrible idea for a vape company, his prefabricated house, BoJack Horseman, Trumps strange posture, getting a star on the Canada Walk of Fame, and his new show LEGO Masters.\r\nMean Tweets - NFL Edition #4 https://youtu.be/siIQ1jPtmEQ\r\nSUBS… [+1752 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580805000000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Lauren Edmonds Valerie Edwards For Dailymail.com",
    "title": "Parents slam J-Lo's and Shakira's halftime performances as inappropriate for kids - Daily Mail",
    "description": "Outraged parents blasted Jennifer Lopez and Shakira's sexy moves during the Super Bowl halftime performance as 'disgusting,' 'vulgar' and too provocative for children.",
    "url": "https://www.dailymail.co.uk/news/article-7964217/Parents-slam-J-Los-Shakiras-halftime-performances-inappropriate-kids.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/06/24281204-0-image-a-44_1580798403933.jpg",
    "publishedAt": "2020-02-04T07:16:00Z",
    "content": "Parents are outraged over Jennifer Lopez and Shakira's sexy Super Bowl LIV Halftime show, saying it was 'vulgar' and completely inappropriate for children.  \r\nShakira and J-Lo performed the much-hyped half-time show at the Hard Rock Stadium in Miami, Florida,… [+10957 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580800560000
}, {
    "source": {
        "id": null,
        "name": "Cheatsheet.com"
    },
    "author": "Connie Liou",
    "title": "BTS Reveals the Powerful Meaning Behind 'Map of the Soul: 7' - Showbiz Cheat Sheet",
    "description": "What BTS members RM and Suga have to say about the meaning behind the new album title for 'Map of the Soul: 7' ahead of the Feb. 21 release date.",
    "url": "https://www.cheatsheet.com/entertainment/bts-meaning-map-of-the-soul-7-new-album-title-black-swan.html/",
    "urlToImage": "https://www.cheatsheet.com/wp-content/uploads/2020/02/BTS-at-Grammy-Awards-2020-Red-Carpet-1024x683.jpg",
    "publishedAt": "2020-02-04T05:30:30Z",
    "content": "After months of sweaty palms at the stroke of midnight KST, BTS revealed the new album, Map of the Soul: 7, will be out on Friday, Feb. 21. The seven members — RM, Jin, Suga, J-Hope, Jimin, V, and Jungkook — previously dropped clues at multiple year-end shows… [+3814 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580794230000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "WINC Podcast (2/3): WWE RAW Review With Matt Morgan, XFL, Super ShowDown, Super Bowl - WrestlingINC",
    "description": "Matt Morgan (@BPmattmorgan), Raj Giri (@RajGiri_303), and Glenn Rubenstein (@GlennRubenstein) are back for the latest edition of the Wrestling Inc. podcast. ...",
    "url": "https://www.youtube.com/watch?v=Fa7vNOFyCoM",
    "urlToImage": "https://i.ytimg.com/vi/Fa7vNOFyCoM/hqdefault.jpg",
    "publishedAt": "2020-02-04T05:16:07Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580793367000
}, {
    "source": {
        "id": null,
        "name": "Cinemablend.com"
    },
    "author": "Mick Joest",
    "title": "America's Got Talent: The Champions' Are Angry And Confused Over One Finalist - CinemaBlend",
    "description": "America's Got Talent: The Champions has advanced someone to the finals the viewers feel is undeserving.",
    "url": "https://www.cinemablend.com/television/2489579/americas-got-talent-the-champions-are-angry-and-confused-over-one-finalist",
    "urlToImage": "https://img.cinemablend.com/quill/2/c/3/5/2/0/2c3520871af0af7e8b4b990e0b31bc0251dae4a6.jpg",
    "publishedAt": "2020-02-04T04:26:24Z",
    "content": "Warning! The following contains spoilers for the semi-finals round of America's Got Talent: The Champions. Read at your own risk!\r\nThe finale contestants have been announced for America's Got Talent: The Champions, and of course, fans are upset by some snubs.… [+4030 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580790384000
}, {
    "source": {
        "id": "entertainment-weekly",
        "name": "Entertainment Weekly"
    },
    "author": "Maureen Lee Lenker",
    "title": "Did the Oscars just predict the Oscars? - Entertainment Weekly News",
    "description": "The Academy of Motion Picture Arts and Sciences appeared to tweet out a list of predictions for its own ceremony, sending movie fans into a tizzy.",
    "url": "https://ew.com/oscars/2020/02/03/did-the-oscars-just-predict-the-oscars/",
    "urlToImage": "https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fewedit.files.wordpress.com%2F2020%2F01%2Fgettyimages-3105512.jpg%3Fcrop%3D0px%2C0px%2C3044px%2C1598.1px%26resize%3D1200%2C630",
    "publishedAt": "2020-02-04T03:30:00Z",
    "content": "And the Oscar goes to…\r\nWell, the Academy of Motion Picture Arts and Sciences appears to have some thoughts. On Monday afternoon, the organization tweeted a now-deleted photo with no caption that featured the title “My Oscar Predictions,” along with a list of… [+1484 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580787000000
}, {
    "source": {
        "id": null,
        "name": "Nypost.com"
    },
    "author": "Tamar Lapin",
    "title": "Trump pretends to conduct orchestra during Super Bowl national anthem - New York Post ",
    "description": "Oh, say can you see … the president goofing off during the national anthem? President Donald Trump was caught in a new video fidgeting, adjusting his chair and pretending to conduct a band du…",
    "url": "https://nypost.com/2020/02/03/trump-pretends-to-conduct-orchestra-during-super-bowl-national-anthem/",
    "urlToImage": "https://thenypost.files.wordpress.com/2020/02/200203-trump-national-anthem.jpg?quality=90&strip=all&w=1200",
    "publishedAt": "2020-02-04T02:46:00Z",
    "content": "Oh, say can you see … the president goofing off during the national anthem?\r\nPresident Donald Trump was caught in a new video fidgeting, adjusting his chair and pretending to conduct a band during the recitation of The Star-Spangled Banner Sunday at his Super… [+980 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580784360000
}, {
    "source": {
        "id": null,
        "name": "Cosmopolitan.com"
    },
    "author": "Jessica Pels",
    "title": "Why We’re Not Publishing the Cosmo ‘Bachelor’ Cover - Cosmopolitan.com",
    "description": "A letter from the editor.",
    "url": "https://www.cosmopolitan.com/entertainment/celebs/a30718890/cosmo-editor-in-chief-bachelor-challenge/",
    "urlToImage": "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/oped-jp-1580498552.png?crop=1.00xw:1.00xh;0,0&resize=1200:*",
    "publishedAt": "2020-02-04T02:19:00Z",
    "content": "If you’re watching The Bachelor tonight, you just saw me and a few key members of the Cosmo team put the contestants through a challenge that, for us, is basically another day at the office: a fashion shoot in extreme conditions under lots of pressure to beat… [+1984 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580782740000
}, {
    "source": {
        "id": "bleacher-report",
        "name": "Bleacher Report"
    },
    "author": "Kevin Berge",
    "title": "WWE Raw Results: Winners, Grades, Reaction and Highlights from February 3 - Bleacher Report",
    "description": "Why,  Randy Orton , why? This question has plagued the WWE Universe since the main event of Monday Night Raw during which The Viper heinously attacked his friend Edge.   The February 3 edition of Raw promised answers as well as plenty more action...",
    "url": "https://bleacherreport.com/articles/2873912-wwe-raw-results-winners-grades-reaction-and-highlights-from-february-3",
    "urlToImage": "https://img.bleacherreport.net/img/slides/photos/004/376/743/57617c9e1bdf93614f0e866c33ce37bb_crop_exact.jpg?w=1200&h=1200&q=75",
    "publishedAt": "2020-02-04T01:36:15Z",
    "content": "Credit: WWE.com\r\nSeth Rollins, Ricochet and Bobby Lashley were interviewed and promised to take the victory. Rollins also cut a promo before his match promising to win and go on to face Drew McIntyre at WrestleMania.\r\nThe One and Only got close to a victory, … [+897 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580780175000
}, {
    "source": {
        "id": null,
        "name": "Eonline.com"
    },
    "author": "McKenna Aiello",
    "title": "Justin Bieber on His Drug Abuse, Mental Illness & Lyme Disease Battle - E! NEWS",
    "description": "Justin Bieber appears alongside wife Hailey Bieber and several other members of his inner circle in his most revealing YouTube docu-series episode yet.",
    "url": "https://www.eonline.com/news/1119046/justin-bieber-details-drug-abuse-mental-illness-and-lyme-disease-battle-6-takeaways",
    "urlToImage": "https://akns-images.eonline.com/eol_images/Entire_Site/202013/rs_600x600-200203160812-600-Bieber-youtube-video-4.jpg?fit=around|600:467&crop=600:467;center,top&output-quality=90",
    "publishedAt": "2020-02-04T01:35:00Z",
    "content": "Justin Bieber won't let his past become the blueprint for his future. \r\nThe pop star appears alongside wife Hailey Bieber, manager Scooter Braun and several other members of his inner circle in the most revealing episode of his YouTube docu-series yet. Titled… [+769 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580780100000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Joaquin Phoenix Curtsies To Prince William In Chummy BAFTAs Moment We Can't Stop Watching - Access",
    "description": "Now this is the friendship we never knew we needed! Joaquin Phoenix proved he knows how to greet the royals when giving Prince William a curtsy during their ...",
    "url": "https://www.youtube.com/watch?v=AnM0EkevLe4",
    "urlToImage": "https://i.ytimg.com/vi/AnM0EkevLe4/maxresdefault.jpg",
    "publishedAt": "2020-02-04T01:32:35Z",
    "content": null,
    "country": "us",
    "category": "entertainment",
    "datetime": 1580779955000
}, {
    "source": {
        "id": "the-verge",
        "name": "The Verge"
    },
    "author": "Jay Peters",
    "title": "Quibi drops new trailers for Will Forte and Idris Elba shows ahead of April launch - The Verge",
    "description": "Quibi has released new teaser trailers for some of its shows that will launch in April. The shows star Will Forte, Kaitlin Olson, Idris Elba, and Kiefer Sutherland.",
    "url": "https://www.theverge.com/2020/2/3/21121385/quibi-new-trailers-for-shows-flipped-elba-vs-block-fugitive",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/hJXsXIFb9B4CHX3ZkpuOIUvjjl4=/0x0:1920x1005/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19682087/Screen_Shot_2020_02_03_at_5.04.28_PM.png",
    "publishedAt": "2020-02-04T01:32:31Z",
    "content": "The service launches on April 6th\r\nImage: Quibi\r\nShort-form video platform Quibi has released new teaser trailers on its YouTube channel that give a first look at some of the new shows coming to the mobile-focused streaming service. The trailers, as well as t… [+1574 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580779951000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Harvey Weinstein Trial: Accuser Has Panic Attack on the Stand - Variety",
    "description": "Jessica Mann — a key witness in Harvey Weinstein’s rape trial who alleges the former movie mogul raped her twice and sexually assaulted her on numerous occas...",
    "url": "https://www.youtube.com/watch?v=Htj-mLkvc7E",
    "urlToImage": "https://i.ytimg.com/vi/Htj-mLkvc7E/maxresdefault.jpg",
    "publishedAt": "2020-02-04T01:24:55Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580779495000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Billie Eilish RESPONDS To Drake Texting Her Controversy! Louis Tomlinson SLAMS Interviewer! (DHR) - Clevver News",
    "description": "More Celebrity News ►► http://bit.ly/SubClevverNews Sussan and Maddie have your daily roundup of today’s hottest stories from Billie Eilish RESPONDS To Drake...",
    "url": "https://www.youtube.com/watch?v=FKCrw1FWRSA",
    "urlToImage": "https://i.ytimg.com/vi/FKCrw1FWRSA/maxresdefault.jpg",
    "publishedAt": "2020-02-04T01:00:22Z",
    "content": "More Celebrity News http://bit.ly/SubClevverNewsSussan and Maddie have your daily roundup of todays hottest stories from Billie Eilish RESPONDS To Drake Texting Her Controversy to Louis Tomlinson SLAMS Interviewer! Get the scoop on the hottest topics right he… [+304 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580778022000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Final Oscar Predictions, Including a Parasite Shocker - For Your Consideration - Collider Videos",
    "description": "On this week’s For Your Consideration, it's time for Collider’s awards experts Scott Mantz, Perri Nemiroff and Jeff Sneider to offer their final Oscar predic...",
    "url": "https://www.youtube.com/watch?v=dUeHu7KD0c8",
    "urlToImage": "https://i.ytimg.com/vi/dUeHu7KD0c8/maxresdefault.jpg",
    "publishedAt": "2020-02-04T01:00:04Z",
    "content": "On this weeks For Your Consideration, it's time for Colliders awards experts Scott Mantz, Perri Nemiroff and Jeff Sneider to offer their final Oscar predictions, and if you think they agree on everything, think again. Scott thinks Parasite will make history o… [+1187 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580778004000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Nick Lachey REACTS to Ex Jessica Simpson's Tell-All Book - Entertainment Tonight",
    "description": "Nick and Vanessa Lachey stopped by 'Today,' sharing their thoughts on Jessica Simpson's new memoir, 'Open Book,' on stands Feb 4. Exclusives from #ETonline :...",
    "url": "https://www.youtube.com/watch?v=f9jvTobIKCk",
    "urlToImage": "https://i.ytimg.com/vi/f9jvTobIKCk/maxresdefault.jpg",
    "publishedAt": "2020-02-04T01:00:02Z",
    "content": "Nick and Vanessa Lachey stopped by 'Today,' sharing their thoughts on Jessica Simpson's new memoir, 'Open Book,' on stands Feb 4.\r\nExclusives from #ETonline :https://www.youtube.com/playlist?list...",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580778002000
}, {
    "source": {
        "id": null,
        "name": "Tvline.com"
    },
    "author": "Kimberly Roots, Kimberly Roots",
    "title": "'The Masked Singer' Season 3, Episode 2: Spoilers and Clues - TVLine",
    "description": "Mask and ye shall receive: Now that The Masked Singer is back, so too is our roundup of the most pertinent clues about the competitors’ true identities.",
    "url": "https://tvline.com/2020/02/03/the-masked-singer-season-3-episode-2-clues-spoilers/",
    "urlToImage": "https://pmctvline2.files.wordpress.com/2020/02/the-masked-singer-season-3-episode-2-spoilers-clues-dw.jpg?w=615",
    "publishedAt": "2020-02-04T00:46:00Z",
    "content": "Mask and ye shall receive: Now that The MaskedSinger is back, so too is our roundup of the most pertinent clues about the competitors’ true identities.\r\nSunday’s post-Super Bowl Season 3 premiere introduced us to six of this go-around’s 18 contestants: White … [+962 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580777160000
}, {
    "source": {
        "id": "engadget",
        "name": "Engadget"
    },
    "author": "Jon Fingas",
    "title": "Twitter's anti-spam rules foiled Planters' Super Bowl stunt - Engadget",
    "description": "Planters' attempt to go viral with Baby Nut backfired in spectacular fashion.",
    "url": "https://www.engadget.com/2020/02/03/twitter-banned-planters-baby-nut-accounts/",
    "urlToImage": "https://o.aolcdn.com/images/dims?thumbnail=1200%2C630&quality=80&image_uri=https%3A%2F%2Fo.aolcdn.com%2Fimages%2Fdims%3Fcrop%3D1600%252C900%252C0%252C0%26quality%3D85%26format%3Djpg%26resize%3D1600%252C900%26image_uri%3Dhttps%253A%252F%252Fs.yimg.com%252Fos%252Fcreatr-uploaded-images%252F2020-02%252F6d6386d0-46dc-11ea-b55b-9df8d00338ba%26client%3Da1acac3e1b3290917d92%26signature%3D5fa5e7afc880af86ce126f329be78024c728526b&client=amp-blogside-v2&signature=a3ac856ba453478421e0e9f70745659f17bf087c",
    "publishedAt": "2020-02-04T00:44:19Z",
    "content": "The accounts were clearly part of a long-in-the-making campaign, with one of them created as early as September.\r\nFor its part, Kraft Heinz told Insider that it had created the accounts \"after consulting with Twitter\" to stay on the social network's good side… [+391 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580777059000
}, {
    "source": {
        "id": "newsweek",
        "name": "Newsweek"
    },
    "author": "Kelly Wynne",
    "title": "'Bachelor' Spoilers: Monday Eliminations and Alayah's Fate Revealed - Newsweek",
    "description": "The drama isn't over between Alayah Benavidez and two other contestants.",
    "url": "https://www.newsweek.com/bachelor-spoilers-monday-eliminations-alayahs-fate-revealed-1485419",
    "urlToImage": "https://d.newsweek.com/en/full/1559714/kelley-flanagan.jpg",
    "publishedAt": "2020-02-04T00:00:00Z",
    "content": "The Bachelor will return Monday night with a giant cliffhanger to sort out.\r\nLast Monday's episode left Bachelor fans wondering what would happen to Alayah Benavidez. Benavidez was sent home two weeks ago but returned during Monday night's episode. The show s… [+2245 chars]",
    "country": "us",
    "category": "entertainment",
    "datetime": 1580774400000
}, {
    "source": {
        "id": "the-verge",
        "name": "The Verge"
    },
    "author": "Tom Warren",
    "title": "Google admits it sent private videos in Google Photos to strangers - The Verge",
    "description": "Google has revealed it accidentally sent some private videos stored in Google Photos to strangers. The mishap happened for five days last year, and has since been fixed.",
    "url": "https://www.theverge.com/2020/2/4/21122044/google-photos-privacy-breach-takeout-data-video-strangers",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/x5bPoUvbJhKWBIxX7LV2j_Bpi_8=/0x146:2040x1214/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19287010/acastro_191014_1777_google_pixel_0005.0.jpg",
    "publishedAt": "2020-02-04T09:37:30Z",
    "content": "The privacy breach affected a small number of Google Photos users\r\nIllustration by Alex Castro / The Verge\r\nGoogle is alerting some users of its Google Photos service that theyve had their private videos sent to strangers by the search giant. Googles Takeout … [+1209 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580809050000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Kagweni Micheni and Farai Sevenzo, CNN",
    "title": "Kenya's longest serving President Daniel Arap Moi dies at 95 - CNN",
    "description": "Former Kenyan President Daniel Arap Moi, who ruled the country for 24 years, has died, President Uhuru Kenyatta announced Tuesday.",
    "url": "https://www.cnn.com/2020/02/04/world/africa/daniel-arap-moi-obit/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200204090509-daniel-arap-moi-super-tease.jpg",
    "publishedAt": "2020-02-04T09:10:00Z",
    "content": null,
    "country": "us",
    "category": "general",
    "datetime": 1580807400000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Lauren Edmonds Valerie Edwards For Dailymail.com",
    "title": "Parents slam J-Lo's and Shakira's halftime performances as inappropriate for kids - Daily Mail",
    "description": "Outraged parents blasted Jennifer Lopez and Shakira's sexy moves during the Super Bowl halftime performance as 'disgusting,' 'vulgar' and too provocative for children.",
    "url": "https://www.dailymail.co.uk/news/article-7964217/Parents-slam-J-Los-Shakiras-halftime-performances-inappropriate-kids.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/06/24281204-0-image-a-44_1580798403933.jpg",
    "publishedAt": "2020-02-04T07:16:00Z",
    "content": "Parents are outraged over Jennifer Lopez and Shakira's sexy Super Bowl LIV Halftime show, saying it was 'vulgar' and completely inappropriate for children.  \r\nShakira and J-Lo performed the much-hyped half-time show at the Hard Rock Stadium in Miami, Florida,… [+10957 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580800560000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Sarah Moon and Hollie Silverman, CNN",
    "title": "The bodies of Kobe Bryant and 8 others killed in helicopter crash have been released to their families - CNN",
    "description": "The bodies of Kobe Bryant, his daughter Gianna, and seven other people killed in a helicopter crash last month in Calabasas, California, have been released to their families, according to the website for the Los Angeles County Medical Examiner-Coroner.",
    "url": "https://www.cnn.com/2020/02/04/us/kobe-bryant-crash-bodies-911-calls-released/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200128093456-helicopter-crash-victims-split-super-tease.jpg",
    "publishedAt": "2020-02-04T07:01:00Z",
    "content": "(CNN)The bodies of Kobe Bryant, his daughter Gianna, and seven other people killed in a helicopter crash last month in Calabasas, California, have been released to their families, according to the website for the Los Angeles County Medical Examiner-Coroner.\r\n… [+2357 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580799660000
}, {
    "source": {
        "id": null,
        "name": "Hollywoodreporter.com"
    },
    "author": "Gavin J. Blair",
    "title": "Sony Film Unit Posts $51M Quarterly Profit, Down 50 Percent - Hollywood Reporter",
    "description": "Overall revenue at Sony Corp. was up 3 percent at $22.6 billion, while operating profit was down 20 percent at $2.76 billion. Net profit for the October-to-December quarter was down 46 percent to $2.1 billion.",
    "url": "https://www.hollywoodreporter.com/news/sony-film-unit-posts-51m-quarterly-profit-down-50-percent-1276170",
    "urlToImage": "https://cdn1.thr.com/sites/default/files/2019/08/jumanji_the_next_level_-_publicity_still_2-_h_2019.jpg",
    "publishedAt": "2020-02-04T06:12:21Z",
    "content": "Sony's film unit recorded a $51 million (6.2 billion yen) profit for the October-to-December quarter, down from $107 million in the same quarter the previous year.\r\nSales for the division were down 12 percent to $2.17 billion.\r\nJumanji: The Next Level, which … [+2332 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580796741000
}, {
    "source": {
        "id": null,
        "name": "Androidauthority.com"
    },
    "author": null,
    "title": "Google confirms decline in hardware sales: Is Pixel 4 to blame? - Android Authority",
    "description": "Google specifically pointed out some devices that sold well, but the Pixel 4 series wasn't one of them.",
    "url": "https://www.androidauthority.com/google-hardware-sales-q4-2019-1079681/",
    "urlToImage": "https://cdn57.androidauthority.net/wp-content/uploads/2019/10/Google-Pixel-4-colors-and-camera-closeup-920x470.jpg",
    "publishedAt": "2020-02-04T05:40:55Z",
    "content": "Alphabet held its Q4 2019 earnings call yesterday (February 3), and we learned how much money YouTube is making for the first time. The Google parent company also shed some light on hardware sales, painting what seems to be a mixed picture.\r\nAlphabet didn’t g… [+1419 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580794855000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "James Griffiths, CNN",
    "title": "Wuhan coronavirus: Confirmed cases top 20,000 as China marks deadliest day - CNN",
    "description": "The spread of the Wuhan coronavirus shows no signs of slowing, as China reported another major spike in both confirmed cases and deaths in the region at the heart of the epidemic.",
    "url": "https://www.cnn.com/2020/02/04/asia/wuhan-coronavirus-update-intl-hnk/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200204094457-wuhan-virus-0203-02-super-tease.jpg",
    "publishedAt": "2020-02-04T05:34:00Z",
    "content": "Hong Kong (CNN)The spread of the Wuhan coronavirus shows no signs of slowing, as China reported another major spike in both confirmed cases and deaths in the region at the heart of the epidemic. \r\nThe total number of confirmed cases in China stands at 20,438 … [+7440 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580794440000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Turkey hits back after soldiers killed in Syrian gov't shelling - Al Jazeera English",
    "description": "Turkey says its military has hit several Syrian government targets, killing dozens of troops in the rebel-held Idlib province in Syria. The raids were launch...",
    "url": "https://www.youtube.com/watch?v=o9CGv9uBNS4",
    "urlToImage": "https://i.ytimg.com/vi/o9CGv9uBNS4/maxresdefault.jpg",
    "publishedAt": "2020-02-04T05:15:28Z",
    "content": null,
    "country": "us",
    "category": "general",
    "datetime": 1580793328000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Science X staff",
    "title": "Feeding bluebirds helps fend off parasites - Phys.org",
    "description": "If you feed the birds in your backyard, you may be doing more than just making sure they have a source of food: you may be helping baby birds give parasites the boot.",
    "url": "https://phys.org/news/2020-02-bluebirds-fend-parasites.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/hires/2020/feedingblueb.jpg",
    "publishedAt": "2020-02-04T05:00:01Z",
    "content": "If you feed the birds in your backyard, you may be doing more than just making sure they have a source of food: you may be helping baby birds give parasites the boot.\r\nNew research published in the Journal of Applied Ecology from UConn assistant professor of … [+4228 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580792401000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Dave Alsup and Theresa Waldrop, CNN",
    "title": "4 children were found alive after spending the night missing in rural Alaska during a blizzard - CNN",
    "description": "Four children who spent the night lost in a blizzard in rural Alaska were found Monday.",
    "url": "https://www.cnn.com/2020/02/03/us/alaska-missing-children-blizzard/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200203214215-alaska-missing-children-reupload-super-tease.jpg",
    "publishedAt": "2020-02-04T04:16:00Z",
    "content": null,
    "country": "us",
    "category": "general",
    "datetime": 1580789760000
}, {
    "source": {
        "id": "entertainment-weekly",
        "name": "Entertainment Weekly"
    },
    "author": "Maureen Lee Lenker",
    "title": "Did the Oscars just predict the Oscars? - Entertainment Weekly News",
    "description": "The Academy of Motion Picture Arts and Sciences appeared to tweet out a list of predictions for its own ceremony, sending movie fans into a tizzy.",
    "url": "https://ew.com/oscars/2020/02/03/did-the-oscars-just-predict-the-oscars/",
    "urlToImage": "https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fewedit.files.wordpress.com%2F2020%2F01%2Fgettyimages-3105512.jpg%3Fcrop%3D0px%2C0px%2C3044px%2C1598.1px%26resize%3D1200%2C630",
    "publishedAt": "2020-02-04T03:30:00Z",
    "content": "And the Oscar goes to…\r\nWell, the Academy of Motion Picture Arts and Sciences appears to have some thoughts. On Monday afternoon, the organization tweeted a now-deleted photo with no caption that featured the title “My Oscar Predictions,” along with a list of… [+1484 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580787000000
}, {
    "source": {
        "id": "nbc-news",
        "name": "NBC News"
    },
    "author": "Daniel Arkin, Maura Barrett, Jonathan Allen",
    "title": "Results for Iowa caucuses delayed after new system used by state Democratic Party - NBCNews.com",
    "description": "Iowa caucus results delayed after new system used, state Democratic party said.",
    "url": "https://www.nbcnews.com/politics/2020-election/iowa-caucus-results-much-slower-expected-state-democratic-party-quality-n1129431",
    "urlToImage": "https://media1.s-nbcnews.com/j/newscms/2020_06/3214946/200203-iowa-caucus-counting-votes-se-1001p_ba06e90936d5c431d2d51fbd59f876d6.nbcnews-fp-1200-630.jpg",
    "publishedAt": "2020-02-04T03:10:00Z",
    "content": "The Iowa presidential caucuses were thrown into chaos late Monday after the state Democratic Party said it found \"inconsistencies,\" delaying results and causing widespread confusion across the state.\r\n\"We found inconsistencies in the reporting of three sets o… [+2696 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580785800000
}, {
    "source": {
        "id": null,
        "name": "Phonearena.com"
    },
    "author": "Eugene Jeong",
    "title": "The Galaxy Fold 2 is coming, and it's not the Z Flip - PhoneArena",
    "description": "Samsung has recently revealed a new codename for a device in development—the ‘Winner2’, which is expected to be the successor to the Galaxy Fold from last year.",
    "url": "https://www.phonearena.com/news/The-Galaxy-Fold-2-is-coming-and-its-not-the-Z-Flip_id121975",
    "urlToImage": "https://i-cdn.phonearena.com/images/article/121975-two/The-Galaxy-Fold-2-is-coming-and-its-not-the-Z-Flip.jpg",
    "publishedAt": "2020-02-04T03:02:00Z",
    "content": "Samsung is evidently gearing up for a busy year ahead with the launch of the Note 10 and S10 Lite, the numerous leaks surrounding the flagship S20 series, and the clamshell Z Flip. Now, a new report suggests that the South Korean firm is also prepping a true … [+1587 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580785320000
}, {
    "source": {
        "id": "bloomberg",
        "name": "Bloomberg"
    },
    "author": null,
    "title": "First Death From Coronavirus Reported in Hong Kong - Bloomberg",
    "description": null,
    "url": "https://www.bloomberg.com/tosv2.html?vid=&uuid=70abbb10-472b-11ea-acb8-e9009717c61f&url=L25ld3MvYXJ0aWNsZXMvMjAyMC0wMi0wNC9maXJzdC1kZWF0aC1mcm9tLWNvcm9uYXZpcnVzLXJlcG9ydGVkLWluLWhvbmcta29uZw==",
    "urlToImage": null,
    "publishedAt": "2020-02-04T02:48:00Z",
    "content": "To continue, please click the box below to let us know you're not a robot.",
    "country": "us",
    "category": "general",
    "datetime": 1580784480000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Statement made: Ducks down UConn for program's first top-five road victory - Pac-12 Networks",
    "description": "Sabrina Ionescu nearly records another triple-double with 10 points, 9 rebounds and 9 assists as No. 3 Oregon takes down No. 4 UConn by a 74-56 final Monday ...",
    "url": "https://www.youtube.com/watch?v=57HJ0XGbpNI",
    "urlToImage": "https://i.ytimg.com/vi/57HJ0XGbpNI/maxresdefault.jpg",
    "publishedAt": "2020-02-04T02:28:14Z",
    "content": "Sabrina Ionescu nearly records another triple-double with 10 points, 9 rebounds and 9 assists as No. 3 Oregon takes down No. 4 UConn by a 74-56 final Monday in Storrs, Connecticut. Ruthy Hebard had a game-high 22 points while also grabbing 12 boards. Satou Sa… [+166 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580783294000
}, {
    "source": {
        "id": "usa-today",
        "name": "USA Today"
    },
    "author": "Nolan King",
    "title": "Colby Covington wants to box 50 Cent: 'If he got shot one time by me, he wouldn't get back up' - MMA Junkie",
    "description": "The UFC welterweight contender is willing to box the rapper one-handed for charity.",
    "url": "https://mmajunkie.usatoday.com/2020/02/colby-covington-wants-to-box-50-cent-ufc-bellator-mma",
    "urlToImage": "https://usatmmajunkie.files.wordpress.com/2020/02/colby-50.jpeg?w=1024&h=576&crop=1",
    "publishedAt": "2020-02-04T02:11:50Z",
    "content": "Colby Covington has his eyes set on an unlikely opponent for his next combat sports bout.\r\nIn a day and age when the idea of Logan Paul, Antonio Brown and other celebrities participating in a boxing match garners massive attention, Covington (15-2 MMA, 10-2 U… [+2400 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580782310000
}, {
    "source": {
        "id": null,
        "name": "Vox.com"
    },
    "author": "Li Zhou",
    "title": "“He is not who you are”: Adam Schiff’s closing statement appeals to Senate Republicans - Vox.com",
    "description": "In an emotional set of closing arguments in the impeachment trial, Schiff made his final case for convicting Trump.",
    "url": "https://www.vox.com/2020/2/3/21121447/adam-schiff-house-impeachment",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/uWvFlDAP9XQFxdUMxpq4TLp5yCQ=/0x0:4652x2436/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19682145/1197623781.jpg.jpg",
    "publishedAt": "2020-02-04T02:10:00Z",
    "content": "House impeachment manager Adam Schiff is looking for just one Republican. \r\nSchiff on Monday made an emotional plea to Republican senators during the closing arguments of the impeachment trial, calling on them to defy their party and vote to convict President… [+2768 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580782200000
}, {
    "source": {
        "id": null,
        "name": "Gamespot.com"
    },
    "author": "Michael Higham",
    "title": "Warcraft 3 Is Still Great But Reforged Disappoints On Many Fronts - GameSpot",
    "description": "The remaster of Warcraft 3 has some upgrades, but it's missing many of the things that we expected.",
    "url": "https://www.gamespot.com/articles/warcraft-3-is-still-great-but-reforged-disappoints/1100-6473239/",
    "urlToImage": "https://gamespot1.cbsistatic.com/uploads/screen_kubrick/1574/15747411/3630823-wc3rfrgd.jpg",
    "publishedAt": "2020-02-04T02:00:00Z",
    "content": "I was an avid StarCraft player when Warcraft 3: Reign of Chaos first came out in 2002, opting to stick with the sci-fi and skip on the fantasy when it came to my real-time strategy game of choice. But I certainly understand Warcraft's importance and thought t… [+5403 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580781600000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Harvey Weinstein Trial: Accuser Has Panic Attack on the Stand - Variety",
    "description": "Jessica Mann — a key witness in Harvey Weinstein’s rape trial who alleges the former movie mogul raped her twice and sexually assaulted her on numerous occas...",
    "url": "https://www.youtube.com/watch?v=Htj-mLkvc7E",
    "urlToImage": "https://i.ytimg.com/vi/Htj-mLkvc7E/maxresdefault.jpg",
    "publishedAt": "2020-02-04T01:24:55Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "us",
    "category": "general",
    "datetime": 1580779495000
}, {
    "source": {
        "id": null,
        "name": "Forexfactory.com"
    },
    "author": null,
    "title": "China: US Should Refrain From Overreacting On Virus Outbreak - Forex Factory",
    "description": "China: U.S. Should Refrain From Overreacting On Virus Outbreak - China Foreign Ministry Says U.S. Should Refrain From Overreacting On Virus Outbreak, Work With China To Deal With The Epidemic CHINA' S FOREIGN MINISTRY SAYS HOPES U.S. PROVIDES...",
    "url": "https://www.forexfactory.com/news/978531-china-us-should-refrain-from-overreacting-on-virus",
    "urlToImage": "https://www.forexfactory.com/facebookimage.php?id=978531",
    "publishedAt": "2020-02-04T01:10:00Z",
    "content": "here is a positive swing....if anyone cares...Flu has been around for all time at still takes out 0.055% of an ever increase number of those infected.\r\nRound the 23 Jan \"reported\" (lets not get sidetracked on that little issue) deaths from Corona was 54% more… [+471 chars]",
    "country": "us",
    "category": "general",
    "datetime": 1580778600000
}, {
    "source": {
        "id": null,
        "name": "Scmp.com"
    },
    "author": "{ \"@type\":\"Person\", \"name\":\"Eric Ng\" }",
    "title": "Are cocktail therapies for flu and HIV the magic cure for coronavirus? - South China Morning Post",
    "description": "Signs are emerging that a combination therapy involving cocktails of drugs meant for different ailments may be effective in combating the coronavirus outbreak around the world, with different hospitals from Bangkok to Zhejiang reporting cases of patients reco…",
    "url": "https://www.scmp.com/business/companies/article/3048888/could-cocktail-therapies-hiv-and-flu-be-magic-cure-new",
    "urlToImage": "https://cdn.i-scmp.com/sites/default/files/styles/og_image_scmp_generic/public/d8/images/methode/2020/02/04/d4a773ba-4709-11ea-befc-ef9687daaa85_image_hires_144752.JPG?itok=zoqBRUxm&v=1580798879",
    "publishedAt": "2020-02-04T06:24:59Z",
    "content": "Published: 2:24pm, 4 Feb, 2020\r\nUpdated: 2:47pm, 4 Feb, 2020",
    "country": "us",
    "category": "health",
    "datetime": 1580797499000
}, {
    "source": {
        "id": "the-hill",
        "name": "The Hill"
    },
    "author": "Chris Mills Rodrigo",
    "title": "Tech companies feel growing impact of coronavirus outbreak | TheHill - The Hill",
    "description": "Major American tech companies are facing a new challenge as they take steps to grapple with the outbreak of the coronavirus in China.In recent days, tech companies have closed stores and offices, restricted executives and workers from traveling to the country…",
    "url": "https://thehill.com/policy/technology/481298-tech-companies-feel-growing-impact-of-coronavirus-outbreak",
    "urlToImage": "https://thehill.com/sites/default/files/coronavirus.jpg",
    "publishedAt": "2020-02-04T03:03:01Z",
    "content": "Major American tech companies are facing a new challenge as they take steps to grapple with the outbreak of the coronavirus in China.\r\nIn recent days, tech companies have closed stores and offices, restricted executives and workers from traveling to the count… [+5776 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580785381000
}, {
    "source": {
        "id": null,
        "name": "Bbc.com"
    },
    "author": "https://www.facebook.com/bbcnews",
    "title": "Coronavirus will be here for some months, says health secretary - BBC News",
    "description": "The health secretary says global cases of the new virus are \"doubling every five days\".",
    "url": "https://www.bbc.com/news/uk-51358742",
    "urlToImage": "https://ichef.bbci.co.uk/news/1024/branded_news/14EB5/production/_110758658_hi059642033.jpg",
    "publishedAt": "2020-02-04T02:04:30Z",
    "content": "Image copyrightPA Media\r\nThe new coronavirus \"will be with us for at least some months to come\", Health Secretary Matt Hancock has said.\r\nHe told the House of Commons that the number of new cases worldwide was \"doubling every five days\" and dealing with it wa… [+5009 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580781870000
}, {
    "source": {
        "id": null,
        "name": "Yahoo.com"
    },
    "author": null,
    "title": "Atlanta Parents Left 'Overwhelmed' After All 3 of Their Sons Are Diagnosed with Same Eye Cancer - Yahoo Entertainment",
    "description": "Atlanta Parents Overwhelmed After 3 Sons Are Diagnosed with Eye Cancer",
    "url": "https://www.yahoo.com/entertainment/atl-parents-left-overwhelmed-3-020145961.html",
    "urlToImage": "https://s.yimg.com/uu/api/res/1.2/EboP6..MhgJRUUI5.cZh.Q--~B/aD0xMDAwO3c9MTUwMDtzbT0xO2FwcGlkPXl0YWNoeW9u/https://media.zenfs.com/en/people_218/89854cc6b88932d4eac0127a8d883d48",
    "publishedAt": "2020-02-04T02:01:00Z",
    "content": "A Georgia family is dealing with unimaginable circumstances after all three of their sons were diagnosed with the same type of cancer.\r\nTristen Rush was just four weeks old when his parents, Aaron and Angie Rush, learned that he was diagnosed with Retinoblast… [+4562 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580781660000
}, {
    "source": {
        "id": null,
        "name": "Katv.com"
    },
    "author": "Brittany Reese",
    "title": "Pulaski County Sheriff's Office investigating after 14-year-old shot - KATV",
    "description": "The Pulaski County Sheriff's Office is investigating a shooting that left a 14-year-old injured Monday night, according to the agency's Twitter. Authorities say the teen was shot on Lowden Road near Hwy. 365. He has been taken to the hospital for treatment of…",
    "url": "http://katv.com/news/local/pulaski-county-sheriffs-office-investigating-after-14-year-old-shot",
    "urlToImage": "http://static-20.sinclairstoryline.com/resources/media/5fcea765-bd14-44b1-b904-3b3fe807a3fc-large16x9_Edit_Story__20200203_22.07.01.png?1580789272009",
    "publishedAt": "2020-02-04T01:47:39Z",
    "content": null,
    "country": "us",
    "category": "health",
    "datetime": 1580780859000
}, {
    "source": {
        "id": "cnbc",
        "name": "CNBC"
    },
    "author": "Tyler Clifford",
    "title": "Coronavirus will likely become a pandemic, warns ex-FDA commissioner Scott Gottlieb - CNBC",
    "description": "\"We need to work from the assumption that it's already introduced\" in order \"to spot those outbreaks quickly and intervene to keep them small,\" Scott Gottlieb told CNBC.",
    "url": "https://www.cnbc.com/2020/02/03/scott-gottlieb-coronavirus-will-likely-become-a-pandemic.html",
    "urlToImage": "https://image.cnbcfm.com/api/v1/image/106355236-1579959965148gettyimages-1196115521.jpeg?v=1580091446",
    "publishedAt": "2020-02-04T01:39:00Z",
    "content": "The coronavirus will likely grow into a pandemic, warned former U.S. Food and Drug Administration Commissioner Dr. Scott Gottlieb. But he says it's not too late for officials to prevent the disease from becoming an epidemic in America.\r\nThe outbreak of the pn… [+1835 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580780340000
}, {
    "source": {
        "id": null,
        "name": "Forexfactory.com"
    },
    "author": null,
    "title": "China: US Should Refrain From Overreacting On Virus Outbreak - Forex Factory",
    "description": "China: U.S. Should Refrain From Overreacting On Virus Outbreak - China Foreign Ministry Says U.S. Should Refrain From Overreacting On Virus Outbreak, Work With China To Deal With The Epidemic CHINA' S FOREIGN MINISTRY SAYS HOPES U.S. PROVIDES...",
    "url": "https://www.forexfactory.com/news/978531-china-us-should-refrain-from-overreacting-on-virus",
    "urlToImage": "https://www.forexfactory.com/facebookimage.php?id=978531",
    "publishedAt": "2020-02-04T01:10:00Z",
    "content": "here is a positive swing....if anyone cares...Flu has been around for all time at still takes out 0.055% of an ever increase number of those infected.\r\nRound the 23 Jan \"reported\" (lets not get sidetracked on that little issue) deaths from Corona was 54% more… [+471 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580778600000
}, {
    "source": {
        "id": null,
        "name": "Wwmt.com"
    },
    "author": "Alexis Berdine  |  Newschannel 3",
    "title": "New data shows more bedbugs are crawling around Grand Rapids than other cities - WWMT-TV",
    "description": "Grand Rapids made a Terminix 2019 top 50 list for U. S. cities with bedbugs and the pest control company stated on its website that it assessed each city based on the number of calls it received to treat bedbug infestations.  Grand Rapids was ranked 41 out of…",
    "url": "http://wwmt.com/news/local/new-data-shows-more-bedbugs-are-crawling-around-grand-rapids-than-other-cities",
    "urlToImage": "http://static-24.sinclairstoryline.com/resources/media/7586465f-135b-4fa2-9e29-6a6207d1576f-large16x9_BedbugsOTSgraphic.png?1580753756321",
    "publishedAt": "2020-02-04T01:08:15Z",
    "content": null,
    "country": "us",
    "category": "health",
    "datetime": 1580778495000
}, {
    "source": {
        "id": null,
        "name": "Newser.com"
    },
    "author": "Bob Cronin",
    "title": "Agency Calls Off HIV Vaccine Trial - Newser",
    "description": "Results from South Africa show vaccine wasn't effective",
    "url": "https://www.newser.com/story/286467/hiv-vaccine-trial-ends-in-failure-and-deep-disappointment.html",
    "urlToImage": "https://img1-azrcdn.newser.com/image/1280454-12-20200203183138.jpeg",
    "publishedAt": "2020-02-04T00:15:00Z",
    "content": "(Newser)\r\n\"An HIV vaccine is essential to end the global pandemic, and we hoped this vaccine candidate would work,\" a US health agency said Monday. \"Regrettably, it does not.\" With that, the clinical trial in South Africa was shut down, CNN reports; the vacci… [+1130 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580775300000
}, {
    "source": {
        "id": null,
        "name": "Cornellsun.com"
    },
    "author": "Meghna Maharishi",
    "title": "CDC Administering Tests for Cornell Student With Coronavirus Symptoms - Cornell University The Cornell Daily Sun",
    "description": "A Cornell student presented symptoms that mirror the novel coronavirus strain — which has afflicted over 17,000 people internationally, Ryan Lombardi announced in an email. It is not confirmed that the student has coronavirus.",
    "url": "https://cornellsun.com/2020/02/03/cornell-student-tests-positive-for-coronavirus/",
    "urlToImage": "https://i1.wp.com/cornellsun.com/wp-content/uploads/2020/02/CHINA-VIRUS-BEIJING-6.jpg?fit=1170%2C780",
    "publishedAt": "2020-02-04T00:10:00Z",
    "content": "A Cornell student presented symptoms that mirror the novel coronavirus strain which has afflicted over 17,000 people worldwide   Ryan Lombardi, vice president of student and campus life, announced in an email on Monday. It is not confirmed that the student ha… [+2942 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580775000000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Natalie Rahhal Acting Us Health Editor",
    "title": "Global rates of cancer are set to soar by 60% in the next two decades - Daily Mail",
    "description": "More than 80 percent of these predicted cases would occur in poorer countries, where as rates of cancer deaths saw saw a record-setting drop between 2016 and 2017 in the wealthy US.",
    "url": "https://www.dailymail.co.uk/health/article-7963195/Global-rates-cancer-set-soar-60-two-decades.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/00/24270266-0-image-a-22_1580774537072.jpg",
    "publishedAt": "2020-02-04T00:05:00Z",
    "content": "Driven by persistently high rates of HPV, hepatitis and smoking - especially in low-income countries - the world could see 60 percent more cancer cases in the next 20 years, the World Health Organization (WHO) warned in a new report. \r\nOver 80 percent of thes… [+3397 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580774700000
}, {
    "source": {
        "id": null,
        "name": "Thetimes.co.uk"
    },
    "author": "Peta Bee",
    "title": "The 'healthy' foods that are bad for you - The Times",
    "description": "If your focus this year has been to remove meat, sugar or carbohydrates from your diet in the hope that it will transform your health and reduce your waistline, you probably don’t want to hear that",
    "url": "https://www.thetimes.co.uk/article/the-healthy-foods-that-are-bad-for-you-8mhs52z5s",
    "urlToImage": "https://www.thetimes.co.uk/imageserver/image/%2Fmethode%2Ftimes%2Fprod%2Fweb%2Fbin%2Fab687b68-46ad-11ea-a5b7-24df8ee7a872.jpg?crop=8688%2C4887%2C0%2C453",
    "publishedAt": "2020-02-04T00:01:00Z",
    "content": "If your focus this year has been to remove meat, sugar or carbohydrates from your diet in the hope that it will transform your health and reduce your waistline, you probably dont want to hear that your efforts dont fulfil the latest requirement laid out by nu… [+493 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580774460000
}, {
    "source": {
        "id": null,
        "name": "Sfist.com"
    },
    "author": "Jay Barmann",
    "title": "San Benito County Couple Infected With Coronavirus Moved to SF General - SFist",
    "description": "The coronavirus has officially arrived in San Francisco as of Monday after a husband and wife who both tested positive for the virus arrive at Zuckerberg SF General for treatment.",
    "url": "https://sfist.com/2020/02/03/san-benito-county-couple-infected-with-coronavirus-moved-to-sf-general/",
    "urlToImage": "https://img.sfist.com/2020/02/sf-general-new.jpg",
    "publishedAt": "2020-02-03T23:58:44Z",
    "content": "The coronavirus has officially arrived in San Francisco as of Monday after a husband and wife who both tested positive for the virus arrive at Zuckerberg SF General for treatment.\r\nThe couple's symptoms reportedly worsened overnight while they were being trea… [+3169 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580774324000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "How U.S. health officials are responding to threat of novel coronavirus - PBS NewsHour",
    "description": "With nearly 20,000 people in China infected by novel coronavirus, the country has essentially quarantined a population of 50 million. Countries including the...",
    "url": "https://www.youtube.com/watch?v=cDEmUXep7E0",
    "urlToImage": "https://i.ytimg.com/vi/cDEmUXep7E0/maxresdefault.jpg",
    "publishedAt": "2020-02-03T23:56:53Z",
    "content": "With nearly 20,000 people in China infected by novel coronavirus, the country has essentially quarantined a population of 50 million. Countries including the United States have evacuated their citizens from China and restricted inbound travelers from there. S… [+589 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580774213000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Cindy Tran for Daily Mail Australia",
    "title": "Dr Preeya Alexander explains everything you need to know about coronavirus - Daily Mail",
    "description": "As the coronavirus outbreak continues to spread, an Australian doctor has offered an updated insight into the deadly virus.",
    "url": "https://www.dailymail.co.uk/femail/article-7960007/Dr-Preeya-Alexander-explains-need-know-coronavirus.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/03/23/24269300-0-image-a-40_1580772485207.jpg",
    "publishedAt": "2020-02-03T23:52:00Z",
    "content": "As the coronavirus outbreak continues to spread, an Australian doctor has offered an updated insight into the deadly virus.\r\nDr Preeya Alexander, a general practitioner from Melbourne, claimed while the coronavirus does appear to spread more easily than sever… [+6479 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580773920000
}, {
    "source": {
        "id": null,
        "name": "Insider.com"
    },
    "author": "Gabby Landsverk",
    "title": "A low-sulfur diet could help you live longer, and eating less meat could be the key - Insider - INSIDER",
    "description": "Researchers suggest a plant-based diet can help regulate excess amounts of sulfur amino acids, leading to better cardiovascular and metabolic health.",
    "url": "https://www.insider.com/sulfur-amino-acids-in-meat-products-linked-to-disease-2020-2",
    "urlToImage": "https://i.insider.com/5e38a02aab49fd4edb4dd92f?width=1200&format=jpeg",
    "publishedAt": "2020-02-03T23:03:45Z",
    "content": "iStock\r\nProtein is an important macro-nutrient, whether you're a body builder or an average desk jockey. But there can be too much of a good thing. New research has found that getting too much protein in your diet, particularly from animal sources, can increa… [+3499 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580771025000
}, {
    "source": {
        "id": null,
        "name": "Nola.com"
    },
    "author": "EMILY WOODRUFF | Staff writer",
    "title": "Louisiana's death rate for pregnant women is twice the average; homicide is a leading cause - NOLA.com",
    "description": "With a death rate for pregnant women that's twice the U.S. average, Louisiana is one of the country's most dangerous places to have a baby. Now, a new study on",
    "url": "https://www.nola.com/news/healthcare_hospitals/article_bb4ba3a4-469c-11ea-9e24-6387ba02467e.html",
    "urlToImage": "https://bloximages.newyork1.vip.townnews.com/nola.com/content/tncms/assets/v3/editorial/e/e6/ee63910e-46a4-11ea-9eda-8b0ed95f393d/5d14ce376b122.image.jpg?resize=1200%2C608",
    "publishedAt": "2020-02-03T22:45:00Z",
    "content": "With a death rate for pregnant women that's twice the U.S. average, Louisiana is one of the country's most dangerous places to have a baby. Now, a new study on maternal mortality in the state includes another startling statistic: Homicide is among the leading… [+5472 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580769900000
}, {
    "source": {
        "id": null,
        "name": "Dailysabah.com"
    },
    "author": "www.dailysabah.com",
    "title": "Coronavirus already a pandemic, Mayo Clinic doctor warns - Daily Sabah",
    "description": "'We're basically at a pandemic now,' Dr. Gregory Poland, head of the Mayo Clinic's Vaccine Research Group, was quoted as saying late Monday regarding the deadly coronavirus, in a piece published by CNBC. Claiming that the illness should be treated as such, he…",
    "url": "https://www.dailysabah.com/health/2020/02/04/coronavirus-already-a-pandemic-mayo-clinic-doctor-warns",
    "urlToImage": "https://iadsb.tmgrup.com.tr/4b2032/645/344/0/0/800/426?u=https://idsb.tmgrup.com.tr/2020/02/04/coronavirus-already-a-pandemic-mayo-clinic-doctor-warns-1580769373788.jpg",
    "publishedAt": "2020-02-03T22:40:24Z",
    "content": "\"We're basically at a pandemic now,\" Dr. Gregory Poland, head of the Mayo Clinic's Vaccine Research Group, was quoted as saying late Monday regarding the deadly coronavirus, in a piece published by CNBC.\r\nClaiming that the illness should be treated as such, h… [+864 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580769624000
}, {
    "source": {
        "id": null,
        "name": "Bnnbloomberg.ca"
    },
    "author": "Bloomberg News",
    "title": "Death toll tops 400; US braces for pandemic - BNNBloomberg.ca",
    "description": "Chinese officials are hoping the U.S. will agree to some flexibility on pledges in their phase-one trade deal, people familiar with the situation said, as Beijing tries to contain economic damage from the worsening coronavirus crisis.",
    "url": "http://www.bnnbloomberg.ca/death-toll-tops-400-u-s-braces-for-pandemic-virus-update-1.1384278",
    "urlToImage": "https://www.bnnbloomberg.ca/polopoly_fs/1.1382713!/fileimage/httpImage/image.jpg_gen/derivatives/landscape_620/shop-assistants-in-luxury-outlets-in-sydney-s-cbd-are-seen-wearing-masks-on-january-31-2020-in-sydney-australia.jpg",
    "publishedAt": "2020-02-03T22:35:50Z",
    "content": "Chinese officials are hoping the U.S. will agree to some flexibility on pledges in their phase-one trade deal, people familiar with the situation said, as Beijing tries to contain economic damage from the worsening coronavirus crisis.\r\nIn the U.S., the Center… [+5578 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580769350000
}, {
    "source": {
        "id": null,
        "name": "Umn.edu"
    },
    "author": null,
    "title": "China nCoV surge tops 17000 as more vaccine support announced - CIDRAP",
    "description": "In a new Q&A, the WHO answers common questions and dispels myths.",
    "url": "http://www.cidrap.umn.edu/news-perspective/2020/02/china-ncov-surge-tops-17000-more-vaccine-support-announced",
    "urlToImage": "http://www.cidrap.umn.edu/sites/default/files/public/styles/thumbnail/public/images/news/chinese_woman_with_mask.jpg?itok=6ZMnVawk",
    "publishedAt": "2020-02-03T22:33:13Z",
    "content": "Chinese health officials reported 2,892 new novel coronavirus (2019-nCoV) cases and 57 more deaths, while Hong Kong reported its first instance of local spread and India reported its third case.\r\nIn other developments today, the World Health Organization (WHO… [+4974 chars]",
    "country": "us",
    "category": "health",
    "datetime": 1580769193000
}, {
    "source": {
        "id": null,
        "name": "Spaceflightnow.com"
    },
    "author": null,
    "title": "Cygnus departs space station, deploys CubeSats - Spaceflight Now",
    "description": null,
    "url": "https://spaceflightnow.com/2020/02/03/cygnus-departs-space-station-deploys-cubesats/",
    "urlToImage": null,
    "publishedAt": "2020-02-04T05:46:48Z",
    "content": "Northrop Grumman’s Cygnus cargo craft departed the International Space Station Friday before raising its orbit and deploying multiple CubeSats. Credit: Oleg Skripochka/Roscosmos\r\nA Northrop Grumman Cygnus cargo craft departed the International Space Station F… [+9135 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580795208000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Science X staff",
    "title": "Sand dunes can 'communicate' with each other - Phys.org",
    "description": "Even though they are inanimate objects, sand dunes can 'communicate' with each other. A team from the University of Cambridge has found that as they move, sand dunes interact with and repel their downstream neighbours.",
    "url": "https://phys.org/news/2020-02-sand-dunes.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/2020/sanddunescan.jpg",
    "publishedAt": "2020-02-04T05:00:15Z",
    "content": "Even though they are inanimate objects, sand dunes can 'communicate' with each other. A team from the University of Cambridge has found that as they move, sand dunes interact with and repel their downstream neighbours.\r\nUsing an experimental dune 'racetrack',… [+4922 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580792415000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Science X staff",
    "title": "Feeding bluebirds helps fend off parasites - Phys.org",
    "description": "If you feed the birds in your backyard, you may be doing more than just making sure they have a source of food: you may be helping baby birds give parasites the boot.",
    "url": "https://phys.org/news/2020-02-bluebirds-fend-parasites.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/hires/2020/feedingblueb.jpg",
    "publishedAt": "2020-02-04T05:00:01Z",
    "content": "If you feed the birds in your backyard, you may be doing more than just making sure they have a source of food: you may be helping baby birds give parasites the boot.\r\nNew research published in the Journal of Applied Ecology from UConn assistant professor of … [+4228 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580792401000
}, {
    "source": {
        "id": null,
        "name": "Universetoday.com"
    },
    "author": "https://www.facebook.com/evan.gough.3",
    "title": "NASA Astronaut Jessica Meir Took a Space Selfie, Capturing her Reflection in the Space Station - Universe Today",
    "description": "NASA astronaut Jessica Meir had a spare moment to capture some selfies during her last spacewalk. She can't hide her smile!",
    "url": "https://www.universetoday.com/144860/nasa-astronaut-jessica-meir-took-a-space-selfie-capturing-her-reflection-in-the-space-station/",
    "urlToImage": "https://www.universetoday.com/wp-content/uploads/2020/02/EPPeDebXsAA-D3S.jpg",
    "publishedAt": "2020-02-03T23:40:00Z",
    "content": "In 2006, astronomers spotted the telltale sign of a supernova detonating in the galaxy NGC 1260, located about 240 million light-years away in the constellation of Perseus. As telescopes around the world turned their collective light-gathering power on the ex… [+2076 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580773200000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Rob Picheta, CNN",
    "title": "Texting more dangerous for pedestrians than listening to music or speaking on the phone - CNN",
    "description": "We can all agree that walking behind someone who's buried in their phone is annoying. Now scientists are suggesting it's dangerous, too.",
    "url": "https://www.cnn.com/2020/02/03/health/texting-pedestrian-safety-study-wellness-scli-intl/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/170729164127-cell-phone-walking-file-super-tease.jpg",
    "publishedAt": "2020-02-03T23:32:00Z",
    "content": null,
    "country": "us",
    "category": "science",
    "datetime": 1580772720000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Gisela Crespo, CNN",
    "title": "Scientists find another threat to Greenland's glaciers lurking beneath the ice - CNN",
    "description": "Warm ocean water moving underneath Greenland's glaciers is causing its vast ice sheet to melt even faster.",
    "url": "https://www.cnn.com/2020/02/03/world/greenland-glaciers-melting-underwater/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200203145600-01-warm-underwater-glaciers-melting-super-tease.jpg",
    "publishedAt": "2020-02-03T23:10:00Z",
    "content": "(CNN)Scientists have long known that higher air temperatures are contributing to the surface melting on Greenland's ice sheet.\r\nBut a new study has found another threat that has begun attacking the ice from below: Warm ocean water moving underneath the vast g… [+2346 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580771400000
}, {
    "source": {
        "id": null,
        "name": "Atlasobscura.com"
    },
    "author": "Matthew Taub",
    "title": "Ancient Hot Pots Helped Hunters Survive the Siberian Ice Age - Atlas Obscura",
    "description": "16,000 years later, they still contain traces of cooked meat and fish.",
    "url": "https://www.atlasobscura.com/articles/who-invented-hot-pot",
    "urlToImage": "https://assets.atlasobscura.com/media/W1siZiIsInVwbG9hZHMvYXNzZXRzLzMwYjk2MDgyLTFkZjMtNDBhYy1iYmQ1LWY4YzBlZjMwNzc5ODlhMzgyZDU0YmUxNjU0OTgzZV8yMjMxMTlfd2ViLmpwZyJdLFsicCIsImNvbnZlcnQiLCIiXSxbInAiLCJjb252ZXJ0IiwiLXF1YWxpdHkgODEgLWF1dG8tb3JpZW50Il0sWyJwIiwidGh1bWIiLCI2MDB4PiJdXQ/223119_web.jpg",
    "publishedAt": "2020-02-03T22:53:01Z",
    "content": "Siberia was probably not the ideal place to live during the late Ice Age. But new research indicates that those residents were perhaps toastier than we might think. As far back as 16,000 years ago, inhabitants of the perilously icy landscape had figured out h… [+2724 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580770381000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Sebastian Kettley",
    "title": "London underwater MAP: Chilling climate forecast shows UK capital submerged in 50 years - Express.co.uk",
    "description": "LONDON could find itself submerged under rising tides and heavy rainfall in the next 50 years if climate change is left unopposed, terrifying forecasts have revealed.",
    "url": "https://www.express.co.uk/news/science/1237504/London-flooding-map-climate-change-forecast-UK-underwater-global-warming-seal-rise",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/151/750x445/1237504.jpg",
    "publishedAt": "2020-02-03T22:41:00Z",
    "content": null,
    "country": "us",
    "category": "science",
    "datetime": 1580769660000
}, {
    "source": {
        "id": null,
        "name": "Cnet.com"
    },
    "author": "Jackson Ryan",
    "title": "NASA solar probe smashes two wild records as it approaches the sun - CNET",
    "description": "Gotta go fast.",
    "url": "https://www.cnet.com/news/nasa-solar-probe-smashes-two-wild-records-as-it-approaches-the-sun/",
    "urlToImage": "https://cnet2.cbsistatic.com/img/GLr7HKRv934pPDtow-lHEEIv9bY=/756x567/2018/10/03/f0c21d50-f31f-475b-ae3f-0039a88ea60f/wts-parker-solar-probe-cnet-thumb.jpg",
    "publishedAt": "2020-02-03T22:03:27Z",
    "content": "New record!\r\nNASA\r\nNASA's Parker Solar Probe just took the record for the fastest human-made object and the closest object to the sun from... NASA's Parker Solar Probe.\r\nThe solar probe, launched in August 2018, is built to withstand the scorching temperature… [+2336 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580767407000
}, {
    "source": {
        "id": "the-next-web",
        "name": "The Next Web"
    },
    "author": "Tristan Greene",
    "title": "New bill could kill NASA's Moon base plans - The Next Web",
    "description": "The US House of Representatives recently proposed a bipartisan bill that would essentially tank NASA's plans to build a fully-functioning lunar base.\r\n\r\nThe proposal comes from the ...",
    "url": "https://thenextweb.com/?p=1269546",
    "urlToImage": "https://img-cdn.tnwcdn.com/image/tnw?filter_last=1&fit=1280%2C640&url=https%3A%2F%2Fcdn0.tnwcdn.com%2Fwp-content%2Fblogs.dir%2F1%2Ffiles%2F2018%2F08%2Fnasacolony.jpg&signature=674b6435e5ff8851f68d903b3e416c10",
    "publishedAt": "2020-02-03T22:02:30Z",
    "content": "The US House of Representatives recently proposed a bipartisan bill that would essentially tank NASAs plans to build a fully-functioning lunar base.\r\nThe proposal comes from the House Aeronautics and Space Subcommittee of the House Space and Science Committee… [+3093 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580767350000
}, {
    "source": {
        "id": null,
        "name": "Extremetech.com"
    },
    "author": "Joel Hruska",
    "title": "Rising Seas: Record Warmth Found at 'Doomsday Glacier' Water Line - ExtremeTech",
    "description": "Scientists investigating Thwaites Glacier found warm seawater below it, at the point where the iceberg means bedrock. That's bad, for a number of reasons.",
    "url": "https://www.extremetech.com/extreme/305718-rising-seas-water-thwaites-glacier-grounding-line-above-freezing",
    "urlToImage": "https://www.extremetech.com/wp-content/uploads/2020/02/Camp-Cavity.jpg",
    "publishedAt": "2020-02-03T22:00:24Z",
    "content": "The Thwaites Glacier, in West Antarctica, is one of the glaciers considered most at-risk for collapse over the next century, earning it the nickname “doomsday glacier.” Scientists have been studying the glacier with increasing concern over the past decade and… [+4470 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580767224000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Sachi Wickramasinghe",
    "title": "New quantum switch turns metals into insulators - Phys.org",
    "description": "Most modern electronic devices rely on tiny, finely-tuned electrical currents to process and store information. These currents dictate how fast our computers run, how regularly our pacemakers tick and how securely our money is stored in the bank.",
    "url": "https://phys.org/news/2020-02-quantum-metals-insulators.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/2020/newquantumsw.jpg",
    "publishedAt": "2020-02-03T21:52:46Z",
    "content": "Most modern electronic devices rely on tiny, finely-tuned electrical currents to process and store information. These currents dictate how fast our computers run, how regularly our pacemakers tick and how securely our money is stored in the bank.\r\nIn a study … [+3641 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580766766000
}, {
    "source": {
        "id": null,
        "name": "Livescience.com"
    },
    "author": "Doris Elin Salazar",
    "title": "'Vampire' star sparks brilliant 'super-outburst' while gorging on its neighbor - Livescience.com",
    "description": "",
    "url": "https://www.livescience.com/vampire-star-gorges-on-neighbor.html",
    "urlToImage": "https://cdn.mos.cms.futurecdn.net/sxwVn8pKRKgsNPwRSTJbPR-1200-80.jpg",
    "publishedAt": "2020-02-03T21:48:00Z",
    "content": "A \"vampire\" dwarf star is sucking the life force from its partner star, and their entanglement produced a rare superoutburst. \r\nNASA detailed this previously unknown dwarf nova, a brief eruption from dwarf stars, in a statement on Jan. 24. The system brighten… [+2763 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580766480000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Science X staff",
    "title": "Researchers create 'intelligent' interaction between light and material - Phys.org",
    "description": "A collaboration between McMaster and Harvard researchers has generated a new platform in which light beams communicate with one another through solid matter, establishing the foundation to explore a new form of computing.",
    "url": "https://phys.org/news/2020-02-intelligent-interaction-material.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/hires/2020/makinglightw.jpg",
    "publishedAt": "2020-02-03T21:39:10Z",
    "content": "A collaboration between McMaster and Harvard researchers has generated a new platform in which light beams communicate with one another through solid matter, establishing the foundation to explore a new form of computing.\r\nTheir work is described in a paper p… [+3534 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580765950000
}, {
    "source": {
        "id": null,
        "name": "Sciencedaily.com"
    },
    "author": null,
    "title": "'Parentese' helps parents, babies make 'conversation' and boosts language development - Science Daily",
    "description": "A new study finds the value of using 'parentese,' an exaggerated speaking style that conveys total engagement with a child.",
    "url": "https://www.sciencedaily.com/releases/2020/02/200203151158.htm",
    "urlToImage": null,
    "publishedAt": "2020-02-03T21:06:39Z",
    "content": "Used in virtually all of the world's languages, parentese is a speaking style that draws baby's attention. Parents adopt its simple grammar and words, plus its exaggerated sounds, almost without thinking about it.But if parents knew the way they speak could h… [+5554 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580763999000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Sebastian Kettley",
    "title": "Moon landing shock: Michael Collins' admission 'NASA never told me' about Apollo 11 - Express.co.uk",
    "description": "NASA'S Michael Collins may have been instrumental in the success of the 1969 Moon landing but NASA never told him Apollo 11 would be the mission to do it first, the astronaut has just revealed.",
    "url": "https://www.express.co.uk/news/science/1237447/Moon-landing-NASA-news-Michael-Collins-astronaut-Apollo-11-Neil-Armstrong-Buzz-Aldrin",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/151/750x445/1237447.jpg",
    "publishedAt": "2020-02-03T20:35:00Z",
    "content": null,
    "country": "us",
    "category": "science",
    "datetime": 1580762100000
}, {
    "source": {
        "id": null,
        "name": "Treehugger.com"
    },
    "author": "Melissa Breyer",
    "title": "What Earth would look like if we drained all the oceans (video) - Treehugger",
    "description": "A NASA scientist shows us the three-fifths of the planet's surface that we don't get to see.",
    "url": "https://www.treehugger.com/natural-sciences/what-earth-would-look-if-we-drained-all-oceans-video.html",
    "urlToImage": "https://media.treehugger.com/assets/images/2020/02/earthoceans.jpg.600x315_q90_crop-smart.jpg",
    "publishedAt": "2020-02-03T19:44:22Z",
    "content": "A NASA scientist shows us the three-fifths of the planet's surface that we don't get to see.\r\nThese days the concern may be more about what Earth would look like if all the ice melted but this look at what we'd see if all the oceans drained away is seriously … [+2802 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580759062000
}, {
    "source": {
        "id": "fox-news",
        "name": "Fox News"
    },
    "author": "James Rogers",
    "title": "Snow moon on deck: Get set for one of the largest full moons of 2020 - Fox News",
    "description": "Skywatchers will soon get a chance to see the Snow Moon, which will be one of the largest full Moons of this year when it lights up the night sky on Feb. 8 and 9.",
    "url": "https://www.foxnews.com/science/snow-moon-on-deck",
    "urlToImage": "https://static.foxnews.com/foxnews.com/content/uploads/2019/02/01_IMG_8985_moon03_02192019.jpg",
    "publishedAt": "2020-02-03T18:45:00Z",
    "content": "Skywatchers will soon get a chance to see the snow moon, which will be one of the largest full moons of this year when it lights up the night sky on Feb. 8 and 9. \r\nThe February full moon will reach its peak at 2:33 a.m. EST on Sunday, Feb. 9, according to NA… [+2049 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580755500000
}, {
    "source": {
        "id": null,
        "name": "Nature.com"
    },
    "author": null,
    "title": "Li metal deposition and stripping in a solid-state battery via Coble creep - Nature.com",
    "description": "By containing lithium metal within oriented tubes of a mixed ionic-electronic conductor, a 3D&nbsp;anode for lithium metal batteries is produced that overcomes &nbsp;chemomechanical stability issues&nbsp;at the electrolyte interface.",
    "url": "https://www.nature.com/articles/s41586-020-1972-y",
    "urlToImage": "https://media.springernature.com/m685/springer-static/image/art%3A10.1038%2Fs41586-020-1972-y/MediaObjects/41586_2020_1972_Fig1_HTML.png",
    "publishedAt": "2020-02-03T18:29:26Z",
    "content": "<li></li>\r\n1.Porz, L. et al. Mechanism of lithium metal penetration through inorganic solid electrolytes. Adv. Energy Mater. 7, 1701003 (2017).\r\n<li></li>\r\n2.Armstrong, R. D., Dickinson, T. &amp; Turner, J. The breakdown of -alumina ceramic electrolyte. Elect… [+5996 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580754566000
}, {
    "source": {
        "id": null,
        "name": "Scitechdaily.com"
    },
    "author": null,
    "title": "Unexpected Discovery by NASA’s MAVEN on Mars Helps Explain Disruptive Phenomenon on Earth - SciTechDaily",
    "description": "NASA’s MAVEN (Mars Atmosphere and Volatile EvolutioN) spacecraft has discovered “layers” and “rifts” in the electrically charged part of the upper atmosphere (the ionosphere) of Mars. The phenomenon is very common at Earth and causes unpredictable disruptions…",
    "url": "https://scitechdaily.com/unexpected-discovery-by-nasas-maven-on-mars-helps-explain-disruptive-phenomenon-on-earth/",
    "urlToImage": "https://scitechdaily.com/images/MAVEN-Spacecraft-Mars-Plasma-Layers-scaled.jpg",
    "publishedAt": "2020-02-03T17:44:20Z",
    "content": "Graphic illustrating radio signals from a remote station (bent purple line) interfering with a local station (black tower) after being reflected off a plasma layer in the ionosphere. Credit: NASA Goddard/CI lab\r\nNASA’s MAVEN (Mars Atmosphere and Volatile Evol… [+5538 chars]",
    "country": "us",
    "category": "science",
    "datetime": 1580751860000
}, {
    "source": {
        "id": null,
        "name": "Telegraph.co.uk"
    },
    "author": null,
    "title": "Construction sector shows signs of a rebound – live updates - Telegraph.co.uk",
    "description": "Flat-pack furniture lovers of the west midlands despair &ndash; Swedish furniture seller Ikea apparently plans to close its store in Coventry.",
    "url": "https://www.telegraph.co.uk/business/2020/02/04/markets-live-latest-news-pound-euro-ftse-100/",
    "urlToImage": "https://www.telegraph.co.uk/content/dam/business/2020/02/04/TELEMMGLPICT000106108047-xlarge_trans_NvBQzQNjv4BqkHKcmJXkDkPeJVvcu56MTukwnuvKGWDUgsrHeVN7YYw.jpeg?imwidth=1200",
    "publishedAt": "2020-02-04T10:45:00Z",
    "content": "3) Boris Johnsons election win has triggered the biggest wave of optimism among smaller manufacturers for six years but the surge is yet to translate into fuller order books, the Confederation of British Industry (CBI) has said. The Tory victory in December d… [+2224 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580813100000
}, {
    "source": {
        "id": null,
        "name": "Pinkbike.com"
    },
    "author": null,
    "title": "back First Ride: The 2020 Specialized Turbo Levo SL Weighs Only 38 Pounds - Pinkbike.com",
    "description": "The new Levo SL uses the same lightweight motor as Specialized's Creo e-road bike.",
    "url": "https://www.pinkbike.com/news/first-ride-2020-specialized-turbo-levo-sl.html",
    "urlToImage": "https://ep1.pinkbike.org/p4pb18237249/p4pb18237249.jpg",
    "publishedAt": "2020-02-04T08:21:33Z",
    "content": "In total, there are 5 models in the Tubo Levo SL lineup. Prices start at $6,535 for the aluminum framed SL Comp model, and go all the way up to a bank-account emptying $16,525 USD for the Founder's Edition, which has a carbon frame, carbon wheels, and SRAM AX… [+5412 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580804493000
}, {
    "source": {
        "id": null,
        "name": "Constructionenquirer.com"
    },
    "author": null,
    "title": "Kier stands in for Amey on Birmingham Highways upkeep - Construction Enquirer",
    "description": "Firm secures interim 15-month deal while long-term partner sought",
    "url": "https://www.constructionenquirer.com/2020/02/04/kier-stands-in-for-amey-on-birmingham-highways-upkeep/",
    "urlToImage": "https://www.constructionenquirer.com/wp-content/uploads/kier_spag_alt-1200x828.png",
    "publishedAt": "2020-02-04T08:14:28Z",
    "content": "Amey is pulling out of the 25-year maintenance and management contract at the end of March after paying £215m to walk away from its highways maintenance PFI contract.This ended a five-year legal battle with the council over performance, during which time Amey… [+1895 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580804068000
}, {
    "source": {
        "id": "techcrunch",
        "name": "TechCrunch"
    },
    "author": "Steve O'Hear",
    "title": "Azimo, the money transfer service, secures €20M debt finance from the European Investment Bank - TechCrunch",
    "description": "Azimo, the money transfer service that is HQ’d in London but has the majority of its staff based in based in Poland, has secured €20 million in debt from the European Investment Bank (EIB), the lending arm of the European Union. The financing is supported by …",
    "url": "http://techcrunch.com/2020/02/04/azimo-eib/",
    "urlToImage": "https://techcrunch.com/wp-content/uploads/2019/08/01_Azimo.jpg?w=711",
    "publishedAt": "2020-02-04T08:01:11Z",
    "content": "Azimo, the money transfer service that is HQ’d in London but has the majority of its staff based in based in Poland, has secured 20 million in debt from the European Investment Bank (EIB), the lending arm of the European Union.\r\nThe financing is supported by … [+2216 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580803271000
}, {
    "source": {
        "id": "financial-times",
        "name": "Financial Times"
    },
    "author": null,
    "title": "BP boosts dividend despite slide in profits - Financial Times",
    "description": "Lower oil and gas prices drive 26% drop in earnings at energy group",
    "url": "https://www.ft.com/content/3c4232e4-471e-11ea-aeb3-955839e06441",
    "urlToImage": "https://www.ft.com/__origami/service/image/v2/images/raw/http%3A%2F%2Fprod-upp-image-read.ft.com%2F64aa8920-471e-11ea-aeb3-955839e06441?source=next-opengraph&fit=scale-down&width=900",
    "publishedAt": "2020-02-04T07:53:02Z",
    "content": "BP raised its dividend as confidence about its ability to generate more cash grew following the completion of a share buyback programme, new asset disposal targets and falling debt levels. \r\nThe higher payout was announced despite the UK energy major reportin… [+3369 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580802782000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Luke Chillingsworth",
    "title": "Petrol and diesel cars to be banned by 2035 to boost electric car sales and save planet - Express",
    "description": "PETROL and diesel cars are set to be banned from forecourts by 2035 as part of the government's plans to deliver on its net-zero carbon promise by 2050.",
    "url": "https://www.express.co.uk/life-style/cars/1237567/petrol-diesel-cars-fuel-car-ban-electric-sales-zero-carbon",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/24/750x445/1237567.jpg",
    "publishedAt": "2020-02-04T07:52:00Z",
    "content": null,
    "country": "gb",
    "category": "business",
    "datetime": 1580802720000
}, {
    "source": {
        "id": null,
        "name": "Mirror.co.uk"
    },
    "author": "Dave Burke",
    "title": "Charing Cross and Waterloo delays: Rush hour chaos with all trains suspended - Mirror Online",
    "description": "The disruption, which will cause misery for thousands of commuters, comes after a track defect was found overnight at New Cross. Southern Railway said it is trying to repair the damage",
    "url": "https://www.mirror.co.uk/news/uk-news/breaking-charing-cross-waterloo-delays-21425187",
    "urlToImage": "https://i2-prod.mirror.co.uk/incoming/article13817578.ece/ALTERNATES/s1200/1_Southern-Railway.jpg",
    "publishedAt": "2020-02-04T07:42:00Z",
    "content": "Commuters to Charing Cross and Waterloo East face misery, with delays and cancellations expected to last until 3pm.\r\nThe disruption comes after a cracked rail was found overnight at New Cross.\r\nRail chiefs have warned that a solution will not be an \"easy fix\"… [+1946 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580802120000
}, {
    "source": {
        "id": null,
        "name": "Theguardian.com"
    },
    "author": "Josh Taylor",
    "title": "Elon Musk's SpaceX clears first hurdle to Australian broadband market - The Guardian",
    "description": "Communications regulator allows Starlink satellites over Australian airspace, but Foxtel objects",
    "url": "https://www.theguardian.com/technology/2020/feb/04/elon-musks-spacex-clears-first-hurdle-to-australian-broadband-market",
    "urlToImage": "https://i.guim.co.uk/img/media/c574d47d3636d39edc14d7072e2baed4e419fa21/0_170_3000_1800/master/3000.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=28ef74a43e0e972be22016567ea309b0",
    "publishedAt": "2020-02-04T07:30:00Z",
    "content": "Elon Musks SpaceX satellite broadband service has taken its first step into the Australian market. The communications regulator has added the company to a list of satellite operators allowed over Australian airspace.\r\nBut Foxtel has raised concerns the servic… [+3446 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580801400000
}, {
    "source": {
        "id": null,
        "name": "Sky.com"
    },
    "author": "Sky",
    "title": "Aviation firms commit to net-zero carbon target - Sky News",
    "description": "The pledge would involve carbon offsetting as well as sustainable fuels but was described as a \"flight of fancy\" by Greenpeace.",
    "url": "https://news.sky.com/story/aviation-firms-commit-to-net-zero-carbon-target-11925910",
    "urlToImage": "https://e3.365dm.com/19/10/1600x900/2371910030882381707_4793864.jpg?20191003075054",
    "publishedAt": "2020-02-04T07:15:39Z",
    "content": null,
    "country": "gb",
    "category": "business",
    "datetime": 1580800539000
}, {
    "source": {
        "id": null,
        "name": "Theregister.co.uk"
    },
    "author": "Kieren McCarthy",
    "title": "Twitter says a certain someone tried to discover the phone numbers used by potentially millions of twits - The Register",
    "description": "Exploitable API blew away anonymity, abused by systems in Iran, Israel, Malaysia",
    "url": "https://www.theregister.co.uk/2020/02/04/twitter_phone_numbers/",
    "urlToImage": "https://regmedia.co.uk/2018/04/23/shutterstock_vintage_phone.jpg",
    "publishedAt": "2020-02-04T07:01:00Z",
    "content": "Twitter has admitted a flaw in its backend systems was exploited to discover the cellphone numbers of potentially millions of twits en masse, which could lead to their de-anonymization.\r\nIn an advisory on Monday, the social network noted it had became aware t… [+2394 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580799660000
}, {
    "source": {
        "id": null,
        "name": "Constructionenquirer.com"
    },
    "author": null,
    "title": "Drywall contractor Astins goes down - Construction Enquirer",
    "description": "Hundreds of staff stunned as £50m turnover specialist sends them home",
    "url": "https://www.constructionenquirer.com/2020/02/04/drywall-contractor-astins-goes-down/",
    "urlToImage": "https://www.constructionenquirer.com/wp-content/uploads/Screenshot-2020-02-03-at-15.10.23-1200x828.png",
    "publishedAt": "2020-02-04T07:00:53Z",
    "content": "The Crawley based company is understood to have ceased trading after 24 years in business.\r\nOne manager said on Linkedin: “To say this is one of the saddest days of my life is an understatement.\r\n“I have worked for Astins Ltd for over 12 years and the fact it… [+867 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580799653000
}, {
    "source": {
        "id": "techcrunch",
        "name": "TechCrunch"
    },
    "author": "Steve O'Hear",
    "title": "Dixa, the customer engagement platform, picks up $36M Series B - TechCrunch",
    "description": "Dixa, the customer engagement platform, has closed $36 million in Series B funding. Leading the round is Notion Capital, with participation from existing investors Project A Ventures and SEED Capital. The Copenhagen and now London-based startup says it will u…",
    "url": "http://techcrunch.com/2020/02/03/dixa-series-b/",
    "urlToImage": "https://techcrunch.com/wp-content/uploads/2020/01/4.jpg?w=601",
    "publishedAt": "2020-02-04T07:00:44Z",
    "content": "Dixa, the customer engagement platform, has closed $36 million in Series B funding. Leading the round is Notion Capital, with participation from existing investors Project A Ventures and SEED Capital.\r\nThe Copenhagen and now London-based startup says it will … [+2425 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580799644000
}, {
    "source": {
        "id": null,
        "name": "Londonist.com"
    },
    "author": null,
    "title": "At Last! Eurostar Trains Will Run Direct From Amsterdam To London From April - Londonist",
    "description": "No more changing at Brussels.",
    "url": "https://londonist.com/london/transport/eurostar-trains-now-direct-to-from-london-st-pancras-amsterdam-centraal",
    "urlToImage": "https://assets.londonist.com/uploads/2020/01/i875/eurostar_trains.jpg",
    "publishedAt": "2020-02-04T07:00:26Z",
    "content": "It's just become easier to get from Amsterdam to London by Eurostar. Image: Shutterstock\r\nEurostar has announced it will run direct trains services between Amsterdam Centraal London St Pancras from 30 April.\r\nThere's been a direct London to Amsterdam service … [+1018 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580799626000
}, {
    "source": {
        "id": null,
        "name": "Theguardian.com"
    },
    "author": "Helen Pidd",
    "title": "Northern Powerhouse Rail: backers say HS2 is vital to its success - The Guardian",
    "description": "In the north of England, the arguments over whether to push on with the HS2 high-speed rail project are as polarised as they are in Westminster. Helen Pidd speaks to those in favour",
    "url": "https://www.theguardian.com/uk-news/2020/feb/04/northern-powerhouse-rail-backers-say-hs2-vital-success",
    "urlToImage": "https://i.guim.co.uk/img/media/7c118c1a192d8279c3086fc20aa1baa68a304ecf/0_0_10667_6401/master/10667.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=e1c32a2148b9595e93a412b4e985169e",
    "publishedAt": "2020-02-04T07:00:00Z",
    "content": "One of the most popular arguments against HS2 is that billions would be better spent on a new Transpennine rail line called Northern Powerhouse Rail (NPR), as well as local transport upgrades if the governments goal is to level up the country and close the ga… [+5967 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580799600000
}, {
    "source": {
        "id": null,
        "name": "Poundsterlinglive.com"
    },
    "author": "Gary Howes",
    "title": "Pound Sterling Steadies after Sharp Declines, Analysts Hold Downside Bias against Euro and Dollar - Pound Sterling Live",
    "description": "The British Pound sold off sharply on the first trading day of February, with analysts citing position squaring, a reversal of positive month-end flows and political developments for the move",
    "url": "https://www.poundsterlinglive.com/gbp-live-today/12738-pound-to-euro-and-dollar-outlook-following-barnier-johnson-speeches",
    "urlToImage": "https://www.poundsterlinglive.com/images/stock/barnier-lays-out-EU-negotiating-position.jpg",
    "publishedAt": "2020-02-04T06:29:00Z",
    "content": "- GBP in sharp devaluation at start of new month- Follow-through losses are possible- Markets turn focus to tough EU-UK trade negotiations\r\nAbove: Michel Barnier, Head of Task Force for Relations with the United Kingdom, holds a press conference on the draft … [+8418 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580797740000
}, {
    "source": {
        "id": null,
        "name": "Sciencealert.com"
    },
    "author": "Carly Cassella",
    "title": "Cigarettes Produce Invisible Chemical Emissions Even After They've Been Extinguished - ScienceAlert",
    "description": "Cigarettes aren't just toxic when they're being smoked. Even when the butts are scrunched up and cold, new research has found they continue to emit harmful compounds in the air.",
    "url": "https://www.sciencealert.com/cigarettes-produce-invisible-chemical-emissions-even-after-they-ve-been-extinguished",
    "urlToImage": "https://www.sciencealert.com/images/2020-02/processed/cigarettebuttsashtray_1024.jpg",
    "publishedAt": "2020-02-04T06:01:29Z",
    "content": "Cigarettes aren't just toxic when they're being smoked. Even when the butts are scrunched up and cold, new research has found they continue to emit harmful compounds in the air.\r\nIn the first 24 hours alone, scientists say a used cigarette butt will produce 1… [+3217 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580796089000
}, {
    "source": {
        "id": null,
        "name": "Telegraph.co.uk"
    },
    "author": null,
    "title": "BT left me angry and exasperated – it’s no wonder Britain is so far behind on fibre - Telegraph.co.uk",
    "description": "There is no reason why switching broadband provider should be a stressful experience &ndash; no more so at least than moving house or assembling IKEA furniture.",
    "url": "https://www.telegraph.co.uk/technology/2020/02/04/bt-left-angry-exasperated-no-wonder-britain-far-behind-fibre/",
    "urlToImage": "https://www.telegraph.co.uk/content/dam/bills-and-utilities/2017/04/20/124767072_REUTERS_FILE-PHOTO-A-BT-Openreach-van-is-seen-parked-in-central-London-xlarge_trans_NvBQzQNjv4Bq4d0Vs6-dQkYv8FTFVrAejKCwx9k2f2K5xGGPVlEYjmQ.jpg?imwidth=1200",
    "publishedAt": "2020-02-04T06:00:00Z",
    "content": "When Openreach turned up for what we assumed would be a simple line change, the engineer declared what we had been told on the phone was wrong. He was gone before we were able to extract from him a clear answer. \r\nOn the phone, BT customer service confidently… [+1968 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580796000000
}, {
    "source": {
        "id": null,
        "name": "Countypress.co.uk"
    },
    "author": "Joshua Silverwood",
    "title": "Drink driver fancied fast food — and was caught at McDonald's drive through - Isle of Wight County Press",
    "description": "A DISQUALIFIED driver borrowed his dad's car because he fancied some fast food — and was caught drink driving at the McDonald's drive-through.",
    "url": "https://www.countypress.co.uk/news/18203003.drink-driver-fancied-fast-food-stopped-mcdonalds-drive----ended-isle-wight-magistrates-court/",
    "urlToImage": "https://www.countypress.co.uk/resources/images/10971636/",
    "publishedAt": "2020-02-04T06:00:00Z",
    "content": "A DISQUALIFIED driver borrowed his dad's car because he fancied some fast food — and was caught drink driving at the McDonald's drive-through.\r\nCallum Andrew Downer, 27, of Medeway, Sandown, pleaded guilty to drink driving, driving while disqualified and driv… [+1633 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580796000000
}, {
    "source": {
        "id": "bbc-news",
        "name": "BBC News"
    },
    "author": "https://www.facebook.com/bbcnews",
    "title": "Coronavirus: 'We may have no clothes left to sell' - BBC News",
    "description": "We talk to UK firms affected by the disruption caused by the deadly virus.",
    "url": "https://www.bbc.co.uk/news/business-51357030",
    "urlToImage": "https://ichef.bbci.co.uk/news/1024/branded_news/6225/production/_110752152_image-v1.jpg",
    "publishedAt": "2020-02-04T05:39:11Z",
    "content": "Image copyrightXUZHI CHENImage caption\r\n Xuzhi Chen is a London-based fashion designer\r\n\"At the moment, we'll have no products to sell and we could miss Fashion Week in Europe,\" says Xuzhi Chen, a fashion designer who runs just one of the UK businesses affect… [+4533 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580794751000
}, {
    "source": {
        "id": null,
        "name": "Dorsetecho.co.uk"
    },
    "author": "Trevor Bevins",
    "title": "Planning battle over Colwell shopping centre in Weymouth - Dorset Echo",
    "description": "REDEVELOPMENT of Weymouth’s former Colwell Shopping Centre may now be decided by a planning appeal.",
    "url": "https://www.dorsetecho.co.uk/news/18207996.planning-battle-former-shopping-centre-weymouth/",
    "urlToImage": "https://www.dorsetecho.co.uk/resources/images/10980976/",
    "publishedAt": "2020-02-04T05:00:00Z",
    "content": "REDEVELOPMENT of Weymouth’s former Colwell Shopping Centre may now be decided by a planning appeal.\r\nIn principle consent was granted in February 2016 for demolition and the existing buildings and the construction of two new shop units and 23 apartments – but… [+2530 chars]",
    "country": "gb",
    "category": "business",
    "datetime": 1580792400000
}, {
    "source": {
        "id": "cnn",
        "name": "CNN"
    },
    "author": "Sarah Moon and Hollie Silverman, CNN",
    "title": "The bodies of Kobe Bryant and 8 others killed in helicopter crash have been released to their families - CNN",
    "description": "The bodies of Kobe Bryant, his daughter Gianna, and seven other people killed in a helicopter crash last month in Calabasas, California, have been released to their families, according to the website for the Los Angeles County Medical Examiner-Coroner.",
    "url": "https://www.cnn.com/2020/02/04/us/kobe-bryant-crash-bodies-911-calls-released/index.html",
    "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/200128093456-helicopter-crash-victims-split-super-tease.jpg",
    "publishedAt": "2020-02-04T07:01:00Z",
    "content": "(CNN)The bodies of Kobe Bryant, his daughter Gianna, and seven other people killed in a helicopter crash last month in Calabasas, California, have been released to their families, according to the website for the Los Angeles County Medical Examiner-Coroner.\r\n… [+2357 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580799660000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Post Game Report: Kristaps Porzingis - Dallas Mavericks",
    "description": "Mavs Kristaps Porzingis speaks to media after the Dallas Mavericks defeat the Indiana Pacers on the road.",
    "url": "https://www.youtube.com/watch?v=9jY9gDrZLAs",
    "urlToImage": "https://i.ytimg.com/vi/9jY9gDrZLAs/maxresdefault.jpg",
    "publishedAt": "2020-02-04T06:57:28Z",
    "content": null,
    "country": "us",
    "category": "sports",
    "datetime": 1580799448000
}, {
    "source": {
        "id": null,
        "name": "Nbcsports.com"
    },
    "author": null,
    "title": "Report: Dubs rejected two firsts from T-Wolves for D-Lo - NBCSports.com",
    "description": "There's a bottleneck forming ahead of Thursday's NBA trade deadline, and the Warriors reportedly are at the center of it.",
    "url": "https://www.nbcsports.com/bayarea/warriors/nba-rumors-warriors-nixed-timberwolves-dangelo-russell-trade-offer",
    "urlToImage": "https://www.nbcsports.com/bayarea/sites/csnbayarea/files/2020/02/03/dlotwolvesusatsi.jpg",
    "publishedAt": "2020-02-04T06:38:57Z",
    "content": "As Steve Kerr walked into Capital One Arena on Monday night for a game against the Wizards, the Warriors' coach was at least mildly concerned with how his roster would respond to being subjected to relentless trade buzz.\r\nIt affects everybody, Kerr told repor… [+4117 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580798337000
}, {
    "source": {
        "id": null,
        "name": "Espn.com"
    },
    "author": null,
    "title": "Grizzlies' Dillon Brooks relishes chance to play Andre Iguodala after trade - ESPN",
    "description": "Memphis guard Dillon Brooks said he hopes the Grizzlies' front office deals Andre Iguodala before Thursday's trade deadline so they can \"play him and show what really Memphis is about.\"",
    "url": "https://www.espn.com/nba/story/_/id/28631360/grizzlies-dillon-brooks-relishes-chance-play-andre-iguodala-trade",
    "urlToImage": "https://a4.espncdn.com/combiner/i?img=%2Fphoto%2F2019%2F0520%2Fr545838_1296x729_16%2D9.jpg",
    "publishedAt": "2020-02-04T06:05:10Z",
    "content": "Andre Iguodala hasn't played a minute for the surprising Memphis Grizzlies this season, and come Thursday's trade deadline, there's a good chance he never will.\r\nDillon Brooks is among those on Memphis hoping that's the case.\r\nWith the trade deadline looming,… [+1572 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580796310000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "SPURS at CLIPPERS | FULL GAME HIGHLIGHTS | February 3, 2020 - NBA",
    "description": "SPURS at CLIPPERS | FULL GAME HIGHLIGHTS | February 3, 2020 The L.A. Clippers defeated the San Antonio Spurs, 108-105. Kawhi Leonard recorded 22 PTS, 6 REB a...",
    "url": "https://www.youtube.com/watch?v=CoBlWB2_VJY",
    "urlToImage": "https://i.ytimg.com/vi/CoBlWB2_VJY/maxresdefault.jpg",
    "publishedAt": "2020-02-04T06:01:49Z",
    "content": "SPURS at CLIPPERS | FULL GAME HIGHLIGHTS | February 3, 2020\r\nThe L.A. Clippers defeated the San Antonio Spurs, 108-105. Kawhi Leonard recorded 22 PTS, 6 REB and 7 AST for the Clippers, while Paul George added 19 PTS, a season-high 12 REB, and 8 AST in the vic… [+487 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580796109000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "TIMBERWOLVES at KINGS | FULL GAME HIGHLIGHTS | February 3, 2020 - NBA",
    "description": "TIMBERWOLVES at KINGS | FULL GAME HIGHLIGHTS | February 3, 2020 The Sacramento Kings defeated the Minnesota Timberwolves, 113-109. De’Aaron Fox led the way f...",
    "url": "https://www.youtube.com/watch?v=K6Y-5CZNMd0",
    "urlToImage": "https://i.ytimg.com/vi/K6Y-5CZNMd0/maxresdefault.jpg",
    "publishedAt": "2020-02-04T05:51:01Z",
    "content": null,
    "country": "us",
    "category": "sports",
    "datetime": 1580795461000
}, {
    "source": {
        "id": null,
        "name": "Theringer.com"
    },
    "author": "Kevin O'Connor",
    "title": "NBA Trade Deadline Buzz: The D’Angelo Russell Question - The Ringer",
    "description": "How the Golden State Warriors’ decision on Russell ahead of Thursday’s NBA trade deadline could affect the futures of Clint Capela, Robert Covington, and more",
    "url": "https://www.theringer.com/nba/2020/2/3/21121918/trade-deadline-dangelo-russell-clint-capela-robert-covington",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/4rEz5cnINQzIKBFBjv9AfCT8FeI=/0x0:3000x1571/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19682807/KOCTradeBuzz_Getty_Ringer.jpg",
    "publishedAt": "2020-02-04T04:54:22Z",
    "content": "The future of DAngelo Russell has become the biggest question at the NBAs trade deadline. But before Russell can be dealt, other dominoes will need to fall. The Wolves are in hot pursuit of Russell and are searching for assets to put together an offer that is… [+6685 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580792062000
}, {
    "source": {
        "id": null,
        "name": "Espn.com"
    },
    "author": null,
    "title": "Jimmy Butler scores season-high 38 as Ben Simmons calls 76ers 'soft' - ESPN",
    "description": "Heat star Jimmy Butler scored a season-high 38 points Monday night as Miami handed Philadelphia its worst loss of the season.",
    "url": "https://www.espn.com/nba/story/_/id/28631196/jimmy-butler-scores-season-high-38-ben-simmons-calls-76ers-soft",
    "urlToImage": "https://a2.espncdn.com/combiner/i?img=%2Fphoto%2F2020%2F0204%2Fr661453_1296x729_16%2D9.jpg",
    "publishedAt": "2020-02-04T04:48:26Z",
    "content": "MIAMI -- Heat star Jimmy Butler cruised to a season-high 38 points on Monday, as Miami handed the Philadelphia 76ers their worst loss of the season 137-106.\r\nIt was simply Butler's night against his former team. He went 14-of-20 from the field, 2-of-2 from 3 … [+3418 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580791706000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Andrew Court For Dailymail.com",
    "title": "Tom Brady's possessions are loaded into a moving truck outside the Massachusetts mansion - Daily Mail",
    "description": "On Monday, a moving truck was seen outside the star's $33.9 million Boston home he shares with wife Giselle Bundchen and their three children.",
    "url": "https://www.dailymail.co.uk/news/article-7963003/Tom-Bradys-possessions-loaded-moving-truck-outside-Massachusetts-mansion.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/03/24275366-0-image-a-33_1580787106369.jpg",
    "publishedAt": "2020-02-04T03:33:00Z",
    "content": "Tom Brady proclaimed he 'wasn't going anywhere' during a Super Bowl commercial which aired on Sunday, but new pictures taken outside his Massachusetts mansion appear to tell a different story. \r\nOn Monday, a moving truck was seen outside the star's $33.9 mill… [+4649 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580787180000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "NHL Highlights | Flyers @ Red Wings 2/3/20 - NHL",
    "description": "Extended highlights of the Philadelphia Flyers at the Detroit Red Wings",
    "url": "https://www.youtube.com/watch?v=Wq6JkR9XQAk",
    "urlToImage": "https://i.ytimg.com/vi/Wq6JkR9XQAk/maxresdefault.jpg",
    "publishedAt": "2020-02-04T03:28:05Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "us",
    "category": "sports",
    "datetime": 1580786885000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Sleepy Super Bowl fan goes viral for taking nap during game - ABC News",
    "description": "This Super Bowl attendee went viral after being caught on camera taking a very expensive nap during the first quarter of the big game. SUBSCRIBE to ABC NEWS:...",
    "url": "https://www.youtube.com/watch?v=lbDyP-JMCYg",
    "urlToImage": "https://i.ytimg.com/vi/lbDyP-JMCYg/maxresdefault.jpg",
    "publishedAt": "2020-02-04T03:17:50Z",
    "content": "This Super Bowl attendee went viral after being caught on camera taking a very expensive nap during the first quarter of the big game.\r\nSUBSCRIBE to ABC NEWS: https://www.youtube.com/ABCNews/Watch More on http://abcnews.go.com/LIKE ABC News on FACEBOOKhttps:/… [+183 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580786270000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "NHL Highlights | Dallas Stars vs. New York Rangers – Feb. 3, 2020 - SPORTSNET",
    "description": "Joe Pavelski scored two power plays goals as the Dallas Stars beat the New York Rangers 5-3.",
    "url": "https://www.youtube.com/watch?v=fW0y9ZjpVsU",
    "urlToImage": "https://i.ytimg.com/vi/fW0y9ZjpVsU/maxresdefault.jpg",
    "publishedAt": "2020-02-04T03:10:35Z",
    "content": null,
    "country": "us",
    "category": "sports",
    "datetime": 1580785835000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "SUNS at NETS | FULL GAME HIGHLIGHTS | February 3, 2020 - NBA",
    "description": "SUNS at NETS | FULL GAME HIGHLIGHTS | February 3, 2020 The Brooklyn Nets defeated the Phoenix Suns, 119-97. Caris LeVert led the way for the Nets with a care...",
    "url": "https://www.youtube.com/watch?v=jGGfwO7VTLw",
    "urlToImage": "https://i.ytimg.com/vi/jGGfwO7VTLw/maxresdefault.jpg",
    "publishedAt": "2020-02-04T02:57:49Z",
    "content": "SUNS at NETS | FULL GAME HIGHLIGHTS | February 3, 2020\r\nThe Brooklyn Nets defeated the Phoenix Suns, 119-97. Caris LeVert led the way for the Nets with a career-high tying 29 PTS, along with a season-high 7 AST, while Deandre Ayton tallied 25 PTS, 17 REB and … [+436 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580785069000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "NHL Highlights | Panthers @ Maple Leafs 2/3/20 - NHL",
    "description": "Extended highlights of the Florida Panthers at the Toronto Maple Leafs",
    "url": "https://www.youtube.com/watch?v=Z0kC_nldklY",
    "urlToImage": "https://i.ytimg.com/vi/Z0kC_nldklY/maxresdefault.jpg",
    "publishedAt": "2020-02-04T02:57:21Z",
    "content": "Extended highlights of the Florida Panthers at the Toronto Maple Leafs",
    "country": "us",
    "category": "sports",
    "datetime": 1580785041000
}, {
    "source": {
        "id": null,
        "name": "Latimes.com"
    },
    "author": "Dylan Hernández",
    "title": "Dodgers must seize the moment and grab Mookie Betts - Los Angeles Times",
    "description": "The Dodgers boast about their analytical approach and stocked farm system, yet their best asset is financial strength. They might as well use it for Mookie Betts.",
    "url": "https://www.latimes.com/sports/dodgers/story/2020-02-03/dodgers-must-seize-moment-acquire-mookie-betts-red-sox",
    "urlToImage": "https://ca-times.brightspotcdn.com/dims4/default/3e61421/2147483647/strip/true/crop/5472x2873+0+0/resize/1200x630!/quality/90/?url=https%3A%2F%2Fcalifornia-times-brightspot.s3.amazonaws.com%2F21%2F16%2Fb53c7d9a482d90ad74c72d025bb4%2Fhttps-delivery.gettyimages.com%2Fdownloads%2F1171632578.jpg",
    "publishedAt": "2020-02-04T02:47:00Z",
    "content": "They were interested in Bryce Harper, but didnt sign him.\r\nThey wanted Gerrit Cole, but didnt land him, either.\r\nThe Dodgers are now in the market for Mookie Betts, and a potential obstacle is one with which they are familiar: Money.\r\nThe fact they would like… [+4872 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580784420000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Basketball Team Manager Has Surprising Moment On The Court | NBC Nightly News - NBC News",
    "description": "Atlanta’s Pace Academy Varsity basketball coach had a surprise for their team manager last week. For the team’s senior night, Daniel Lucke had a chance to en...",
    "url": "https://www.youtube.com/watch?v=JvyJrSKrT1E",
    "urlToImage": "https://i.ytimg.com/vi/JvyJrSKrT1E/maxresdefault.jpg",
    "publishedAt": "2020-02-04T02:46:15Z",
    "content": "Atlantas Pace Academy Varsity basketball coach had a surprise for their team manager last week. For the teams senior night, Daniel Lucke had a chance to enter the game, and scored an amazing 3-point shot at the buzzer.» Subscribe to NBC News: http://nbcnews.t… [+927 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580784375000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "KNICKS at CAVALIERS | FULL GAME HIGHLIGHTS | February 3, 2020 - NBA",
    "description": "KNICKS at CAVALIERS | FULL GAME HIGHLIGHTS | February 3, 2020 The New York Knicks defeated the Cleveland Cavaliers, 139-134, in overtime. Elfrid Payton recor...",
    "url": "https://www.youtube.com/watch?v=HNeoayUOVjM",
    "urlToImage": "https://i.ytimg.com/vi/HNeoayUOVjM/maxresdefault.jpg",
    "publishedAt": "2020-02-04T02:43:46Z",
    "content": null,
    "country": "us",
    "category": "sports",
    "datetime": 1580784226000
}, {
    "source": {
        "id": null,
        "name": "Espn.com"
    },
    "author": null,
    "title": "Brooks Koepka won't agree to midround TV interviews -- 'I don't get it' - ESPN",
    "description": "Brooks Koepka said \"no thanks\" to midround TV interviews in the wake of Graeme McDowell getting a slow playing warning last week in Saudi Arabia.",
    "url": "https://www.espn.com/golf/story/_/id/28630508/brooks-koepka-agree-midround-tv-interviews-get-it",
    "urlToImage": "https://a4.espncdn.com/combiner/i?img=%2Fphoto%2F2019%2F0611%2Fr555192_1296x729_16%2D9.jpg",
    "publishedAt": "2020-02-04T02:30:39Z",
    "content": "In the wake of Graeme McDowell getting a slow playing warning last week in Saudi Arabia after consenting to a midround TV interview, Brooks Koepka said \"no thanks'' to such requests.\r\nKoepka, who finished tied for 17th in the event and will lose his No. 1 ran… [+1476 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580783439000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "Statement made: Ducks down UConn for program's first top-five road victory - Pac-12 Networks",
    "description": "Sabrina Ionescu nearly records another triple-double with 10 points, 9 rebounds and 9 assists as No. 3 Oregon takes down No. 4 UConn by a 74-56 final Monday ...",
    "url": "https://www.youtube.com/watch?v=57HJ0XGbpNI",
    "urlToImage": "https://i.ytimg.com/vi/57HJ0XGbpNI/maxresdefault.jpg",
    "publishedAt": "2020-02-04T02:28:14Z",
    "content": "Sabrina Ionescu nearly records another triple-double with 10 points, 9 rebounds and 9 assists as No. 3 Oregon takes down No. 4 UConn by a 74-56 final Monday in Storrs, Connecticut. Ruthy Hebard had a game-high 22 points while also grabbing 12 boards. Satou Sa… [+166 chars]",
    "country": "us",
    "category": "sports",
    "datetime": 1580783294000
}, {
    "source": {
        "id": null,
        "name": "Youtube.com"
    },
    "author": null,
    "title": "MAGIC at HORNETS | FULL GAME HIGHLIGHTS | February 3, 2020 - NBA",
    "description": "MAGIC at HORNETS | FULL GAME HIGHLIGHTS | February 3, 2020 The Orlando Magic defeated the Charlotte Hornets, 112-100. Nikola Vucevic led the Magic with 22 PT...",
    "url": "https://www.youtube.com/watch?v=kgmMbLFfE90",
    "urlToImage": "https://i.ytimg.com/vi/kgmMbLFfE90/maxresdefault.jpg",
    "publishedAt": "2020-02-04T02:17:15Z",
    "content": "[[getSimpleString(data.title)]]\r\n[[getSimpleString(data.description)]]\r\n[[getSimpleString(data.videoCountText)]]",
    "country": "us",
    "category": "sports",
    "datetime": 1580782635000
}, {
    "source": {
        "id": "the-verge",
        "name": "The Verge"
    },
    "author": "Tom Warren",
    "title": "Google admits it sent private videos in Google Photos to strangers - The Verge",
    "description": "Google has revealed it accidentally sent some private videos stored in Google Photos to strangers. The mishap happened for five days last year, and has since been fixed.",
    "url": "https://www.theverge.com/2020/2/4/21122044/google-photos-privacy-breach-takeout-data-video-strangers",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/x5bPoUvbJhKWBIxX7LV2j_Bpi_8=/0x146:2040x1214/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19287010/acastro_191014_1777_google_pixel_0005.0.jpg",
    "publishedAt": "2020-02-04T09:37:30Z",
    "content": "The privacy breach affected a small number of Google Photos users\r\nIllustration by Alex Castro / The Verge\r\nGoogle is alerting some users of its Google Photos service that theyve had their private videos sent to strangers by the search giant. Googles Takeout … [+1209 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580809050000
}, {
    "source": {
        "id": null,
        "name": "Nintendolife.com"
    },
    "author": "Nintendo Life",
    "title": "Random: Back The Wonderful 101 Remaster On Kickstarter And Get Blocked By Hideki Kamiya - Nintendo Life",
    "description": "Are you insects listening?",
    "url": "http://www.nintendolife.com/news/2020/02/random_back_the_wonderful_101_remaster_on_kickstarter_and_get_blocked_by_hideki_kamiya",
    "urlToImage": "http://images.nintendolife.com/3e468197f04b8/1280x720.jpg",
    "publishedAt": "2020-02-04T07:30:00Z",
    "content": "He is \"really fed up with insects\"\r\nIn what's possibly a Kickstarter first, you can now pay money to get blocked. If the headline wasn't enough of an idea about what's going, we're referring to the recently launched project for the remastered version of The W… [+856 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580801400000
}, {
    "source": {
        "id": null,
        "name": "Androidauthority.com"
    },
    "author": null,
    "title": "Google confirms decline in hardware sales: Is Pixel 4 to blame? - Android Authority",
    "description": "Google specifically pointed out some devices that sold well, but the Pixel 4 series wasn't one of them.",
    "url": "https://www.androidauthority.com/google-hardware-sales-q4-2019-1079681/",
    "urlToImage": "https://cdn57.androidauthority.net/wp-content/uploads/2019/10/Google-Pixel-4-colors-and-camera-closeup-920x470.jpg",
    "publishedAt": "2020-02-04T05:40:55Z",
    "content": "Alphabet held its Q4 2019 earnings call yesterday (February 3), and we learned how much money YouTube is making for the first time. The Google parent company also shed some light on hardware sales, painting what seems to be a mixed picture.\r\nAlphabet didn’t g… [+1419 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580794855000
}, {
    "source": {
        "id": null,
        "name": "Gamespot.com"
    },
    "author": "Eddie Makuch",
    "title": "Last Of Us 2's Rating Has Been Revealed, And It Sounds Very Violent And Graphic - GameSpot",
    "description": "It looks like The Last of Us 2 will once again be a violent game.",
    "url": "https://www.gamespot.com/articles/last-of-us-2s-rating-has-been-revealed-and-it-soun/1100-6473332/",
    "urlToImage": "https://gamespot1.cbsistatic.com/uploads/screen_kubrick/1179/11799911/3631979-last.jpg",
    "publishedAt": "2020-02-04T04:40:00Z",
    "content": "The Last of Us: Part II will reportedly carry an M for Mature rating in the United States. The game's website (via Dualshockers) shows the M rating from the ESRB, but the ratings group has yet to officially publish its rating for the game, so it may only be a… [+2681 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580791200000
}, {
    "source": {
        "id": null,
        "name": "Slashgear.com"
    },
    "author": "Ewdison Then",
    "title": "Motorla Razr first impressions are unflattering - SlashGear",
    "description": "Although the Galaxy Z Flip has been rumored far longer, Motorola beat Samsung to the punch by announcing and launching its reborn Razr clamshell ahead of time. Motorola and parent Lenovo have admit…",
    "url": "https://www.slashgear.com/motorla-razr-first-impressions-are-unflattering-03608357/",
    "urlToImage": "https://scdn.slashgear.com/wp-content/uploads/2020/02/motorola-razr-2019-69.jpg",
    "publishedAt": "2020-02-04T03:16:49Z",
    "content": "Although the Galaxy Z Flip has been rumored far longer, Motorola beat Samsung to the punch by announcing and launching its reborn Razr clamshell ahead of time. Motorola and parent Lenovo have admittedly been playing around foldables just as long as anyone els… [+1571 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580786209000
}, {
    "source": {
        "id": "the-verge",
        "name": "The Verge"
    },
    "author": "Sam Byford",
    "title": "The Apple TV app is now available on LG’s 2019 TVs - The Verge",
    "description": "LG has made the Apple TV app available on a variety of its 2019 smart TVs. The app will be on TVs in more than 80 countries.",
    "url": "https://www.theverge.com/2020/2/3/21121647/apple-tv-app-lg-2019-tvs-available",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/77PE4VSQ1XQqfRJ5hGLbFFcTzlk=/0x119:2100x1218/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19682297/Apple_TV_App_Now_on_2019_LG_TVs__011.jpg",
    "publishedAt": "2020-02-04T03:01:12Z",
    "content": "Apple TV+ and iTunes on webOS\r\nLG has made the Apple TV app available on a variety of its 2019 smart TVs as promised, according to a press release from the company. The app will be on TVs in more than 80 countries and gives users access to Apples new Apple TV… [+674 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580785272000
}, {
    "source": {
        "id": null,
        "name": "Gamespot.com"
    },
    "author": "Matt Espineli",
    "title": "Final Fantasy 7 Remake: The Most Intriguing Takeaways And Details From The New Trailer - GameSpot",
    "description": "Jenova, Red-XIII, and a cross-dressing Cloud are only a few of the many new details found in the latest trailer for Final Fantasy 7 Remake on PS4.",
    "url": "https://www.gamespot.com/articles/final-fantasy-7-remake-the-most-intriguing-takeawa/1100-6473284/",
    "urlToImage": "https://gamespot1.cbsistatic.com/uploads/screen_kubrick/1552/15524586/3631453-final-fantasy-7-remake-trailer-welcomes-you-inside-the-honey-bee-inn-1580467351277.jpg",
    "publishedAt": "2020-02-04T01:58:00Z",
    "content": "Final Fantasy VII Remake is only a couple of months away, but in the meantime, the game that started it all is celebrating a birthday. The original FFVII released on the PlayStation 23 years ago, and a new trailer for the Remake pays homage with more characte… [+10303 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580781480000
}, {
    "source": {
        "id": null,
        "name": "Phonearena.com"
    },
    "author": "Cosmin Vasile",
    "title": "One of the oldest Samsung smartwatches gets an important update - PhoneArena",
    "description": "In a surprising move, Samsung has decided to provide Gear S2 users with a new update no less than five years after the smartwatch was launched on the market.",
    "url": "https://www.phonearena.com/news/Samsung-Gear-S2-update-improved-battery-life_id121971",
    "urlToImage": "https://i-cdn.phonearena.com/images/article/121971-two/One-of-the-oldest-Samsung-smartwatches-gets-an-important-update.jpg",
    "publishedAt": "2020-02-04T01:54:00Z",
    "content": "A discussion is a place, where people can voice their opinion, no matter if it is positive, neutral or negative. However, when posting, one must stay true to the topic, and not just share some random thoughts, which are not directly related to the matter.\r\nTh… [+691 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580781240000
}, {
    "source": {
        "id": "google-news",
        "name": "Google News"
    },
    "author": null,
    "title": "Mortal Kombat: Every Character Confirmed For The Movie Reboot - Screen Rant",
    "description": null,
    "url": "https://news.google.com/__i/rss/rd/articles/CBMiR2h0dHBzOi8vc2NyZWVucmFudC5jb20vbW9ydGFsLWtvbWJhdC1tb3ZpZS1yZWJvb3QtY2hhcmFjdGVycy1jb25maXJtZWQv0gFLaHR0cHM6Ly9zY3JlZW5yYW50LmNvbS9tb3J0YWwta29tYmF0LW1vdmllLXJlYm9vdC1jaGFyYWN0ZXJzLWNvbmZpcm1lZC9hbXAv?oc=5",
    "urlToImage": null,
    "publishedAt": "2020-02-04T01:16:38Z",
    "content": null,
    "country": "us",
    "category": "technology",
    "datetime": 1580778998000
}, {
    "source": {
        "id": null,
        "name": "Sciencealert.com"
    },
    "author": "David Nield",
    "title": "New Research Explains How Solar Panels Could Soon Be Generating Power at Night - ScienceAlert",
    "description": "As beneficial as current solar panel technology has been in our quest to switch to renewable energy, such panels can't generate electricity at night. Now, new research suggests it could be possible to design panels that can operate around the clock.",
    "url": "https://www.sciencealert.com/here-s-how-solar-panels-could-soon-be-generating-power-at-night",
    "urlToImage": "https://www.sciencealert.com/images/2020-02/processed/012-solar-panel-night_1024.jpg",
    "publishedAt": "2020-02-04T01:14:09Z",
    "content": "As beneficial as current solar panel technology has been in our quest to switch to renewable energy, such panels can't generate electricity at night. Now, new research suggests it could be possible to design panels that can operate around the clock.\r\nUnder op… [+2918 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580778849000
}, {
    "source": {
        "id": null,
        "name": "Nintendolife.com"
    },
    "author": "Nintendo Life",
    "title": "Daemon X Machina Is No Longer A Switch Exclusive, Arrives On PC This Month - Nintendo Life",
    "description": "Less than six months after its release",
    "url": "http://www.nintendolife.com/news/2020/02/daemon_x_machina_is_no_longer_a_switch_exclusive_arrives_on_pc_this_month",
    "urlToImage": "http://images.nintendolife.com/04c9544064044/1280x720.jpg",
    "publishedAt": "2020-02-04T01:00:00Z",
    "content": "Exclusivity can make or break a video game console. In the case of the Switch, it's made a name for itself over the past few years thanks to a number of highly successful exclusives.\r\nOne title that wasn't as positively received, though, was Daemon X Machina.… [+839 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580778000000
}, {
    "source": {
        "id": null,
        "name": "Jalopnik.com"
    },
    "author": "Erik Shilling",
    "title": "This Is What Happens When You Take Risks, GM - Jalopnik",
    "description": "Production started on the 2020 Corvette today, according to Chevy, following a strike-related delay and the need to finish the last 2019 Corvettes and retool the factory. GM expects to make around 40,000 new ‘Vettes this year, all of which are sold out, the c…",
    "url": "https://jalopnik.com/this-is-what-happens-when-you-take-risks-gm-1841434751",
    "urlToImage": "https://i.kinja-img.com/gawker-media/image/upload/c_fill,f_auto,fl_progressive,g_center,h_675,pg_1,q_80,w_1200/k6tvdb4qjme1cyrlpmek.jpg",
    "publishedAt": "2020-02-04T01:00:00Z",
    "content": "Production started on the 2020 Corvette today, according to Chevy, following a strike-related delay and the need to finish the last 2019 Corvettes and retool the factory. GM expects to make around 40,000 new Vettes this year, all of which are sold out, the co… [+2420 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580778000000
}, {
    "source": {
        "id": null,
        "name": "Anandtech.com"
    },
    "author": "Ryan Smith",
    "title": "JEDEC Updates HBM2 Memory Standard To 3.2 Gbps; Samsung's Flashbolt Memory Nears Production - AnandTech",
    "description": "After a series of piecemeal announcements from different hardware vendors over the past year, the future of High Bandwidth Memory 2 (HBM2) is finally...",
    "url": "https://www.anandtech.com/show/15469/jedec-updates-hbm2-memory-standard-to-32-gbps-samsungs-flashbolt-memory-nears-production",
    "urlToImage": "https://images.anandtech.com/doci/15469/samsung_hbm2_678_678x452.jpg",
    "publishedAt": "2020-02-04T01:00:00Z",
    "content": "After a series of piecemeal announcements from different hardware vendors over the past year, the future of High Bandwidth Memory 2 (HBM2) is finally coming into focus. Continuing the industry’s ongoing momentum with HBM2 technology, late last month JEDEC pub… [+7886 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580778000000
}, {
    "source": {
        "id": null,
        "name": "Foxbusiness.com"
    },
    "author": "Thomas Barrabi",
    "title": "Antonio Brown, Logan Paul agree to boxing match - Fox Business",
    "description": "Officials from streaming service DAZN confirmed to FOX Business that talks are underway with both camps about a potential fight.",
    "url": "https://www.foxbusiness.com/sports/antonio-brown-logan-paul-boxing-match",
    "urlToImage": "https://a57.foxnews.com/static.foxbusiness.com/foxbusiness.com/content/uploads/2020/01/0/0/Brown-Paul-RT.jpg?ve=1&tl=1",
    "publishedAt": "2020-02-04T00:02:00Z",
    "content": "Antonio Brown’s future in the NFL may be in doubt, but the troubled football star is eyeing a potential payday in the form of a celebrity boxing match against YouTube star Logan Paul.\r\nBrown and Paul crossed paths at the Maxim “Havana Nights” Super Bowl party… [+2274 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580774520000
}, {
    "source": {
        "id": null,
        "name": "Gizmodo.com"
    },
    "author": "Victoria Song",
    "title": "Pablo Escobar's Brother Wants to 'Kill Samsung' With Another Folding Phone - Gizmodo",
    "description": "As if the Pablo Escobar Fold 1 wasn’t enough, there is now a second Pablo Escobar-branded folding smartphone. The name? Wait for it—the Pablo Escobar Fold 2.",
    "url": "https://gizmodo.com/pablo-escobars-brother-wants-to-kill-samsung-with-anoth-1841432025",
    "urlToImage": "https://i.kinja-img.com/gawker-media/image/upload/c_fill,f_auto,fl_progressive,g_center,h_675,pg_1,q_80,w_1200/keefwj9wfynyjiujrjmg.png",
    "publishedAt": "2020-02-03T23:38:00Z",
    "content": "As if the Pablo Escobar Fold 1 wasnt enough, there is now a second Pablo Escobar-branded folding smartphone. The name? Wait for itthe Pablo Escobar Fold 2. \r\nLike its predecessor, the Fold 2 is a suspiciously cheap folding phone at $400 and is the brainchild … [+2622 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580773080000
}, {
    "source": {
        "id": null,
        "name": "Gamespot.com"
    },
    "author": "jeremy winslow",
    "title": "Blizzard Responds To Warcraft 3: Reforged Criticism, Patches Coming Soon - GameSpot",
    "description": "Warcraft 3: Reforged has received a hefty amount of criticism since its PC launch last week, and Blizzard has finally responded by apologizing to its fans.",
    "url": "https://www.gamespot.com/articles/blizzard-responds-to-warcraft-3-reforged-criticism/1100-6473335/",
    "urlToImage": "https://gamespot1.cbsistatic.com/uploads/screen_kubrick/1578/15789366/3631978-3459708-warcraft_iii_reforged_human_vs_orc.0.jpg",
    "publishedAt": "2020-02-03T23:23:00Z",
    "content": "After a wave of criticism was directed toward Activision Blizzard for its handling of Warcraft 3: Reforged, the company has issued an apology for the problems and outlined a couple of patches currently in the works.\r\nWarcraft community manager Randy \"Kaivax\" … [+2917 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580772180000
}, {
    "source": {
        "id": null,
        "name": "Androidauthority.com"
    },
    "author": null,
    "title": "TCL put another nail in coffin of BlackBerry smartphones. That makes me sad. - Android Authority",
    "description": "BlackBerry smartphones finally met their demise, as TCL decided to stop designing and making the beleaguered 'Berrys.",
    "url": "https://www.androidauthority.com/blackberry-smartphones-are-dead-1079741/",
    "urlToImage": "https://cdn57.androidauthority.net/wp-content/uploads/2019/02/BlackBerry-Key2-LE-review-9-920x470.jpg",
    "publishedAt": "2020-02-03T22:50:34Z",
    "content": "BlackBerry smartphones were the first smartphones carried by many people around the world. BlackBerrys preceded the iPhone and Android in important ways and helped set the stage for many of the features we rely on today. That’s why it hurts just a little that… [+4009 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580770234000
}, {
    "source": {
        "id": null,
        "name": "Futurism.com"
    },
    "author": null,
    "title": "Idiot Hacks Nintendo Servers, Gets Caught With Child Pornography - Futurism",
    "description": "The FBI seized his electronics and found a folder accurately labeled \"Bad Stuff.\"",
    "url": "https://futurism.com/the-byte/idiot-hacks-nintendo-servers-caught-child-pornography",
    "urlToImage": "https://wp-assets.futurism.com/2020/02/idiots-hack-nintendo-servers-caught-with-child-pornography-768x403.jpg",
    "publishedAt": "2020-02-03T22:25:24Z",
    "content": "Bad Stuff\r\nIn June 2019, FBI agents raided the home of 21-year-old Californian Ryan Hernandez, whom they suspected of hacking multiple servers owned by multinational gaming company Nintendo.\r\nOn the devices they seized, the FBI found thousands of confidential… [+1457 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580768724000
}, {
    "source": {
        "id": null,
        "name": "Gamespot.com"
    },
    "author": "Jordan Ramée",
    "title": "Apex Legends Season 4 Revenant's Abilities And Map Changes Revealed In Season 4 Trailer - GameSpot",
    "description": "Apex Legends Season 4: Assimilation begins February 4 and introduces Revenant and new World's Edge map changes to the battle royale game.",
    "url": "https://www.gamespot.com/articles/apex-legends-season-4-revenants-abilities-and-map-/1100-6473318/",
    "urlToImage": "https://gamespot1.cbsistatic.com/uploads/screen_kubrick/1587/15875866/3631796-rev.jpeg",
    "publishedAt": "2020-02-03T22:16:00Z",
    "content": "The launch trailer for Season 4: Assimilation, the new season for Apex Legends, has released just ahead of the battle royale game's birthday and the start of Year 2. It's embedded below if you haven't seen it yet. The trailer showcases Revenant's abilities, t… [+3772 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580768160000
}, {
    "source": {
        "id": "techcrunch",
        "name": "TechCrunch"
    },
    "author": "Devin Coldewey",
    "title": "Twitter suspends ‘large network’ of fake accounts used to match phone numbers to users - TechCrunch",
    "description": "Twitter announced today that over the holidays it identified and shut down “a large network of fake accounts,” as well as many others “located in a wide range of countries,” collectively abusing a feature that let them match phone numbers to user accounts. Te…",
    "url": "http://techcrunch.com/2020/02/03/twitter-suspends-large-network-of-fake-accounts-used-to-match-phone-numbers-to-users/",
    "urlToImage": "https://techcrunch.com/wp-content/uploads/2019/10/fake-twitter-accounts1.png?w=753",
    "publishedAt": "2020-02-03T22:09:56Z",
    "content": "Twitter announced today that over the holidays it identified and shut down “a large network of fake accounts,” as well as many others “located in a wide range of countries,” collectively abusing a feature that let them match phone numbers to user accounts.\r\nT… [+2627 chars]",
    "country": "us",
    "category": "technology",
    "datetime": 1580767796000
}, {
    "source": {
        "id": "google-news",
        "name": "Google News"
    },
    "author": null,
    "title": "Piers Morgan screams at PETA activist for wanting the word 'pet' banned - Mirror Online",
    "description": null,
    "url": "https://news.google.com/__i/rss/rd/articles/CBMiUmh0dHBzOi8vd3d3Lm1pcnJvci5jby51ay90di90di1uZXdzL3BpZXJzLW1vcmdhbi1zY3JlYW1zLXBldGEtc3Bva2Vzd29tYW4tMjE0MjU4NDnSAVZodHRwczovL3d3dy5taXJyb3IuY28udWsvdHYvdHYtbmV3cy9waWVycy1tb3JnYW4tc2NyZWFtcy1wZXRhLXNwb2tlc3dvbWFuLTIxNDI1ODQ5LmFtcA?oc=5",
    "urlToImage": null,
    "publishedAt": "2020-02-04T09:36:00Z",
    "content": null,
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580808960000
}, {
    "source": {
        "id": null,
        "name": "Sky.com"
    },
    "author": "Lucia Binding",
    "title": "Weinstein accuser Jessica Mann breaks down in court after reading 'father issues' email - Sky News",
    "description": "Ms Mann started crying while reading an email in which she described him as a \"pseudo father\" figure.",
    "url": "https://news.sky.com/story/weinstein-accuser-jessica-mann-breaks-down-in-court-after-reading-father-issues-email-11925898",
    "urlToImage": "https://e3.365dm.com/20/02/1600x900/skynews-jessica-mann-weinstein_4910983.jpg?20200204091856",
    "publishedAt": "2020-02-04T09:27:50Z",
    "content": null,
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580808470000
}, {
    "source": {
        "id": null,
        "name": "Mirror.co.uk"
    },
    "author": "Rose Hill",
    "title": "Piers Morgan riles up Susanna over Kevin Clifton 'bombshell' after pro 'swept her off feet' - Mirror Online",
    "description": "Good Morning Britain's Susanna Reid, 49, was paired with the Strictly Come Dancing professional in 2013 but suffered from the dreaded 'curse' by splitting from her long-term partner just a year later",
    "url": "https://www.mirror.co.uk/tv/tv-news/piers-morgan-riles-up-susanna-21425407",
    "urlToImage": "https://i2-prod.mirror.co.uk/incoming/article21425438.ece/ALTERNATES/s1200/0_EHP_CHP_040220GMB_14889JPG.jpg",
    "publishedAt": "2020-02-04T08:29:00Z",
    "content": "Piers Morgan attempted to irritate Susanna Reid today after teasing that Strictly Come Dancing pro Kevin Clifton would be making a \"bombshell revelation\" while appearing on Good Morning Britain today. \r\nSusanna, 49, was paired with the professional for the da… [+1630 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580804940000
}, {
    "source": {
        "id": "independent",
        "name": "Independent"
    },
    "author": "Roisin O'Connor",
    "title": "Liam Gallagher claims Oasis offered ‘£100m for reunion but Noel turned it down’ - The Independent",
    "description": "Former Oasis star has repeatedly spoken about his wish to get the band back together",
    "url": "https://www.independent.co.uk/arts-entertainment/music/news/liam-gallagher-noel-oasis-reunion-twitter-high-flying-birds-a9315936.html",
    "urlToImage": "https://static.independent.co.uk/s3fs-public/thumbnails/image/2019/09/05/18/gettyimages-1152916699-1.jpg",
    "publishedAt": "2020-02-04T08:05:00Z",
    "content": "Liam Gallagher has claimed his brother Noel turned down a £100m offer for an Oasis reunion tour. \r\nThe artist, who released his latest solo album Why Me? Why Not in September last year, has been regularly tweeting about getting his former band back together. … [+11210 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580803500000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Emily Hennings",
    "title": "Louis Tomlinson says he’s never going on BBC Breakfast again after Louise Minchin clash - Express",
    "description": "BBC BREAKFAST continued yesterday with hosts Dan Walker and Louise Minchin who were joined live in the studio by One Direction star Louis Tomlinson, who is releasing his first solo album.",
    "url": "https://www.express.co.uk/showbiz/tv-radio/1237167/BBC-Louise-Minchin-shut-down-Louis-Tomlinson-1D-One-Direction-BBC-News-video",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/20/750x445/1237167.jpg",
    "publishedAt": "2020-02-04T07:40:00Z",
    "content": null,
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580802000000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Georgina Laud",
    "title": "Queen heartbreak: The tragedy of Sandringham - how Philip will ease Queen’s sadness - Express",
    "description": "QUEEN ELIZABETH II will leave Sandringham in a couple of days and return to Buckingham Palace, but how will Prince Philip ease the Queen's sadness?",
    "url": "https://www.express.co.uk/news/royal/1237150/queen-elizabeth-II-news-sandringham-prince-philip-king-george-VI-dead-royal-latest",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/106/750x445/1237150.jpg",
    "publishedAt": "2020-02-04T07:37:00Z",
    "content": null,
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580801820000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Georgina Laud",
    "title": "Royal FURY: The one 'frustrating' element of Meghan Markle and Prince Harry's royal split - Express",
    "description": "MEGHAN MARKLE and Prince Harry are currently in Canada following the agreement of the Queen that they can leave their senior royal status behind and live independently. But what is the one 'frustrating' part of Harry and Meghan's split for Kate Middleton and …",
    "url": "https://www.express.co.uk/news/royal/1237214/royal-family-news-meghan-markle-prince-harry-split-Kate-Middleton-news-Prince-William",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/106/750x445/1237214.jpg",
    "publishedAt": "2020-02-04T07:34:00Z",
    "content": null,
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580801640000
}, {
    "source": {
        "id": null,
        "name": "Ladbible.com"
    },
    "author": "Jess Hardiman",
    "title": "Billie Eilish Defends Drake's Texts To Her Saying People Are 'So Sensitive' - LADbible",
    "description": "Eilish, who turned 18 in December, revealed last autumn that she and 33-year-old star Drake had been texting",
    "url": "https://www.ladbible.com/entertainment/celebrity-billie-eilish-defends-drakes-texts-to-her-saying-people-are-sensitive-20200204",
    "urlToImage": "https://images.ladbible.com/thumbnail?type=jpeg&url=http://beta.ems.ladbiblegroup.com/s3/content/d82158745e39be005991e1f06c24d17b.png&quality=70&width=808",
    "publishedAt": "2020-02-04T07:32:00Z",
    "content": "Billie Eilish has hit back at the haters who have criticisedDrake - 15 years her senior - for texting her, saying that everybody is simply 'so sensitive' and that there are many other people they should be worrying about.\r\nEilish, who turned 18 in December, r… [+2463 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580801520000
}, {
    "source": {
        "id": null,
        "name": "Standard.co.uk"
    },
    "author": "Rebecca Speare-Cole",
    "title": "Canadians don't want to pay for Prince Harry and Meghan Markle's security costs, survey shows - Evening Standard",
    "description": "",
    "url": "https://www.standard.co.uk/news/world/canada-harry-meghan-markle-duck-duchess-sussex-security-a4352716.html",
    "urlToImage": "https://static.standard.co.uk/s3fs-public/thumbnails/image/2020/02/04/06/MeghanHarry03023030a.jpg",
    "publishedAt": "2020-02-04T07:18:00Z",
    "content": "More than three quarters of Canadians feel their country should not foot the security bill for the Duke and Duchess of Sussex, a new survey suggests.\r\nA total of 77 per cent of respondents said taxpayers should not have to pay the cost of protecting the Susse… [+2058 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580800680000
}, {
    "source": {
        "id": "independent",
        "name": "Independent"
    },
    "author": "Alexandra Pollard",
    "title": "Parasite’s Song Kang-ho: ‘When you’re rich, it’s much easier to be generous’ - The Independent",
    "description": "Bong Joon-ho’s exquisite black comedy thriller is a frontrunner in the Oscars’ Best Picture race. One of its stars, Song Kang-ho, talks to Alexandra Pollard about awards, class and why this is a film without villains",
    "url": "https://www.independent.co.uk/arts-entertainment/films/features/parasite-interview-song-kang-ho-actor-bong-joon-ho-oscars-best-picture-a9311436.html",
    "urlToImage": "https://static.independent.co.uk/s3fs-public/thumbnails/image/2020/01/31/14/pst-sti-pre-01.jpg",
    "publishedAt": "2020-02-04T07:14:00Z",
    "content": "One of the most important exchanges in Parasite could easily be missed on first viewing. The Kim family are bundled around a table having dinner, discussing their wealthy new employers, the Parks. Even though shes rich, shes nice, says Song Kang-hos Ki-taek b… [+7256 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580800440000
}, {
    "source": {
        "id": null,
        "name": "Theguardian.com"
    },
    "author": "Benjamin Lee",
    "title": "Will 2020 be a turning point for female film-makers? - The Guardian",
    "description": "After last month’s Sundance film festival showcased more works than ever from women, a string of blockbusters is set to slowly level the playing field",
    "url": "https://www.theguardian.com/film/2020/feb/04/2020-turning-point-female-film-makers-sundance-festival",
    "urlToImage": "https://i.guim.co.uk/img/media/b91b1a33c2e0bab4daac535946542f6f99724bf9/487_0_2839_1705/master/2839.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=90234faaa068416e05128985aa41c91d",
    "publishedAt": "2020-02-04T07:10:00Z",
    "content": "A funny thing happened on the way to my eighth screening at this years Sundance film festival. Like many major lineups, its front-loaded with most of the biggest premieres taking place within the first weekend and almost three full days in, Id seen some of th… [+5487 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580800200000
}, {
    "source": {
        "id": null,
        "name": "Digitalspy.com"
    },
    "author": null,
    "title": "Neighbours spoilers (February 10 to 14) - digitalspy.com",
    "description": "What's next on Ramsay Street?",
    "url": "https://www.digitalspy.com/soaps/neighbours/a30750514/neighbours-spoilers-jane-harris-return-finn-kelly-father-trent/",
    "urlToImage": "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/neighbours-jane-paul-yashvi-finn-1580736537.jpg?crop=1.00xw:0.502xh;0,0.0624xh&resize=1200:*",
    "publishedAt": "2020-02-04T07:00:00Z",
    "content": "Next week on Neighbours, Finn is forced to face his past, a familiar face makes a return and is the Rebecchi marriage beyond saving?\r\nHere are 10 storylines from the week to look forward to.\r\n1. Jane Harris is back in town\r\nPaul and Terese get a surprise when… [+5504 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580799600000
}, {
    "source": {
        "id": null,
        "name": "Cagesideseats.com"
    },
    "author": "Alex Briggs",
    "title": "WWE Raw results, recap, reactions (Feb. 3, 2020): Determination - Cageside Seats",
    "description": "WWE gave us an incredible episode of “Raw” this week.",
    "url": "https://www.cagesideseats.com/wwe/2020/2/4/21121990/wwe-raw-results-recap-reactions-feb-3-2020-brock-lesnar-ricochet-super-showdown",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/958xMqzwaGPUlFRcqSjQRvVID6Y=/0x0:1200x628/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19683088/062_RAW_02032020ca_6690__86006a570589523f8469ba4ad1ff9bbc.jpg",
    "publishedAt": "2020-02-04T06:00:00Z",
    "content": null,
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580796000000
}, {
    "source": {
        "id": null,
        "name": "Thesun.co.uk"
    },
    "author": "Joe Kasper",
    "title": "Justin Bieber says his drug addiction was so bad he felt like he was ‘dying’ - The Sun",
    "description": "",
    "url": "http://www.thesun.co.uk/tvandshowbiz/10885897/justin-bieber-drug-addiction-dying/",
    "urlToImage": "https://www.thesun.co.uk/wp-content/uploads/2020/02/NINTCHDBPICT000556689640.jpg?strip=all&quality=100&w=1200&h=800&crop=1",
    "publishedAt": "2020-02-04T02:12:00Z",
    "content": "JUSTIN Bieber has revealed his drug addiction was so bad he felt like he was dying.\r\nThe pop star, 25, said he would smoke weed and pop pills as soon as he woke up.\r\n Justin Bieber says his drug addiction was so bad he felt like he was dyingCredit: PA:Press A… [+1425 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580782320000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Ross Ibbetson For Mailonline Charlotte Griffiths for The Mail on Sunday",
    "title": "Princess Beatrice 'furious' after she was forced to delay wedding AGAIN - Daily Mail",
    "description": "Insiders revealed that Beatrice, 31, and Edo Mapelli Mozzi, 36, will marry on May 29, with a reception at Buckingham Palace but no venue for the ceremony has been confirmed.",
    "url": "https://www.dailymail.co.uk/news/article-7963469/Princess-Beatrice-furious-forced-delay-wedding-AGAIN.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/01/24273346-0-image-a-19_1580780999591.jpg",
    "publishedAt": "2020-02-04T02:04:00Z",
    "content": "Princess Beatrice is understood to be furious after she had to delay her wedding date for a second time over the furore surrounding Prince Andrew.\r\nHer father's friendship with paedophile financier Jeffrey Epstein postponed the Queen agreeing a date for her n… [+2294 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580781840000
}, {
    "source": {
        "id": null,
        "name": "Mirror.co.uk"
    },
    "author": "Adenike Adenitire",
    "title": "Nick Lachey responds to ex-wife Jessica Simpson's book saying 'we've all moved on' - Mirror Online",
    "description": "The TV host and former boyband singer spoke out after Jessica shared intimate details of their marriage which ended in 2006",
    "url": "https://www.mirror.co.uk/3am/celebrity-news/nick-lachey-responds-ex-wife-21424555",
    "urlToImage": "https://i2-prod.mirror.co.uk/incoming/article3599737.ece/ALTERNATES/s1200/Nick-Lachey.jpg",
    "publishedAt": "2020-02-04T02:00:00Z",
    "content": "Nick Lachey has said \"we have all moved on\" in response to his ex-wife Jessica Simpson's shocking new memoir, in which she shares candid details about their former marriage.\r\nThe former member of boy band 98 degrees, 46, also said he hasn't read the memoir Op… [+2527 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580781600000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By William Cole For Mailonline",
    "title": "Joaquin Phoenix curtsies as he greets Prince William at BAFTAs - Daily Mail",
    "description": "Attempting to use royal protocol, the actor, 45, awkwardly curtsied to the Duke of Cambridge who can be heard saying: 'Lovely to meet you'.",
    "url": "https://www.dailymail.co.uk/tvshowbiz/article-7963291/Joaquin-Phoenix-curtsies-greets-Prince-William-BAFTAs.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/01/24273522-0-image-a-8_1580780709352.jpg",
    "publishedAt": "2020-02-04T01:47:00Z",
    "content": "Joaquin Phoenix caused a stir with his BAFTAs appearance - but it's not his win or powerful speech that has people talking. \r\nThe Hollywood star, 45, curtsied heavily to the Duke of Cambridge as they met following the show.  \r\nAttempting to use royal protocol… [+7807 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580780820000
}, {
    "source": {
        "id": "independent",
        "name": "Independent"
    },
    "author": "Annabel Nugent",
    "title": "From Parasite to Us, modern cinema is exposing the scam of the American Dream - The Independent",
    "description": "In their blinkered depictions of class, films such as ‘Working Girl’ and ‘Pretty Woman’ fortify a national delusion of an even playing field, writes Annabel Nugent. But ‘Parasite’ is changing things",
    "url": "https://www.independent.co.uk/arts-entertainment/films/features/parasite-movie-class-inequality-us-american-dream-a9315066.html",
    "urlToImage": "https://static.independent.co.uk/s3fs-public/thumbnails/image/2020/02/03/15/pst-sti-pre-05-1.jpg",
    "publishedAt": "2020-02-04T00:12:00Z",
    "content": "Class is not cool, says writer and activist bell hooks. While race and gender are now fashionable to talk about, class is the paste-eating boy in the class whom everyone awkwardly ignores. And nowhere is its second-rate status in popular culture more observab… [+970 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580775120000
}, {
    "source": {
        "id": null,
        "name": "Mirror.co.uk"
    },
    "author": "Irishmirror.ie",
    "title": "Rio Ferdinand feared he would never be happy again following death of wife Rebecca - Irish Mirror",
    "description": "The former footballer, who lost his first wife Rebecca Ellison to a battle with breast cancer, revealed that he thought he would never find love or happiness again",
    "url": "https://www.mirror.co.uk/3am/celebrity-news/rio-ferdinand-feared-would-never-21423785",
    "urlToImage": "https://i2-prod.mirror.co.uk/incoming/article21422317.ece/ALTERNATES/s1200/4_CS81387128.jpg",
    "publishedAt": "2020-02-04T00:05:00Z",
    "content": "Rio Ferdinand has admitted he feared he would never be happy again following the death of his wife Rebecca in 2015.\r\nHis confession comes in an emotional film in which he says he was not looking for love, but focusing on his three grieving children.\r\nRio, 41,… [+2726 chars]",
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580774700000
}, {
    "source": {
        "id": null,
        "name": "Gamespot.com"
    },
    "author": "Mat Elfring",
    "title": "Marvel Theories For Falcon And Winter Soldier, Loki, WandaVision TV Shows - GameSpot",
    "description": "The Super Bowl delivered new looks at Marvel's WandaVision, The Falcon And The Winter Soldier, and Loki Disney+ shows. Here's some our theories on what could happen in them.",
    "url": "https://www.gamespot.com/gallery/marvel-theories-for-falcon-and-winter-soldier-loki/2900-3371/",
    "urlToImage": "https://gamespot1.cbsistatic.com/uploads/screen_kubrick/1582/15828986/3631690-88xky.00_00_14_12.still012.jpg",
    "publishedAt": "2020-02-04T00:02:00Z",
    "content": null,
    "country": "gb",
    "category": "entertainment",
    "datetime": 1580774520000
}, {
    "source": {
        "id": null,
        "name": "Telegraph.co.uk"
    },
    "author": null,
    "title": "Construction sector shows signs of a rebound – live updates - Telegraph.co.uk",
    "description": "Flat-pack furniture lovers of the west midlands despair &ndash; Swedish furniture seller Ikea apparently plans to close its store in Coventry.",
    "url": "https://www.telegraph.co.uk/business/2020/02/04/markets-live-latest-news-pound-euro-ftse-100/",
    "urlToImage": "https://www.telegraph.co.uk/content/dam/business/2020/02/04/TELEMMGLPICT000106108047-xlarge_trans_NvBQzQNjv4BqkHKcmJXkDkPeJVvcu56MTukwnuvKGWDUgsrHeVN7YYw.jpeg?imwidth=1200",
    "publishedAt": "2020-02-04T10:45:00Z",
    "content": "3) Boris Johnsons election win has triggered the biggest wave of optimism among smaller manufacturers for six years but the surge is yet to translate into fuller order books, the Confederation of British Industry (CBI) has said. The Tory victory in December d… [+2224 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580813100000
}, {
    "source": {
        "id": "talksport",
        "name": "TalkSport"
    },
    "author": "Anton Stanley",
    "title": "Premier League table: talkSPORT Super Computer predicts where every club will finish in 2019/20 campaign - talkSPORT.com",
    "description": "",
    "url": "http://talksport.com/football/664770/premier-league-table-talksport-super-computer-predicts-where-every-club-will-finish-in-2019-20-campaign-february-update/",
    "urlToImage": "https://talksport.com/wp-content/uploads/sites/5/2020/02/TALKSPORT-Chelsea-West-Ham-and-Arsenal.jpg?strip=all&quality=100&w=1200&h=800&crop=1",
    "publishedAt": "2020-02-04T10:26:02Z",
    "content": "Okay, so we know Liverpool are going to win the Premier League – it’s more than 99 per cent certain according to some statistical models.\r\nThe rest of the division, though, is absolute chaos and from second to 20th could all change radically between now and t… [+3025 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580811962000
}, {
    "source": {
        "id": null,
        "name": "Sky.com"
    },
    "author": "Lucia Binding",
    "title": "Weinstein accuser Jessica Mann breaks down in court after reading 'father issues' email - Sky News",
    "description": "Ms Mann started crying while reading an email in which she described him as a \"pseudo father\" figure.",
    "url": "https://news.sky.com/story/weinstein-accuser-jessica-mann-breaks-down-in-court-after-reading-father-issues-email-11925898",
    "urlToImage": "https://e3.365dm.com/20/02/1600x900/skynews-jessica-mann-weinstein_4910983.jpg?20200204091856",
    "publishedAt": "2020-02-04T09:27:50Z",
    "content": null,
    "country": "gb",
    "category": "general",
    "datetime": 1580808470000
}, {
    "source": {
        "id": null,
        "name": "Sky.com"
    },
    "author": "Lucia Binding",
    "title": "Coronavirus: Search for travellers who flew to UK from Wuhan before outbreak continues - Sky News",
    "description": "The travellers had left Wuhan after the virus emerged, but efforts to track them down and assess them began last week.",
    "url": "https://news.sky.com/story/coronavirus-search-for-travellers-who-flew-to-uk-from-wuhan-before-outbreak-continues-11925935",
    "urlToImage": "https://e3.365dm.com/20/02/1600x900/skynews-coronavirus-china_4911021.jpg?20200204075927",
    "publishedAt": "2020-02-04T09:12:01Z",
    "content": null,
    "country": "gb",
    "category": "general",
    "datetime": 1580807521000
}, {
    "source": {
        "id": null,
        "name": "Thesun.co.uk"
    },
    "author": "Les Steed",
    "title": "Coronavirus – 3,700 quarantined on cruise ship off Japan after passenger struck down with deadly bug - The Sun",
    "description": "",
    "url": "http://www.thesun.co.uk/news/10886286/coronavirus-3500-quarantined-on-diamond-princess-cruise-ship-japan-passenger-struck-down-deadly/",
    "urlToImage": "https://www.thesun.co.uk/wp-content/uploads/2020/02/NINTCHDBPICT000559904759.jpg?strip=all&quality=100&w=1024&h=658&crop=1",
    "publishedAt": "2020-02-04T08:42:00Z",
    "content": "JAPAN has quarantined 3,700 people aboard a cruise ship after one of the passengers is diagnosed with the coronavirus.\r\nThe Diamond Princess ended its planned 14-day cruise early and is currently docked at Yokohama, around 22 miles south of central Tokyo, a c… [+2699 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580805720000
}, {
    "source": {
        "id": null,
        "name": "Mirror.co.uk"
    },
    "author": "Bradley Jolly",
    "title": "Gran found dead after being tormented by evil daughter's murder of her grandchildren - Mirror Online",
    "description": "Police confirmed tragic Sharon Porton, whose daughter Louise killed her own two children, was discovered at her home in Willenhall, West Midlands",
    "url": "https://www.mirror.co.uk/news/uk-news/gran-found-dead-after-being-21425253",
    "urlToImage": "https://i2-prod.mirror.co.uk/incoming/article18816963.ece/ALTERNATES/s1200/5_stg_louise_porton_murdered_her_kids02.jpg",
    "publishedAt": "2020-02-04T08:39:00Z",
    "content": "A gran was found dead at her home after being tormented over her evil daughter killing two of her grandchildren. \r\nSharon Porter was discovered at the property in Willenhall, West Midlands, on Sunday.\r\nSuspicious circumstances have been ruled out, police say.… [+2335 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580805540000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By James Tapsfield, Political Editor For Mailonline",
    "title": "Boris Johnson 'faces court battle' over bid to keep terrorists in prison - Daily Mail",
    "description": "Legal experts say the government's emergency legislation will 'certainly' be challenged, as it would apply retrospectively to individuals who have already been sentenced.",
    "url": "https://www.dailymail.co.uk/news/article-7964347/Boris-Johnson-faces-court-battle-bid-terrorists-prison.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/10/24289198-0-image-a-5_1580813268234.jpg",
    "publishedAt": "2020-02-04T08:20:00Z",
    "content": "Sudesh Amman, 20, from Harrow, fantasised about carrying out a terror attack with a blade or with acid while riding a moped and had been jailed in 2018 - before being released a few days ago \r\nBoris Johnson is facing a major court battle over his bid to keep … [+22337 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580804400000
}, {
    "source": {
        "id": "financial-times",
        "name": "Financial Times"
    },
    "author": null,
    "title": "BP boosts dividend despite slide in profits - Financial Times",
    "description": "Lower oil and gas prices drive 26% drop in earnings at energy group",
    "url": "https://www.ft.com/content/3c4232e4-471e-11ea-aeb3-955839e06441",
    "urlToImage": "https://www.ft.com/__origami/service/image/v2/images/raw/http%3A%2F%2Fprod-upp-image-read.ft.com%2F64aa8920-471e-11ea-aeb3-955839e06441?source=next-opengraph&fit=scale-down&width=900",
    "publishedAt": "2020-02-04T07:53:02Z",
    "content": "BP raised its dividend as confidence about its ability to generate more cash grew following the completion of a share buyback programme, new asset disposal targets and falling debt levels. \r\nThe higher payout was announced despite the UK energy major reportin… [+3369 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580802782000
}, {
    "source": {
        "id": null,
        "name": "Manchestereveningnews.co.uk"
    },
    "author": "Charlotte Duncker, Richard Fay",
    "title": "Manchester United transfer news LIVE Odion Ighalo latest as squad number 'revealed' - Manchester Evening News",
    "description": "All the latest Man Utd transfer rumours and injury latest throughout the day.",
    "url": "https://www.manchestereveningnews.co.uk/sport/football/transfer-news/man-utd-transfer-news-live-17682936",
    "urlToImage": "https://i2-prod.manchestereveningnews.co.uk/incoming/article17683014.ece/ALTERNATES/s1200/0_Untitled-design.jpg",
    "publishedAt": "2020-02-04T07:49:29Z",
    "content": "Bournemouth boss Eddie Howe insisted there have been \"no issues\" with forward Josh King after his proposed Manchester United deadline day transfer fell through.\r\nBournemouth rejected United's advances for King as Ole Gunnar Solskjaer sought to boost his strik… [+586 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580802569000
}, {
    "source": {
        "id": null,
        "name": "Theguardian.com"
    },
    "author": "Graham Readfearn",
    "title": "Global heating a serious threat to the world's climate refuges, study finds - The Guardian",
    "description": "Biodiversity hotspots with millions of years of climate stability could be among the world’s hardest hit regions",
    "url": "https://www.theguardian.com/environment/2020/feb/04/global-heating-a-serious-threat-to-the-worlds-climate-refuges-study-finds",
    "urlToImage": "https://i.guim.co.uk/img/media/cd66b159f255d2c23c13ed21177ff04c4419efc5/0_78_5416_3250/master/5416.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=72902cf799bc28d3b5c17e610abad2ad",
    "publishedAt": "2020-02-04T07:43:00Z",
    "content": "Biodiversity hotspots that have given species a safe haven from changing climates for millions of years will come under threat from human-driven global heating, a new study has found.\r\nSpecies that have evolved in tropical regions such Australias wet tropics,… [+3920 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580802180000
}, {
    "source": {
        "id": null,
        "name": "Theguardian.com"
    },
    "author": "Rowena Mason, Fiona Harvey",
    "title": "Boris Johnson doesn’t get climate change, says sacked COP 26 chair - The Guardian",
    "description": "Claire O’Neill says prime minister’s promises of action are not close to being met",
    "url": "https://www.theguardian.com/environment/2020/feb/04/sacked-cop-26-chair-claire-oneill-berates-boris-johnson-over-climate-record",
    "urlToImage": "https://i.guim.co.uk/img/media/6caddb9759b9968003e022181e4386b1ea1e00d7/0_167_4724_2835/master/4724.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=d87dfc576d09452c2e639f7013109a1f",
    "publishedAt": "2020-02-04T07:42:00Z",
    "content": "Boris Johnson has shown a huge lack of leadership and engagement over the UKs hosting of the COP 26 global climate change conference and admitted he does not understand the issue, according to Claire ONeill, the sacked head of the summit.\r\nThe former minister… [+4032 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580802120000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Nathan Salt For Mailonline",
    "title": "Frank Lampard 'set to clash with Chelsea board over long-term future of Kepa Arrizabalaga' - Daily Mail",
    "description": "Frank Lampard is facing a battle with Chelsea's board over the future of No 1 goalkeeper Kepa Arrizabalaga after dropping the world's most expensive stopper for the trip to Leicester City.",
    "url": "https://www.dailymail.co.uk/sport/football/article-7964225/Frank-Lampard-set-clash-board-long-term-future-Kepa-Arrizabalaga.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/07/24282684-0-image-a-4_1580801013452.jpg",
    "publishedAt": "2020-02-04T07:33:00Z",
    "content": "Frank Lampard is facing a battle with Chelsea's board over the future of No 1 goalkeeper Kepa Arrizabalaga. \r\nThe Spaniard, who remains the world's most expensive goalkeeper following his £71.6million move to Stamford Bridge in 2018, was dropped by Lampard fo… [+2314 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580801580000
}, {
    "source": {
        "id": null,
        "name": "Telegraph.co.uk"
    },
    "author": "By\nNick Allen",
    "title": "Iowa caucus: Night of confusion as Bernie Sanders and Pete Buttigieg claim victory in first Democratic vote - Telegraph.co.uk",
    "description": "The Democratic race for the presidential nomination was left in turmoil as results at the first vote in Iowa were indefinitely delayed.",
    "url": "https://www.telegraph.co.uk/news/2020/02/04/bernie-sanders-pete-buttigieg-claim-victory-first-democrat-primary/",
    "urlToImage": "https://img.youtube.com/vi/cTnM870CCu8/mqdefault.jpg",
    "publishedAt": "2020-02-04T07:29:00Z",
    "content": "The Democratic race for the presidential nomination was left in turmoil as results at the first vote in Iowa were indefinitely delayed.\r\nIssues with a mobile phone app and inconsistencies in reporting were blamed for the disaster on a frustrating night for th… [+4232 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580801340000
}, {
    "source": {
        "id": "independent",
        "name": "Independent"
    },
    "author": "Roisin O'Connor",
    "title": "Love Island contestant Amy Hart calls second villa Casa Amor ‘mentally torturous’ - The Independent",
    "description": "Hart previously said she became concerned about her mental health during her time on the show",
    "url": "https://www.independent.co.uk/arts-entertainment/tv/news/love-island-amy-hart-casa-amor-boys-girls-shaughna-callum-molly-mental-health-a9315886.html",
    "urlToImage": "https://static.independent.co.uk/s3fs-public/thumbnails/image/2019/07/11/13/love-island-sr5-ep31-06.jpg",
    "publishedAt": "2020-02-04T07:20:00Z",
    "content": "Former Love Islandcontestant Amy Hart has branded the second villa, Casa Amor, as pure hell and mentally torturous.\r\nHart, 27, was the subject of widespread concern after being heartbroken when her former partner, Curtis Pritchard, returned to the main house … [+6802 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580800800000
}, {
    "source": {
        "id": null,
        "name": "Sky.com"
    },
    "author": "Sky",
    "title": "Aviation firms commit to net-zero carbon target - Sky News",
    "description": "The pledge would involve carbon offsetting as well as sustainable fuels but was described as a \"flight of fancy\" by Greenpeace.",
    "url": "https://news.sky.com/story/aviation-firms-commit-to-net-zero-carbon-target-11925910",
    "urlToImage": "https://e3.365dm.com/19/10/1600x900/2371910030882381707_4793864.jpg?20191003075054",
    "publishedAt": "2020-02-04T07:15:39Z",
    "content": null,
    "country": "gb",
    "category": "general",
    "datetime": 1580800539000
}, {
    "source": {
        "id": null,
        "name": "Metro.co.uk"
    },
    "author": "Richard Hartley-Parkinson",
    "title": "Journalists stage mass walk-out after Downing Street bars critical reporters - Metro.co.uk",
    "description": "The BBC's Laura Kuenssberg was one of those journalists who walked out after colleagues were barred from a briefing.",
    "url": "https://metro.co.uk/2020/02/04/journalists-stage-mass-walk-downing-street-bars-critical-reporters-12177787/",
    "urlToImage": "https://i1.wp.com/metro.co.uk/wp-content/uploads/2020/02/PRC_132642547_1580802181.jpg?quality=90&strip=all&w=1200&h=630&crop=1&zoom=1&ssl=1",
    "publishedAt": "2020-02-04T06:30:00Z",
    "content": "The journalists excluded were from outlets viewed as left-wing or critical of the Government\r\nDowning Street ordered senior journalists from some of the UKs major news organisations to leave before a briefing on Boris Johnsons Brexit plans prompting a walkout… [+4838 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580797800000
}, {
    "source": {
        "id": "bbc-news",
        "name": "BBC News"
    },
    "author": "https://www.facebook.com/bbcnews",
    "title": "Kenya's former President Daniel arap Moi dies aged 95 - BBC News",
    "description": "President Kenyatta pays tribute to his former mentor, saying the nation has lost a \"great man\".",
    "url": "https://www.bbc.co.uk/news/world-africa-50238081",
    "urlToImage": "https://ichef.bbci.co.uk/news/1024/branded_news/1668/production/_109463750_gettyimages-51391234.jpg",
    "publishedAt": "2020-02-04T05:15:58Z",
    "content": "Image copyrightGetty ImagesImage caption\r\n Daniel arap Moi served as president from 1978 to 2002\r\nKenya's former President Daniel arap Moi has died at the age of 95.\r\nPresident Uhuru Kenyatta announced his death, saying the nation had lost a \"great man\". \r\nMr… [+5221 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580793358000
}, {
    "source": {
        "id": "bbc-news",
        "name": "BBC News"
    },
    "author": "https://www.facebook.com/bbcnews",
    "title": "Jehovah's Witnesses sued over 'child sex abuse' - BBC News",
    "description": "A former elder, who says he was abused, says the group is \"inadvertently\" protecting child abusers.",
    "url": "https://www.bbc.co.uk/news/uk-51006771",
    "urlToImage": "https://ichef.bbci.co.uk/news/1024/branded_news/176BF/production/_110753959_jwpic5.jpg",
    "publishedAt": "2020-02-04T04:44:51Z",
    "content": "At least 20 former Jehovah's Witnesses are suing the group over historical sexual abuse they say they suffered.\r\nThe group has a policy of not punishing alleged child sex abuse unless a second person, alongside the accuser, has witnessed it - or an abuser con… [+4435 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580791491000
}, {
    "source": {
        "id": null,
        "name": "Sky.com"
    },
    "author": "Sky",
    "title": "Iran, Israel and Malaysia suspected of exploiting Twitter phone number security flaw - Sky News",
    "description": "The company has declined to say how many user phone numbers had been exposed, because it could not identify all the accounts.",
    "url": "https://news.sky.com/story/iran-israel-and-malaysia-suspected-of-exploiting-twitter-phone-number-security-flaw-11925861",
    "urlToImage": "https://e3.365dm.com/20/02/1600x900/skynews-twitter-hacker_4910922.jpg?20200204025756",
    "publishedAt": "2020-02-04T04:14:32Z",
    "content": null,
    "country": "gb",
    "category": "general",
    "datetime": 1580789672000
}, {
    "source": {
        "id": "bbc-news",
        "name": "BBC News"
    },
    "author": null,
    "title": "Serena Williams needs to 'face reality', says coach Patrick Mouratoglou - BBC Sport",
    "description": "Serena Williams needs to \"change her strategy\" and \"face reality\" having not won a Grand Slam title since returning to tennis, says her coach Patrick Mouratoglou.",
    "url": "https://www.bbc.co.uk/sport/tennis/51355748",
    "urlToImage": "https://ichef.bbci.co.uk/onesport/cps/624/cpsprodpb/6E0F/production/_110757182_serena_getty.jpg",
    "publishedAt": "2020-02-04T02:45:49Z",
    "content": "Serena Williams has been coached by Patrick Mouratoglou since 2012\r\nSerena Williams needs to \"change her strategy\" and \"face reality\" having not won a Grand Slam title since returning to tennis, says her coach Patrick Mouratoglou.\r\nThe American 23-time Grand … [+2212 chars]",
    "country": "gb",
    "category": "general",
    "datetime": 1580784349000
}, {
    "source": {
        "id": null,
        "name": "Walesonline.co.uk"
    },
    "author": "Mari Jones, Jillian MacMath",
    "title": "Welshman thought to be first Brit to catch the coronavirus - Wales Online",
    "description": "\"I'm walking proof you can survive the coronavirus\"",
    "url": "https://www.walesonline.co.uk/news/wales-news/welshman-thought-first-brit-catch-17684127",
    "urlToImage": "https://i2-prod.walesonline.co.uk/incoming/article17684068.ece/ALTERNATES/s1200/3_North-Wales-man-with-coronavirus.jpg",
    "publishedAt": "2020-02-04T08:28:00Z",
    "content": "A Welshman working in China is thought to be the first Brit to have caught the potentially fatal coronavirus.\r\nConnor Reed, originally of Llandudno, works at a college in Wuhan and came down with the virus at the beginning of December.\r\n But he didn't know it… [+2181 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580804880000
}, {
    "source": {
        "id": null,
        "name": "Oxfordmail.co.uk"
    },
    "author": "Sophie Grubb",
    "title": "Man on flight from coronavirus-hit Wuhan is in Oxford - Oxford Mail",
    "description": "A MAN who was taken into isolation after returning from coronavirus-hit Wuhan is reportedly being cared for in Oxford.",
    "url": "https://www.oxfordmail.co.uk/news/18208748.man-flight-coronavirus-hit-wuhan-oxford/",
    "urlToImage": "https://www.oxfordmail.co.uk/resources/images/10981978/",
    "publishedAt": "2020-02-04T08:01:00Z",
    "content": "A MAN who was taken into isolation after returning from coronavirus-hit Wuhan is reportedly being cared for in Oxford. \r\nOne of the Britons who returned from China on Sunday has said he now feels 'fine', however, after a cough and sore throat led to precautio… [+4288 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580803260000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Mary Mrad For Daily Mail Australia",
    "title": "Nutritionist reveals her best tricks for boosting your immunity and preventing colds and flus - Daily Mail",
    "description": "From regular exercise to eating antioxidant-rich foods, the founder of Supercharged foods, Lee Holmes, shared exactly how to stay healthy.",
    "url": "https://www.dailymail.co.uk/femail/article-7963163/Nutritionist-reveals-best-tricks-boosting-immunity-preventing-colds-flus.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/01/24273860-0-image-a-16_1580781499501.jpg",
    "publishedAt": "2020-02-04T02:54:00Z",
    "content": "An Australian nutritionist has revealed her top tricks for boosting immunity naturally through simple diet and lifestyle habits.  \r\nFrom regular exercise to eating antioxidant-rich foods, the founder of Supercharged foods, Lee Holmes, shared exactly how to st… [+5635 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580784840000
}, {
    "source": {
        "id": null,
        "name": "Thesun.co.uk"
    },
    "author": "Patrick gysin",
    "title": "Coronavirus: Foreign Office staff tricked Chinese officials so Brit could flee Wuhan with newborn son - The Sun",
    "description": "",
    "url": "http://www.thesun.co.uk/news/10885870/foreign-office-brit-dad-flee-wuhan/",
    "urlToImage": "https://www.thesun.co.uk/wp-content/uploads/2020/02/dk-comp-coronavirus-plane-v4.jpg?strip=all&quality=100&w=1200&h=800&crop=1",
    "publishedAt": "2020-02-04T02:24:00Z",
    "content": "A BRITISH dad says quick-thinking Foreign Office staff tricked Chinese officials so he could escape from coronavirus-ravaged Wuhan with his wife and newborn son.\r\nMichael Martin feared the tot would not be allowed to board last weeks rescue flight as he has C… [+3355 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580783040000
}, {
    "source": {
        "id": "bbc-news",
        "name": "BBC News"
    },
    "author": "https://www.facebook.com/bbcnews",
    "title": "Keeping rats out of kitchens and bedbugs out of hotels - BBC News",
    "description": "Mouse traps and poison are being replaced by internet connected traps and thermal imaging.",
    "url": "https://www.bbc.co.uk/news/business-51019178",
    "urlToImage": "https://ichef.bbci.co.uk/news/1024/branded_news/F7AD/production/_110750436_rat.sewere.g.jpg",
    "publishedAt": "2020-02-04T02:21:56Z",
    "content": "Image copyrightGetty ImagesImage caption\r\n Getting rid of pests is big business\r\nWhen construction work disturbed a pack of rats near his commercial kitchen business in County Wicklow, Ireland, Shane Bonner knew he needed a savvier approach to pest control. \r… [+6034 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580782916000
}, {
    "source": {
        "id": null,
        "name": "Thesun.co.uk"
    },
    "author": "Nick McDermott",
    "title": "Coronavirus UK – Brit with symptoms reveals he wasn’t screened before being evacuated on UK-bound flight - The Sun",
    "description": "",
    "url": "http://www.thesun.co.uk/news/10876909/coronavirus-uk-symptoms-china-flight/",
    "urlToImage": "https://www.thesun.co.uk/wp-content/uploads/2020/02/DD-OFF_PLATFORM-WUHAN.jpg?strip=all&quality=100&w=1200&h=800&crop=1",
    "publishedAt": "2020-02-04T01:39:04Z",
    "content": "A SUSPECTED coronavirus victim was airlifted back to the UK despite having symptoms of the virus.\r\nAnthony May-Smith had a cough and a sore throat but was not screened before boarding the flight from China.\r\n Coronavirus UK: Anthony May-Smith, who was showing… [+4056 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580780344000
}, {
    "source": {
        "id": "bbc-news",
        "name": "BBC News"
    },
    "author": "https://www.facebook.com/bbcnews",
    "title": "World Cancer Day: New study into hard-to-treat cancers - BBC News",
    "description": "Academics at Queen's University Belfast are studying pancreatic and oesophageal cancers.",
    "url": "https://www.bbc.co.uk/news/uk-northern-ireland-51364005",
    "urlToImage": "https://ichef.bbci.co.uk/news/1024/branded_news/10739/production/_110758376_oesoph.jpg",
    "publishedAt": "2020-02-04T01:14:23Z",
    "content": "Image copyrightCancer Research UK\r\nTwo cancers which are among the hardest to treat and have very low survival rates are to be the focus of pioneering research at Queen's University Belfast. \r\nThe five-year survival rate for pancreatic cancer in Northern Irel… [+3572 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580778863000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Natalie Rahhal Acting Us Health Editor",
    "title": "Global rates of cancer are set to soar by 60% in the next two decades - Daily Mail",
    "description": "More than 80 percent of these predicted cases would occur in poorer countries, where as rates of cancer deaths saw saw a record-setting drop between 2016 and 2017 in the wealthy US.",
    "url": "https://www.dailymail.co.uk/health/article-7963195/Global-rates-cancer-set-soar-60-two-decades.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/00/24270266-0-image-a-22_1580774537072.jpg",
    "publishedAt": "2020-02-04T00:05:00Z",
    "content": "Driven by persistently high rates of HPV, hepatitis and smoking - especially in low-income countries - the world could see 60 percent more cancer cases in the next 20 years, the World Health Organization (WHO) warned in a new report. \r\nOver 80 percent of thes… [+3397 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580774700000
}, {
    "source": {
        "id": null,
        "name": "Thetimes.co.uk"
    },
    "author": "Peta Bee",
    "title": "The 'healthy' foods that are bad for you - The Times",
    "description": "If your focus this year has been to remove meat, sugar or carbohydrates from your diet in the hope that it will transform your health and reduce your waistline, you probably don’t want to hear that",
    "url": "https://www.thetimes.co.uk/article/the-healthy-foods-that-are-bad-for-you-8mhs52z5s",
    "urlToImage": "https://www.thetimes.co.uk/imageserver/image/%2Fmethode%2Ftimes%2Fprod%2Fweb%2Fbin%2Fab687b68-46ad-11ea-a5b7-24df8ee7a872.jpg?crop=8688%2C4887%2C0%2C453",
    "publishedAt": "2020-02-04T00:01:00Z",
    "content": "If your focus this year has been to remove meat, sugar or carbohydrates from your diet in the hope that it will transform your health and reduce your waistline, you probably dont want to hear that your efforts dont fulfil the latest requirement laid out by nu… [+493 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580774460000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Cindy Tran for Daily Mail Australia",
    "title": "Dr Preeya Alexander explains everything you need to know about coronavirus - Daily Mail",
    "description": "As the coronavirus outbreak continues to spread, an Australian doctor has offered an updated insight into the deadly virus.",
    "url": "https://www.dailymail.co.uk/femail/article-7960007/Dr-Preeya-Alexander-explains-need-know-coronavirus.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/03/23/24269300-0-image-a-40_1580772485207.jpg",
    "publishedAt": "2020-02-03T23:52:00Z",
    "content": "As the coronavirus outbreak continues to spread, an Australian doctor has offered an updated insight into the deadly virus.\r\nDr Preeya Alexander, a general practitioner from Melbourne, claimed while the coronavirus does appear to spread more easily than sever… [+6479 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580773920000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Vanessa Chalmers Health Reporter For Mailonline",
    "title": "Texting and scrolling on touchscreens has sent pedestrian injuries soaring by 800% - Daily Mail",
    "description": "A review of evidence shows 'distraction injuries' are now a significant problem. Incidents such as walking into lampposts increased by 800% in the US from 2004 to 2010, according to one study.",
    "url": "https://www.dailymail.co.uk/health/article-7961881/Texting-scrolling-touchscreens-sent-pedestrian-injuries-soaring-800.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/03/17/24258232-0-image-a-33_1580752694106.jpg",
    "publishedAt": "2020-02-03T23:30:00Z",
    "content": "Texting and scrolling on touchscreens has sent pedestrian injuries soaring by 800 per cent, scientists have warned.\r\nA review of evidence shows 'distraction injuries' are now a significant problem and are causing growing numbers of accidents. \r\nBeing engrosse… [+4431 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580772600000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Martin Scurr for the Daily Mail",
    "title": "DR MARTIN SCURR answers your health questions - Daily Mail",
    "description": "Seborrhoeic dermatitis is a skin condition in which the scalp becomes red, itchy and flaky. It's very common - occurring in around one in 25 people. It can affect any area of oily skin.",
    "url": "https://www.dailymail.co.uk/health/article-7962293/DR-MARTIN-SCURR-answers-health-questions.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/03/20/24261834-0-image-a-16_1580760207197.jpg",
    "publishedAt": "2020-02-03T22:31:00Z",
    "content": "Question: For two years I've been plagued by a very itchy, sensitive scalp even using a hairdryer is too much to bear. I also get painful flare-ups, during which it feels like someone is pulling my hair. I'm worried it's a sign of a more serious problem.\r\nJen… [+4055 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580769060000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Anne Trafton",
    "title": "Chemists unveil the structure of an influenza B protein - Phys.org",
    "description": "A team of MIT chemists has discovered the structure of a key influenza protein, a finding that could help researchers design drugs that block the protein and prevent the virus from spreading.",
    "url": "https://phys.org/news/2020-02-chemists-unveil-influenza-protein.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/2020/influenza.jpg",
    "publishedAt": "2020-02-03T21:43:51Z",
    "content": "A team of MIT chemists has discovered the structure of a key influenza protein, a finding that could help researchers design drugs that block the protein and prevent the virus from spreading.\r\nThe protein, known as BM2, is a proton channel that controls acidi… [+5391 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580766231000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Science X staff",
    "title": "Probing the genetic basis of Roundup resistance in morning glory, a noxious weed - Phys.org",
    "description": "The herbicide Roundup is the most widely used agricultural chemical in history. But over the past two decades, a growing number of weed species have evolved resistance to Roundup's active ingredient, glyphosate, reducing the product's dominance somewhat.",
    "url": "https://phys.org/news/2020-02-probing-genetic-basis-roundup-resistance.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/hires/2020/5e3892aa325b0.jpg",
    "publishedAt": "2020-02-03T21:38:03Z",
    "content": "The herbicide Roundup is the most widely used agricultural chemical in history. But over the past two decades, a growing number of weed species have evolved resistance to Roundup's active ingredient, glyphosate, reducing the product's dominance somewhat.\r\nRes… [+3170 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580765883000
}, {
    "source": {
        "id": null,
        "name": "Mirror.co.uk"
    },
    "author": "Carol Davis",
    "title": "Embarrassing Bodies doctor Christian Jessen caught malaria in a Ugandan jail - Mirror.co.uk",
    "description": "The TV doctor has opened up about one of the 'worst experiences' of his life after catching the tropical disease",
    "url": "https://www.mirror.co.uk/3am/celebrity-news/supersize-vs-superskinny-doctor-christian-21423969",
    "urlToImage": "https://i2-prod.mirror.co.uk/incoming/article21421702.ece/ALTERNATES/s1200/4_CS6099046.jpg",
    "publishedAt": "2020-02-03T21:26:00Z",
    "content": "When they first begin their studies, very few medical students know what they will specialise in. \r\nBut for Embarrassing Bodies presenter Dr Christian Jessen, his gap year travels made his choice easy he would home in on malaria.\r\nAfter all, he had only just … [+4567 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580765160000
}, {
    "source": {
        "id": null,
        "name": "Forexlive.com"
    },
    "author": null,
    "title": "Coronavirus appears to be milder-than-feared. Why that's bad news - ForexLive",
    "description": null,
    "url": "https://www.forexlive.com/news/!/coronavirus-appears-to-be-milder-than-feared-why-thats-bad-news-20200203",
    "urlToImage": null,
    "publishedAt": "2020-02-03T20:12:12Z",
    "content": null,
    "country": "gb",
    "category": "health",
    "datetime": 1580760732000
}, {
    "source": {
        "id": null,
        "name": "Mylondon.news"
    },
    "author": "Thomas Kingsley",
    "title": "Chinatown shop owner told 'don't give me coronavirus' after coughing on London Underground - MyLondon",
    "description": "Since the coronavirus outbreak Chinatown has been markedly quiet",
    "url": "https://www.mylondon.news/news/west-london-news/chinatown-shop-owner-told-dont-17681337",
    "urlToImage": "https://i2-prod.mylondon.news/news/west-london-news/article16609318.ece/ALTERNATES/s1200/2_chinatown.jpg",
    "publishedAt": "2020-02-03T19:45:00Z",
    "content": "Since the deadly coronavirus outbreak in China, fear has taken hold as the World Health Organisation last week officially declared the virus a global health emergency. \r\nIn the same week, the first two cases of coronavirus in the UK have also been confirmed s… [+3304 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580759100000
}, {
    "source": {
        "id": null,
        "name": "Leaderlive.co.uk"
    },
    "author": "Steve Craddock",
    "title": "Vets warning to dog owners as vomiting condition spreads throughout the UK - South Cotswolds Gazette",
    "description": "VETS are warning dog owners to remain calm but vigilant, as an unusually high number of cases of gastroenteritis, specifically with profuse…",
    "url": "http://www.leaderlive.co.uk/news/national/uk_today/18207112.vets-warning-dog-owners-vomiting-condition-spreads-throughout-uk/",
    "urlToImage": "https://www.thetelegraphandargus.co.uk/resources/images/10979461/",
    "publishedAt": "2020-02-03T19:07:31Z",
    "content": "VETS are warning dog owners to remain calm but vigilant, as an unusually high number of cases of gastroenteritis, specifically with profuse vomiting, is being seen in dogs across the UK.\r\nCases of the condition - which causes acute, profuse vomiting, lethargy… [+2135 chars]",
    "country": "gb",
    "category": "health",
    "datetime": 1580756851000
}, {
    "source": {
        "id": null,
        "name": "Sky.com"
    },
    "author": "Sky",
    "title": "Coronavirus v SARS: How similar are the outbreaks? - Sky News",
    "description": "",
    "url": "https://news.sky.com/story/coronavirus-v-sars-how-similar-are-the-outbreaks-11925557",
    "urlToImage": "https://e3.365dm.com/20/02/1600x900/skynews-coronavirus-china_4910770.jpg?20200203173600",
    "publishedAt": "2020-02-03T18:59:44Z",
    "content": null,
    "country": "gb",
    "category": "health",
    "datetime": 1580756384000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Kaisha Langton",
    "title": "Coronavirus symptoms: How to tell if it's NOT cold or flu - The KEY signs YOU have virus - Express",
    "description": "CORONAVIRUS is spreading rapidly with the death toll standing at 361 deaths reported in China. Express.co.uk has compiled a guide for the key symptoms of coronavirus.",
    "url": "https://www.express.co.uk/life-style/health/1237402/coronavirus-symptoms-list-cold-flu-symptoms-different-coronavirus-uk-latest",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/11/750x445/1237402.jpg",
    "publishedAt": "2020-02-03T18:18:00Z",
    "content": null,
    "country": "gb",
    "category": "health",
    "datetime": 1580753880000
}, {
    "source": {
        "id": null,
        "name": "Eurogamer.net"
    },
    "author": "Tom Phillips",
    "title": "PlayStation 4 had a good Christmas, but sales are slowing - Eurogamer.net",
    "description": null,
    "url": "https://www.eurogamer.net/articles/2020-02-04-playstation-4-had-a-good-christmas-but-sales-are-slowing",
    "urlToImage": "https://d2skuhm0vrry40.cloudfront.net/2020/articles/2020-02-04-10-16/playstation-4-had-a-good-christmas-but-sales-are-slowing-1580811355407.jpg/EG11/resize/1200x-1/playstation-4-had-a-good-christmas-but-sales-are-slowing-1580811355407.jpg",
    "publishedAt": "2020-02-04T10:18:14Z",
    "content": "Sony's Christmas sales figures are in and they're good - but they're down noticeably on those from previous years. \r\nPlayStation shifted 6.1m PS4 consoles over the final three months of 2019, down from 8.1m over the same period in 2018.\r\nAll of that puts Play… [+972 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580811494000
}, {
    "source": {
        "id": "the-verge",
        "name": "The Verge"
    },
    "author": "Tom Warren",
    "title": "Google admits it sent private videos in Google Photos to strangers - The Verge",
    "description": "Google has revealed it accidentally sent some private videos stored in Google Photos to strangers. The mishap happened for five days last year, and has since been fixed.",
    "url": "https://www.theverge.com/2020/2/4/21122044/google-photos-privacy-breach-takeout-data-video-strangers",
    "urlToImage": "https://cdn.vox-cdn.com/thumbor/x5bPoUvbJhKWBIxX7LV2j_Bpi_8=/0x146:2040x1214/fit-in/1200x630/cdn.vox-cdn.com/uploads/chorus_asset/file/19287010/acastro_191014_1777_google_pixel_0005.0.jpg",
    "publishedAt": "2020-02-04T09:37:30Z",
    "content": "The privacy breach affected a small number of Google Photos users\r\nIllustration by Alex Castro / The Verge\r\nGoogle is alerting some users of its Google Photos service that theyve had their private videos sent to strangers by the search giant. Googles Takeout … [+1209 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580809050000
}, {
    "source": {
        "id": null,
        "name": "Pinkbike.com"
    },
    "author": null,
    "title": "back First Ride: The 2020 Specialized Turbo Levo SL Weighs Only 38 Pounds - Pinkbike.com",
    "description": "The new Levo SL uses the same lightweight motor as Specialized's Creo e-road bike.",
    "url": "https://www.pinkbike.com/news/first-ride-2020-specialized-turbo-levo-sl.html",
    "urlToImage": "https://ep1.pinkbike.org/p4pb18237249/p4pb18237249.jpg",
    "publishedAt": "2020-02-04T08:21:33Z",
    "content": "In total, there are 5 models in the Tubo Levo SL lineup. Prices start at $6,535 for the aluminum framed SL Comp model, and go all the way up to a bank-account emptying $16,525 USD for the Founder's Edition, which has a carbon frame, carbon wheels, and SRAM AX… [+5412 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580804493000
}, {
    "source": {
        "id": null,
        "name": "Pinkbike.com"
    },
    "author": null,
    "title": "back First Ride: Pivot's New 2020 Switchblade - Pinkbike.com",
    "description": "The Switchblade gets a new look and more travel for 2020.",
    "url": "https://www.pinkbike.com/news/first-ride-pivots-new-2020-switchblade.html",
    "urlToImage": "https://ep1.pinkbike.org/p4pb18242737/p4pb18242737.jpg",
    "publishedAt": "2020-02-04T08:02:56Z",
    "content": "All of the models are carbon and there are several different build kits available at the Race, Team, or Pro levels. Each level has the option of a Shimano or SRAM kit. Prices range from $5,499 USD for the Race XT build all the way up to $12,399 for the Team X… [+4709 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580803376000
}, {
    "source": {
        "id": null,
        "name": "Nintendolife.com"
    },
    "author": "Nintendo Life",
    "title": "Random: Back The Wonderful 101 Remaster On Kickstarter And Get Blocked By Hideki Kamiya - Nintendo Life",
    "description": "Are you insects listening?",
    "url": "http://www.nintendolife.com/news/2020/02/random_back_the_wonderful_101_remaster_on_kickstarter_and_get_blocked_by_hideki_kamiya",
    "urlToImage": "http://images.nintendolife.com/3e468197f04b8/1280x720.jpg",
    "publishedAt": "2020-02-04T07:30:00Z",
    "content": "He is \"really fed up with insects\"\r\nIn what's possibly a Kickstarter first, you can now pay money to get blocked. If the headline wasn't enough of an idea about what's going, we're referring to the recently launched project for the remastered version of The W… [+856 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580801400000
}, {
    "source": {
        "id": null,
        "name": "Theguardian.com"
    },
    "author": "Josh Taylor",
    "title": "Elon Musk's SpaceX clears first hurdle to Australian broadband market - The Guardian",
    "description": "Communications regulator allows Starlink satellites over Australian airspace, but Foxtel objects",
    "url": "https://www.theguardian.com/technology/2020/feb/04/elon-musks-spacex-clears-first-hurdle-to-australian-broadband-market",
    "urlToImage": "https://i.guim.co.uk/img/media/c574d47d3636d39edc14d7072e2baed4e419fa21/0_170_3000_1800/master/3000.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=28ef74a43e0e972be22016567ea309b0",
    "publishedAt": "2020-02-04T07:30:00Z",
    "content": "Elon Musks SpaceX satellite broadband service has taken its first step into the Australian market. The communications regulator has added the company to a list of satellite operators allowed over Australian airspace.\r\nBut Foxtel has raised concerns the servic… [+3446 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580801400000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "David Snelling",
    "title": "WhatsApp releases its biggest change in years but fans don't like it one bit - Express",
    "description": "WHATSAPP has finally begun pushing out a dramatic update to some lucky users but this big change to the way the chat app looks is not going down well.",
    "url": "https://www.express.co.uk/life-style/science-technology/1237314/WhatsApp-dark-mode-release-android-iPhone-update",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/59/750x445/1237314.jpg",
    "publishedAt": "2020-02-04T06:45:00Z",
    "content": "Reddit forums are full of people moaning about the dark mode with one saying “Why is Whatsapp Android's new dark mode so ugly? It is just horrible compared to all other dark modes, and it doesn't have an AMOLED dark mode option.”\r\nAgreeing, another user added… [+505 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580798700000
}, {
    "source": {
        "id": "independent",
        "name": "Independent"
    },
    "author": "Louis Chilton",
    "title": "20 years of The Sims: How EA’s ‘toilet game’ became a global mega-hit - The Independent",
    "description": "Will Wright’s unlikely triumph let people play God – and introduced a whole new audience to the world of video games, writes Louis Chilton",
    "url": "https://www.independent.co.uk/arts-entertainment/games/the-sims-video-20th-anniversary-ea-video-game-pc-a9315516.html",
    "urlToImage": "https://static.independent.co.uk/s3fs-public/thumbnails/image/2020/02/03/17/the-sims-4-1.jpg",
    "publishedAt": "2020-02-04T06:30:00Z",
    "content": "In hindsight, it seems inevitable that The Sims would be a hit. The video game franchise that gave players total dominion over the lives of their digital characters the ability to manage everything from sleeping habits to wallpaper patterns has earned EA, its… [+33069 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580797800000
}, {
    "source": {
        "id": "techradar",
        "name": "TechRadar"
    },
    "author": "Desire Athow",
    "title": "This $9 smartwatch is the cheapest phone right now and we tried it - TechRadar",
    "description": "Leehur claims the crown for now",
    "url": "https://www.techradar.com/news/this-dollar9-smartwatch-is-the-cheapest-phone-right-now-and-we-tried-it",
    "urlToImage": "https://cdn.mos.cms.futurecdn.net/mABC36phm9eY27KL5469hR-1200-80.jpg",
    "publishedAt": "2020-02-04T06:00:00Z",
    "content": "The Leehur V8 is first and foremost a smartwatch, but don’t let its rock bottom price tag fool you, as it can do a lot more than display the time.\r\nWe've been using the Leehur V8 for a while to find out what it can do and came out pleasantly surprised - altho… [+2207 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580796000000
}, {
    "source": {
        "id": null,
        "name": "Nintendolife.com"
    },
    "author": "Nintendo Life",
    "title": "Temtem Developer Lays Down The Law And Bans \"Almost 900\" Cheaters - Nintendo Life",
    "description": "But will allow players to appeal",
    "url": "http://www.nintendolife.com/news/2020/02/temtem_developer_lays_down_the_law_and_bans_almost_900_cheaters",
    "urlToImage": "http://images.nintendolife.com/b9c8f0b670798/1280x720.jpg",
    "publishedAt": "2020-02-04T06:00:00Z",
    "content": "You might have heard about the indie hit Temtem. It's a game \"inspired by\" Game Freak's long-running Pokémon RPG series and wants to be the very best creature collection MMO on the market. While it's still yet to arrive on the Switch, the title recently launc… [+2100 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580796000000
}, {
    "source": {
        "id": null,
        "name": "Gamespot.com"
    },
    "author": "Eddie Makuch",
    "title": "PS5 And Xbox Series X Don't Scare Nintendo - GameSpot",
    "description": "Nintendo says the target audiences for the next-generation consoles don't overlap with the Switch.",
    "url": "https://www.gamespot.com/articles/ps5-and-xbox-series-x-dont-scare-nintendo/1100-6473345/",
    "urlToImage": "https://gamespot1.cbsistatic.com/uploads/screen_kubrick/1179/11799911/3632033-switch77.png",
    "publishedAt": "2020-02-04T04:37:00Z",
    "content": "2020 is shaping up to be a very big and important year in gaming. Both Sony and Microsoft are releasing next-generation consoles this year, while Nintendo has confirmed that it will not release new hardware this year. The Japanese gaming giant has now comment… [+1223 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580791020000
}, {
    "source": {
        "id": null,
        "name": "Sky.com"
    },
    "author": "Sky",
    "title": "Iran, Israel and Malaysia suspected of exploiting Twitter phone number security flaw - Sky News",
    "description": "The company has declined to say how many user phone numbers had been exposed, because it could not identify all the accounts.",
    "url": "https://news.sky.com/story/iran-israel-and-malaysia-suspected-of-exploiting-twitter-phone-number-security-flaw-11925861",
    "urlToImage": "https://e3.365dm.com/20/02/1600x900/skynews-twitter-hacker_4910922.jpg?20200204025756",
    "publishedAt": "2020-02-04T04:14:32Z",
    "content": null,
    "country": "gb",
    "category": "technology",
    "datetime": 1580789672000
}, {
    "source": {
        "id": "bbc-news",
        "name": "BBC News"
    },
    "author": "https://www.facebook.com/bbcnews",
    "title": "Diversity in gaming: Industry promises to improve - BBC News",
    "description": "Women are significantly under-represented in gaming, leaving some people with \"no-one to look up to\".",
    "url": "https://www.bbc.co.uk/news/newsbeat-51364212",
    "urlToImage": "https://ichef.bbci.co.uk/news/1024/branded_news/11F90/production/_110761637_gettyimages-525593502.jpg",
    "publishedAt": "2020-02-04T02:33:28Z",
    "content": "Image copyrightGetty Images\r\nDiversity is a \"necessity\" if the gaming industry is to continue to grow, says the body that represents people who make games.\r\nAround one in 10 people working in the UK industry are from ethnically diverse backgrounds - slightly … [+3975 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580783608000
}, {
    "source": {
        "id": null,
        "name": "Pushsquare.com"
    },
    "author": "Push Square",
    "title": "PlayStation Plus PS4 Games Lineup for February 2020 Announced - Push Square",
    "description": "Three games, but no Crash Bandicoot",
    "url": "http://www.pushsquare.com/news/2020/02/playstation_plus_ps4_games_lineup_for_february_2020_announced",
    "urlToImage": "http://images.pushsquare.com/6c19089136adf/1280x720.jpg",
    "publishedAt": "2020-02-04T02:26:00Z",
    "content": "The time has come: February 2020's PS Plus games have been announced. As per usual, subscribers get access to two PlayStation 4 games, but this time there's an added bonus as PlayStation VR title Firewall Zero Hour is also included. If you don't have a headse… [+2469 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580783160000
}, {
    "source": {
        "id": null,
        "name": "Nintendolife.com"
    },
    "author": "Nintendo Life",
    "title": "Video: Nintendo's Latest Ad For Animal Crossing: New Horizons Gives Us A Look At The Title Screen - Nintendo Life",
    "description": "We'll take anything at this point",
    "url": "http://www.nintendolife.com/news/2020/02/video_nintendos_latest_ad_for_animal_crossing_new_horizons_gives_us_a_look_at_the_title_screen",
    "urlToImage": "http://images.nintendolife.com/ea132e32042d5/1280x720.jpg",
    "publishedAt": "2020-02-04T02:00:00Z",
    "content": null,
    "country": "gb",
    "category": "technology",
    "datetime": 1580781600000
}, {
    "source": {
        "id": null,
        "name": "Metro.co.uk"
    },
    "author": "GameCentral",
    "title": "Games Inbox: Is The Last Of Us Naughty Dog’s best game? - Metro.co.uk",
    "description": "The Tuesday Inbox suggests some of the best games to play for young kids, as one reader wants a way to play King’s Field on a modern format.",
    "url": "https://metro.co.uk/2020/02/04/games-inbox-last-us-part-2-adults-ps5-60fps-graphics-mario-kart-legacy-12177718/",
    "urlToImage": "https://i0.wp.com/metro.co.uk/wp-content/uploads/2018/06/tlou2_screen_ps4pro_e32018_00002_1528773869_1580778196.jpg?quality=90&strip=all&w=1200&h=630&crop=1&zoom=1&ssl=1",
    "publishedAt": "2020-02-04T01:02:00Z",
    "content": "The Last Of Us Part 2 not for kids (pic: Sony)\r\nThe Tuesday Inbox suggests some of the best games to play for young kids, as one reader wants a way to play Kings Field on a modern format.\r\nTo join in with the discussions yourself email gamecentral@ukmetro.co.… [+9570 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580778120000
}, {
    "source": {
        "id": null,
        "name": "Metro.co.uk"
    },
    "author": "GameCentral",
    "title": "Apex Legends year one review – the Fortnite killer - Metro.co.uk",
    "description": "With Repsawn’s battle royale celebrating its first anniversary, GameCentral looks back at an eventful 12 months of updates and controversies.",
    "url": "https://metro.co.uk/2020/02/04/apex-legends-year-one-review-the-fortnite-killer-12177691/",
    "urlToImage": "https://i0.wp.com/metro.co.uk/wp-content/uploads/2020/02/Screenshot_1-8624_1580777488.jpg?quality=90&strip=all&w=1200&h=630&crop=1&zoom=1&ssl=1",
    "publishedAt": "2020-02-04T01:00:00Z",
    "content": "Apex Legends its come a long way in just a year (pic: EA)\r\nWith Repsawns battle royale celebrating its first anniversary, GameCentral looks back at an eventful 12 months of updates and controversies.\r\nApex Legends had the odds stacked against it from the star… [+5738 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580778000000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Paul Revoir Media Editor For The Daily Mail",
    "title": "Generation YouTube: One in four children watch no live TV - Daily Mail",
    "description": "The research shows that 80 per cent watched some form of video-on-demand content last year, a figure that has almost doubled in five years. Three quarters of five to 15-year-olds watched live broadcast TV.",
    "url": "https://www.dailymail.co.uk/news/article-7963191/Generation-YouTube-One-four-children-watch-no-live-TV.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/00/24270338-0-image-a-43_1580774534343.jpg",
    "publishedAt": "2020-02-04T00:03:00Z",
    "content": "One in four children watch no live broadcast TV, a report from the media regulator has found.\r\nOfcom's snapshot of the viewing habits of under-16s found they preferred YouTube and Netflix to BBC and ITV channels.\r\nVideo-on-demand and subscription services eve… [+3368 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580774580000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Stacy Liberatore For Dailymail.com",
    "title": "Lonely programmers develop algorithm that chat with hundreds of matches on Tinder at once - Daily Mail",
    "description": "The charming person you are chatting with on Tinder may actually be a bot in disguise. Programmers have developed technology that can choose and talk with matches.",
    "url": "https://www.dailymail.co.uk/sciencetech/article-7962827/Lonely-programmers-develop-algorithm-chat-hundreds-matches-Tinder-once.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/03/22/24266094-0-image-a-22_1580770305872.jpg",
    "publishedAt": "2020-02-03T22:52:00Z",
    "content": "The charming person you are chatting with on Tinder may actually be a bot in disguise.\r\nA programmer developed technology that can choose and talk with matches, without the need of the human dater to get involved, Mashable reports.\r\nA data scientist created a… [+2766 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580770320000
}, {
    "source": {
        "id": null,
        "name": "Eurogamer.net"
    },
    "author": "Matt Wales",
    "title": "Switch mech shooter Daemon X Machina is heading to PC next week - Eurogamer.net",
    "description": null,
    "url": "https://www.eurogamer.net/articles/2020-02-03-switch-mech-shooter-daemon-x-machina-is-heading-to-pc-next-week",
    "urlToImage": "https://d2skuhm0vrry40.cloudfront.net/2020/articles/2020-02-03-22-22/switch-mech-shooter-daemon-x-machina-is-heading-to-pc-next-week-1580768538817.jpg/EG11/resize/1200x-1/switch-mech-shooter-daemon-x-machina-is-heading-to-pc-next-week-1580768538817.jpg",
    "publishedAt": "2020-02-03T22:34:51Z",
    "content": "PC players hankering for a spot of big stompy robot action are in luck; developer Marvelous has announced that previously Switch-exclusive mech shooter Daemon X Machina will be heading to Steam next week, on 13th February.\r\nDaemon X Machina casts players as m… [+1945 chars]",
    "country": "gb",
    "category": "technology",
    "datetime": 1580769291000
}, {
    "source": {
        "id": "talksport",
        "name": "TalkSport"
    },
    "author": "Anton Stanley",
    "title": "Premier League table: talkSPORT Super Computer predicts where every club will finish in 2019/20 campaign - talkSPORT.com",
    "description": "",
    "url": "http://talksport.com/football/664770/premier-league-table-talksport-super-computer-predicts-where-every-club-will-finish-in-2019-20-campaign-february-update/",
    "urlToImage": "https://talksport.com/wp-content/uploads/sites/5/2020/02/TALKSPORT-Chelsea-West-Ham-and-Arsenal.jpg?strip=all&quality=100&w=1200&h=800&crop=1",
    "publishedAt": "2020-02-04T10:26:02Z",
    "content": "Okay, so we know Liverpool are going to win the Premier League – it’s more than 99 per cent certain according to some statistical models.\r\nThe rest of the division, though, is absolute chaos and from second to 20th could all change radically between now and t… [+3025 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580811962000
}, {
    "source": {
        "id": "talksport",
        "name": "TalkSport"
    },
    "author": "Jake Bacon",
    "title": "How Liverpool can become even stronger by SELLING Mo Salah, according to ex-England striker - talkSPORT.com",
    "description": "",
    "url": "http://talksport.com/football/664733/liverpool-mohamed-salah-kylian-mbappe-jadon-sancho-darren-bent-selling/",
    "urlToImage": "https://talksport.com/wp-content/uploads/sites/5/2020/02/NINTCHDBPICT000559218741.jpg?strip=all&quality=100&w=1200&h=800&crop=1",
    "publishedAt": "2020-02-04T09:56:15Z",
    "content": "Liverpool boss Jurgen Klopp has been told he should consider SELLING Mohamed Salah and replacing him with Kylian Mbappe or Jadon Sancho.\r\nSalah, 27, has become a superstar at Anfield – scoring 89 goals in 137 games since joining the Reds in a £34million deal … [+2358 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580810175000
}, {
    "source": {
        "id": "google-news",
        "name": "Google News"
    },
    "author": null,
    "title": "Arsenal legend Ian Wright sends Liverpool transfer warning to Man City, Chelsea, and Man United - Football.London",
    "description": null,
    "url": "https://news.google.com/__i/rss/rd/articles/CBMiXWh0dHBzOi8vd3d3LmZvb3RiYWxsLmxvbmRvbi9jaGVsc2VhLWZjL3RyYW5zZmVyLW5ld3MvYXJzZW5hbC1sZWdlbmQtaWFuLXdyaWdodC1zZW5kcy0xNzY4NDM4MdIBYWh0dHBzOi8vd3d3LmZvb3RiYWxsLmxvbmRvbi9jaGVsc2VhLWZjL3RyYW5zZmVyLW5ld3MvYXJzZW5hbC1sZWdlbmQtaWFuLXdyaWdodC1zZW5kcy0xNzY4NDM4MS5hbXA?oc=5",
    "urlToImage": null,
    "publishedAt": "2020-02-04T09:11:00Z",
    "content": null,
    "country": "gb",
    "category": "sports",
    "datetime": 1580807460000
}, {
    "source": {
        "id": null,
        "name": "Walesonline.co.uk"
    },
    "author": "Matthew Southcombe",
    "title": "England World Cup-winner calls for Eddie Jones to be sacked 'right now' - Wales Online",
    "description": "The England head coach has come under fire after his pre-match mind games backfired spectacularly in Paris",
    "url": "https://www.walesonline.co.uk/sport/rugby/rugby-news/england-world-cup-winner-calls-17684367",
    "urlToImage": "https://i2-prod.walesonline.co.uk/incoming/article17684378.ece/ALTERNATES/s1200/0_France-v-England-Guinness-Six-Nations-Stade-de-France.jpg",
    "publishedAt": "2020-02-04T09:09:00Z",
    "content": "Eddie Jones should go and the RFU should appoint an English coach 'right now'.\r\nThat is the view of England 2003 World Cup-winner Kyran Bracken, who believes Jones should have gone after the World Cup final defeat in Japan last year.\r\nJones has come in for wi… [+2369 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580807340000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Jack Otway",
    "title": "Real Madrid star Gareth Bale’s view on Tottenham transfer emerges after Jose Mourinho plot - Express",
    "description": "Real Madrid star Gareth Bale nearly returned to Tottenham during the January transfer window.",
    "url": "https://www.express.co.uk/sport/football/1237592/Real-Madrid-Gareth-Bale-Tottenham-transfer-news",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/67/750x445/1237592.jpg",
    "publishedAt": "2020-02-04T08:51:00Z",
    "content": "Real Madrid star Gareth Bale has no interest in returning to Tottenham, according to reports. Jose Mourinho tried to bring the Wales international back to north London on transfer deadline day but, ultimately, couldn’t get a deal for the player over the line.… [+1004 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580806260000
}, {
    "source": {
        "id": null,
        "name": "Nottinghampost.com"
    },
    "author": "Jonny Bonell",
    "title": "'Perfect' - Leeds United handed boost ahead of Nottingham Forest clash - Nottinghamshire Live",
    "description": "Nottingham Forest v Leeds United preview – The Reds welcome their promotion rivals to the City Ground on Saturday evening for what looks set to be a huge Championship clash",
    "url": "https://www.nottinghampost.com/sport/football/football-news/leeds-united-augustin-nottingham-forest-3808386",
    "urlToImage": "https://i2-prod.nottinghampost.com/incoming/article3806379.ece/ALTERNATES/s1200/0_GettyImages-1202560920.jpg",
    "publishedAt": "2020-02-04T08:51:00Z",
    "content": "Leeds Uniteds marquee signing Jean-Kevin Augustin looks set to be fit for Saturdays trip to play Nottingham Forest.\r\nThere were major fears among Leeds supporters yesterday that Augustin could be set for a spell on the sidelines after featuring for the under-… [+1175 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580806260000
}, {
    "source": {
        "id": null,
        "name": "Football365.com"
    },
    "author": "Ian Watson",
    "title": "Gossip: Euro giants eye Lingard, new striker link for Man Utd - Football365.com",
    "description": "Football365 - Mino Raiola is already working his magic for Jesse Lingard, while Chelsea are looking at two PL keepers to replace Kepa...",
    "url": "https://www.football365.com/news/transfer-gossip-atletico-roma-lingard-new-striker-link-man-utd-kepa-chelsea",
    "urlToImage": "https://d2x51gyc4ptf2q.cloudfront.net/content/uploads/2019/08/20094815/Jesse-Lingard.jpg",
    "publishedAt": "2020-02-04T08:20:18Z",
    "content": "EUROPEAN GIANTS EYE LINGARDIt seems that Mino Raiola is already working his magic for Jesse Lingard. Apparently, the woefully out-of-form Manchester United attacker has a couple of Europe’s grandest clubs interested in taking him this summer.\r\nAccording to ES… [+2569 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580804418000
}, {
    "source": {
        "id": null,
        "name": "Birminghammail.co.uk"
    },
    "author": "Ben Husband",
    "title": "'I hope' - Christian Purslow discusses Villa Park refurbishment plans - Birmingham Live",
    "description": "Aston Villa news - Dean Smith's side have been able to play in front of a packed out stadium every week this season",
    "url": "https://www.birminghammail.co.uk/sport/football/football-news/aston-villa-park-refurbishment-purslow-17684003",
    "urlToImage": "https://i2-prod.birminghammail.co.uk/sport/football/football-news/article17647438.ece/ALTERNATES/s1200/0_Villa-Park.jpg",
    "publishedAt": "2020-02-04T08:02:00Z",
    "content": "Aston Villa chief executive Christian Purslow has opened up on the renovations going on behind the scenes to ensure fans 'enjoy the experience' of coming to watch Dean Smith's side.\r\n Back in June of last year, Villa's owners Wes Edens and Nassef Sawiris put … [+2343 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580803320000
}, {
    "source": {
        "id": null,
        "name": "Geordiebootboys.com"
    },
    "author": "James Rutherford",
    "title": "A chance for Christian Atsu: Predicted Newcastle lineup to face Oxford - Geordie Boot Boys - Newcastle United F.C. News",
    "description": "After back-to-back 0-0 draws, Newcastle can’t afford an FA Cup calamity away to Oxford. The Magpies couldn’t book their place in the fifth round in front of a sold out St James’ Park, so will have to head to the Kassam Stadium and hope for a result live on th…",
    "url": "https://www.geordiebootboys.com/match/a-chance-for-christian-atsu-predicted-newcastle-lineup-to-face-oxford/",
    "urlToImage": "https://www.geordiebootboys.com/static/uploads/16/2020/01/GettyImages-1191576334.jpg",
    "publishedAt": "2020-02-04T08:01:13Z",
    "content": "After back-to-back 0-0 draws, Newcastle can’t afford an FA Cup calamity away to Oxford.\r\nThe Magpies couldn’t book their place in the fifth round in front of a sold out St James’ Park, so will have to head to the Kassam Stadium and hope for a result live on t… [+2016 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580803273000
}, {
    "source": {
        "id": null,
        "name": "Manchestereveningnews.co.uk"
    },
    "author": "Charlotte Duncker, Richard Fay",
    "title": "Manchester United transfer news LIVE Odion Ighalo latest as squad number 'revealed' - Manchester Evening News",
    "description": "All the latest Man Utd transfer rumours and injury latest throughout the day.",
    "url": "https://www.manchestereveningnews.co.uk/sport/football/transfer-news/man-utd-transfer-news-live-17682936",
    "urlToImage": "https://i2-prod.manchestereveningnews.co.uk/incoming/article17683014.ece/ALTERNATES/s1200/0_Untitled-design.jpg",
    "publishedAt": "2020-02-04T07:49:29Z",
    "content": "Bournemouth boss Eddie Howe insisted there have been \"no issues\" with forward Josh King after his proposed Manchester United deadline day transfer fell through.\r\nBournemouth rejected United's advances for King as Ole Gunnar Solskjaer sought to boost his strik… [+586 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580802569000
}, {
    "source": {
        "id": null,
        "name": "Mirror.co.uk"
    },
    "author": "Rich Jones",
    "title": "Kobe Bryant helicopter crash audio released from harrowing 911 calls made by witnesses - Mirror Online",
    "description": "A series of harrowing 911 calls made to the Los Angeles Fire Department reporting the helicopter crash which killed NBA legend Kobe Bryant have been released",
    "url": "https://www.mirror.co.uk/sport/other-sports/american-sports/kobe-bryant-helicopter-crash-audio-21425137",
    "urlToImage": "https://i2-prod.mirror.co.uk/incoming/article21391161.ece/ALTERNATES/s1200/0_Basket-NBA-Bryant.jpg",
    "publishedAt": "2020-02-04T07:48:00Z",
    "content": "The Los Angeles Fire Department has released harrowing audio from multiple 911 calls from those who witnessed the tragic helicopter crash which killed NBA legend Kobe Bryant.\r\nBryant, 41, and 13-year-old daughter Gianna were amongst the nine passengers killed… [+2776 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580802480000
}, {
    "source": {
        "id": null,
        "name": "Mirror.co.uk"
    },
    "author": "Martin Domin",
    "title": "Tyson Fury shows off bulked-up physique ahead of Deontay Wilder rematch - Mirror Online",
    "description": "Fury looks set to weigh in up to a stone heavier for his second installment with Wilder than he did for the rivals' first meeting in 2018",
    "url": "https://www.mirror.co.uk/sport/boxing/tyson-fury-shows-bulked-up-21425113",
    "urlToImage": "https://i2-prod.mirror.co.uk/incoming/article21425201.ece/ALTERNATES/s1200/0_Tyson-Fury.jpg",
    "publishedAt": "2020-02-04T07:46:00Z",
    "content": "Tyson Fury looks set to weigh in at his heaviest since his comeback win over Sefer Seferi when he takes on Deontay Wilder later this month. \r\nThe former heavyweight wold champion has promised to KO his American rival after being denied victory by the judges i… [+2205 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580802360000
}, {
    "source": {
        "id": null,
        "name": "Thesun.co.uk"
    },
    "author": "SunSport Reporters",
    "title": "8am Chelsea news LIVE: Pulisic injury return date, Werner drops summer transfer hint, Kepa replacement search - The Sun",
    "description": "",
    "url": "http://www.thesun.co.uk/sport/football/10878259/chelsea-news-live-pulisic-werner-transfer-kepa-latest/",
    "urlToImage": "https://www.thesun.co.uk/wp-content/uploads/2020/02/kepa-werner.jpg?strip=all&quality=100&w=1200&h=800&crop=1",
    "publishedAt": "2020-02-04T07:41:15Z",
    "content": "BLUES LATEST\r\nFRANK LAMPARD has been given a fitness boost as Chelsea head into the winter break.\r\nChristian Pulisic could be fit to face Manchester United in two weeks' time.\r\nThe 21-year-old has been out of action since the start of January with a thigh inj… [+657 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580802075000
}, {
    "source": {
        "id": null,
        "name": "Liverpoolecho.co.uk"
    },
    "author": "Ben Turner-LE, Lottie Gibbons",
    "title": "Fallen trees and traffic chaos as wild wind batters Merseyside - Liverpool Echo",
    "description": "But there's some good news on the way",
    "url": "https://www.liverpoolecho.co.uk/news/liverpool-news/wild-wind-batters-merseyside-good-17683911",
    "urlToImage": "https://i2-prod.liverpoolecho.co.uk/incoming/article17684179.ece/ALTERNATES/s1200/0_treeTeebs.jpg",
    "publishedAt": "2020-02-04T07:38:00Z",
    "content": "Winds travelling over 52mph were recorded last night in Merseyside as the wild weather continues to batter the region. \r\nDespite it being six degrees, the current temperature feels like zero degrees following a chilly start this morning.\r\n Rose Lane in Mossle… [+1171 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580801880000
}, {
    "source": {
        "id": null,
        "name": "Yorkshirepost.co.uk"
    },
    "author": "Rhys Thomas",
    "title": "Premier League man reveals Leeds United exit was 'biggest regret', Manchester United 'will sell four players', Rangers 'failed' with Sheffield United bid: Rumours - Yorkshire Post",
    "description": "With the transfer window now closed, here are today's Premier League rumours:",
    "url": "https://www.yorkshirepost.co.uk/sport/football/leeds-united/premier-league-man-reveals-leeds-united-exit-was-biggest-regret-manchester-united-will-sell-four-players-rangers-failed-with-sheffield-united-bid-rumours-1-10236047",
    "urlToImage": "https://images-a.jpimedia.uk/imagefetch/w_620,f_auto,ar_3:2,q_auto:low,c_fill/if_h_lte_200,c_mfit,h_201/https://www.yorkshirepost.co.uk/webimage/1.10236046.1580738144!/image/image.jpg",
    "publishedAt": "2020-02-04T07:34:47Z",
    "content": "With the transfer window now closed, here are today's Premier League rumours:\r\nBurnley full-back Charlie Taylor has admitted that the controversial circumstances surrounding his transfer from Leeds United are the biggest regret of his career. (Sunday Mirror)\r… [+1077 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580801687000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Nathan Salt For Mailonline",
    "title": "Frank Lampard 'set to clash with Chelsea board over long-term future of Kepa Arrizabalaga' - Daily Mail",
    "description": "Frank Lampard is facing a battle with Chelsea's board over the future of No 1 goalkeeper Kepa Arrizabalaga after dropping the world's most expensive stopper for the trip to Leicester City.",
    "url": "https://www.dailymail.co.uk/sport/football/article-7964225/Frank-Lampard-set-clash-board-long-term-future-Kepa-Arrizabalaga.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/04/07/24282684-0-image-a-4_1580801013452.jpg",
    "publishedAt": "2020-02-04T07:33:00Z",
    "content": "Frank Lampard is facing a battle with Chelsea's board over the future of No 1 goalkeeper Kepa Arrizabalaga. \r\nThe Spaniard, who remains the world's most expensive goalkeeper following his £71.6million move to Stamford Bridge in 2018, was dropped by Lampard fo… [+2314 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580801580000
}, {
    "source": {
        "id": null,
        "name": "Manchestereveningnews.co.uk"
    },
    "author": "Dominic Booth",
    "title": "Manchester United need to target four positions for summer transfer window - Manchester Evening News",
    "description": "Bruno Fernandes and Odion Ighalo arrived at Man Utd in the January transfer window but Ole Gunnar Solskjaer needs to do more business.",
    "url": "https://www.manchestereveningnews.co.uk/sport/football/transfer-news/man-utd-summer-transfer-window-17680943",
    "urlToImage": "https://i2-prod.manchestereveningnews.co.uk/incoming/article17681825.ece/ALTERNATES/s1200/0_GettyImages-1203405685-1.jpg",
    "publishedAt": "2020-02-04T07:00:00Z",
    "content": "The transfer window might have closed, meaning a temporary reduction in the relentless speculation surrounding Manchester United, but the club ought to already be looking ahead to the summer.\r\nSigning Bruno Fernandes and loaning Odion Ighalo represented an av… [+4063 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580799600000
}, {
    "source": {
        "id": null,
        "name": "Birminghammail.co.uk"
    },
    "author": "Shane Ireland",
    "title": "‘Not prepared to even negotiate’ - Club chief takes aim over Aston Villa target - Birmingham Live",
    "description": "Aston Villa transfer news - Chelsea striker was linked with AVFC in the January window while Inter Milan wanted to sign him",
    "url": "https://www.birminghammail.co.uk/sport/football/transfer-news/olivier-giroud-inter-transfer-chelsea-17683763",
    "urlToImage": "https://i2-prod.birminghammail.co.uk/incoming/article17508453.ece/ALTERNATES/s1200/0_GettyImages-1189658295.jpg",
    "publishedAt": "2020-02-04T07:00:00Z",
    "content": "Inter Milans chief executive has accused Chelsea of not being willing to negotiate with the Serie A side over Olivier Giroud.\r\nGiroud was widely expected to leave Stamford Bridge in the January transfer window after falling down the pecking order under Frank … [+1012 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580799600000
}, {
    "source": {
        "id": null,
        "name": "Skysports.com"
    },
    "author": "Adam Smith",
    "title": "VAR: Sky Sports survey with YouGov results in full - Sky Sports",
    "description": "Football fans aren't happy with VAR in its current form, according to a YouGov survey. Here, we present the results in full...",
    "url": "https://www.skysports.com/football/news/11661/11920796/var-sky-sports-survey-with-yougov-results-in-full",
    "urlToImage": "https://e0.365dm.com/20/02/1600x900/skysports-var-graphic_4910551.jpg",
    "publishedAt": "2020-02-04T06:00:58Z",
    "content": "Football fans aren't happy with VAR in its current form, according to a YouGov poll. Here, we present the results in full...\r\nOne in 25 fans believe VAR has worked 'very well'\r\nYouGov surveyed 1,419 supporters across Great Britain to find out how the nation f… [+2067 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580796058000
}, {
    "source": {
        "id": null,
        "name": "Walesonline.co.uk"
    },
    "author": "Simon Thomas",
    "title": "The 'horrific' decision Wales had to make before Italy game - Wales Online",
    "description": "Kicking coach Neil Jenkins had to choose between world class duo Dan Biggar and Leigh Halfpenny for the Championship opener against Italy",
    "url": "https://www.walesonline.co.uk/sport/rugby/rugby-news/horrific-decision-wales-make-before-17683000",
    "urlToImage": "https://i2-prod.walesonline.co.uk/incoming/article17683759.ece/ALTERNATES/s1200/0_CDF_270120_WalesRugbyTraining36JPG.jpg",
    "publishedAt": "2020-02-04T06:00:00Z",
    "content": "Neil Jenkins admits it was horrific having to choose between Dan Biggar and Leigh Halfpenny as Wales place-kicker against Italy.\r\nIn the end, the kicking coach opted for fly-half Biggar to take on the duties in the Six Nations opener at the Principality Stadi… [+2489 chars]",
    "country": "gb",
    "category": "sports",
    "datetime": 1580796000000
}, {
    "source": {
        "id": null,
        "name": "Theguardian.com"
    },
    "author": "Graham Readfearn",
    "title": "Global heating a serious threat to the world's climate refuges, study finds - The Guardian",
    "description": "Biodiversity hotspots with millions of years of climate stability could be among the world’s hardest hit regions",
    "url": "https://www.theguardian.com/environment/2020/feb/04/global-heating-a-serious-threat-to-the-worlds-climate-refuges-study-finds",
    "urlToImage": "https://i.guim.co.uk/img/media/cd66b159f255d2c23c13ed21177ff04c4419efc5/0_78_5416_3250/master/5416.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=72902cf799bc28d3b5c17e610abad2ad",
    "publishedAt": "2020-02-04T07:43:00Z",
    "content": "Biodiversity hotspots that have given species a safe haven from changing climates for millions of years will come under threat from human-driven global heating, a new study has found.\r\nSpecies that have evolved in tropical regions such Australias wet tropics,… [+3920 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580802180000
}, {
    "source": {
        "id": null,
        "name": "Sciencealert.com"
    },
    "author": "Jacinta Bowler",
    "title": "Scientists Grab First Glimpse Deep Underneath Antarctica's Unstable Thwaites Glacier - ScienceAlert",
    "description": "Antarctica's Thwaites Glacier hasn't been doing so well. It's close to irreversibly melting, it has a huge cavity growing underneath it, and it's the poster child for everything wrong with our reliance on fossil fuels.",
    "url": "https://www.sciencealert.com/scientists-discover-what-s-underneath-the-unstable-thwaites-glacier",
    "urlToImage": "https://www.sciencealert.com/images/2020-02/processed/processed/010-thwaites-glacier_1024.jpg",
    "publishedAt": "2020-02-04T06:37:26Z",
    "content": "Antarctica's Thwaites Glacier hasn't been doing so well. It's close to irreversibly melting, it has a huge cavity growing underneath it, and it's the poster child for everything wrong with our reliance on fossil fuels.\r\nBut a robotic underwater vehicle called… [+2539 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580798246000
}, {
    "source": {
        "id": null,
        "name": "Spaceflightnow.com"
    },
    "author": null,
    "title": "Cygnus departs space station, deploys CubeSats - Spaceflight Now",
    "description": null,
    "url": "https://spaceflightnow.com/2020/02/03/cygnus-departs-space-station-deploys-cubesats/",
    "urlToImage": null,
    "publishedAt": "2020-02-04T05:46:48Z",
    "content": "Northrop Grumman’s Cygnus cargo craft departed the International Space Station Friday before raising its orbit and deploying multiple CubeSats. Credit: Oleg Skripochka/Roscosmos\r\nA Northrop Grumman Cygnus cargo craft departed the International Space Station F… [+9135 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580795208000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Sean Martin",
    "title": "NASA simulation reveals what Earth would look like if the oceans drained away - Express.co.uk",
    "description": "A NASA simulation has revealed just how the Earth would look if the oceans were to gradually drain away, with stunning results.",
    "url": "https://www.express.co.uk/news/science/1237310/nasa-simulation-earth-ocean-sea-levels-mariana-trench-climate-change-jaxa",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/151/750x445/1237310.jpg",
    "publishedAt": "2020-02-04T00:08:00Z",
    "content": null,
    "country": "gb",
    "category": "science",
    "datetime": 1580774880000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Vanessa Chalmers Health Reporter For Mailonline",
    "title": "Texting and scrolling on touchscreens has sent pedestrian injuries soaring by 800% - Daily Mail",
    "description": "A review of evidence shows 'distraction injuries' are now a significant problem. Incidents such as walking into lampposts increased by 800% in the US from 2004 to 2010, according to one study.",
    "url": "https://www.dailymail.co.uk/health/article-7961881/Texting-scrolling-touchscreens-sent-pedestrian-injuries-soaring-800.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/03/17/24258232-0-image-a-33_1580752694106.jpg",
    "publishedAt": "2020-02-03T23:30:00Z",
    "content": "Texting and scrolling on touchscreens has sent pedestrian injuries soaring by 800 per cent, scientists have warned.\r\nA review of evidence shows 'distraction injuries' are now a significant problem and are causing growing numbers of accidents. \r\nBeing engrosse… [+4431 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580772600000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Sebastian Kettley",
    "title": "London underwater MAP: Chilling climate forecast shows UK capital submerged in 50 years - Express.co.uk",
    "description": "LONDON could find itself submerged under rising tides and heavy rainfall in the next 50 years if climate change is left unopposed, terrifying forecasts have revealed.",
    "url": "https://www.express.co.uk/news/science/1237504/London-flooding-map-climate-change-forecast-UK-underwater-global-warming-seal-rise",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/151/750x445/1237504.jpg",
    "publishedAt": "2020-02-03T22:41:00Z",
    "content": null,
    "country": "gb",
    "category": "science",
    "datetime": 1580769660000
}, {
    "source": {
        "id": null,
        "name": "Livescience.com"
    },
    "author": "Doris Elin Salazar",
    "title": "'Vampire' star sparks brilliant 'super-outburst' while gorging on its neighbor - Livescience.com",
    "description": "",
    "url": "https://www.livescience.com/vampire-star-gorges-on-neighbor.html",
    "urlToImage": "https://cdn.mos.cms.futurecdn.net/sxwVn8pKRKgsNPwRSTJbPR-1200-80.jpg",
    "publishedAt": "2020-02-03T21:48:00Z",
    "content": "A \"vampire\" dwarf star is sucking the life force from its partner star, and their entanglement produced a rare superoutburst. \r\nNASA detailed this previously unknown dwarf nova, a brief eruption from dwarf stars, in a statement on Jan. 24. The system brighten… [+2763 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580766480000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Sebastian Kettley",
    "title": "Moon landing shock: Michael Collins' admission 'NASA never told me' about Apollo 11 - Express.co.uk",
    "description": "NASA'S Michael Collins may have been instrumental in the success of the 1969 Moon landing but NASA never told him Apollo 11 would be the mission to do it first, the astronaut has just revealed.",
    "url": "https://www.express.co.uk/news/science/1237447/Moon-landing-NASA-news-Michael-Collins-astronaut-Apollo-11-Neil-Armstrong-Buzz-Aldrin",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/151/750x445/1237447.jpg",
    "publishedAt": "2020-02-03T20:35:00Z",
    "content": null,
    "country": "gb",
    "category": "science",
    "datetime": 1580762100000
}, {
    "source": {
        "id": null,
        "name": "Telegraph.co.uk"
    },
    "author": "By\nSarah Knapton,",
    "title": "How speaking 'parentese' can add 40 words to your baby's vocabulary - Telegraph.co.uk",
    "description": "Babies who are spoken to in 'parentese' know 40 more words than other infants by the time they are 18-months-old, researchers have found.",
    "url": "https://www.telegraph.co.uk/science/2020/02/03/speaking-parentese-can-add-40-words-babys-vocabulary/",
    "urlToImage": "https://www.telegraph.co.uk/content/dam/news/2019/09/02/TELEMMGLPICT000182203031-xlarge_trans_NvBQzQNjv4BqplGOf-dgG3z4gg9owgQTXDVXE4-NcPVfcZy5a1cUJ04.jpeg?imwidth=1200",
    "publishedAt": "2020-02-03T20:00:00Z",
    "content": "Babies who are spoken to in 'parentese' know 40 more words than other infants by the time they are 18-months-old, researchers have found.\r\nIn most of the worlds languages, parents will change their speaking style, using exaggerated sounds and simplifying gram… [+2309 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580760000000
}, {
    "source": {
        "id": null,
        "name": "Scitechdaily.com"
    },
    "author": null,
    "title": "Unexpected Discovery by NASA’s MAVEN on Mars Helps Explain Disruptive Phenomenon on Earth - SciTechDaily",
    "description": "NASA’s MAVEN (Mars Atmosphere and Volatile EvolutioN) spacecraft has discovered “layers” and “rifts” in the electrically charged part of the upper atmosphere (the ionosphere) of Mars. The phenomenon is very common at Earth and causes unpredictable disruptions…",
    "url": "https://scitechdaily.com/unexpected-discovery-by-nasas-maven-on-mars-helps-explain-disruptive-phenomenon-on-earth/",
    "urlToImage": "https://scitechdaily.com/images/MAVEN-Spacecraft-Mars-Plasma-Layers-scaled.jpg",
    "publishedAt": "2020-02-03T17:44:20Z",
    "content": "Graphic illustrating radio signals from a remote station (bent purple line) interfering with a local station (black tower) after being reflected off a plasma layer in the ionosphere. Credit: NASA Goddard/CI lab\r\nNASA’s MAVEN (Mars Atmosphere and Volatile Evol… [+5538 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580751860000
}, {
    "source": {
        "id": null,
        "name": "Thesun.co.uk"
    },
    "author": "Harry Pettit",
    "title": "Mysterious Russian spacecraft ‘stalking’ US spy satellite – as astronomers warn ‘close approach’ to take place - The Sun",
    "description": "",
    "url": "http://www.thesun.co.uk/tech/10882203/russia-spacecraft-stalking-us-spy-satellite/",
    "urlToImage": "https://www.thesun.co.uk/wp-content/uploads/2020/02/NINTCHDBPICT000559829156.jpg?strip=all&quality=100&w=1200&h=800&crop=1",
    "publishedAt": "2020-02-03T16:57:00Z",
    "content": "A MYSTERIOUS Russian spacecraft quietly tailing a US spy satellite hundreds of miles above the Earth's surface will make its closest approach yet this week.\r\nCosmos 2542 manoeuvred so it was behind USA 245 which snaps intelligence photos of Earth for the Pent… [+6126 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580749020000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "David L. Chandler",
    "title": "New electrode design may lead to more powerful batteries - Phys.org",
    "description": "New research by engineers at MIT and elsewhere could lead to batteries that can pack more power per pound and last longer, based on the long-sought goal of using pure lithium metal as one of the battery's two electrodes, the anode.",
    "url": "https://phys.org/news/2020-02-electrode-powerful-batteries.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/hires/2019/lithium.jpg",
    "publishedAt": "2020-02-03T16:00:10Z",
    "content": "New research by engineers at MIT and elsewhere could lead to batteries that can pack more power per pound and last longer, based on the long-sought goal of using pure lithium metal as one of the battery's two electrodes, the anode.\r\nThe new electrode concept … [+7015 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580745610000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Sean Martin",
    "title": "Betelgeuse supernova: Star reaches its dimmest point yet as it could EXPLODE - Express.co.uk",
    "description": "BETELGEUSE continues to dim in the night's sky as experts warn it could be set to supernova.",
    "url": "https://www.express.co.uk/news/science/1237296/Betelgeuse-star-supernova-explosion-news-space-astronomy",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/151/750x445/1237296.jpg",
    "publishedAt": "2020-02-03T14:49:00Z",
    "content": null,
    "country": "gb",
    "category": "science",
    "datetime": 1580741340000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": "Brian McGleenon",
    "title": "Jupiter warning: ‘Earth in crosshairs’ as scientists make terrifying discovery - Express.co.uk",
    "description": "JUPITER could be a danger to life on Earth, despite its reputation as a ‘protector planet'.",
    "url": "https://www.express.co.uk/news/science/1237303/jupiter-space-news-latest-Jupiter-earth-asteroid-end-of-life-human-annihilation",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/151/750x445/1237303.jpg",
    "publishedAt": "2020-02-03T14:26:00Z",
    "content": null,
    "country": "gb",
    "category": "science",
    "datetime": 1580739960000
}, {
    "source": {
        "id": null,
        "name": "Phys.org"
    },
    "author": "Spencer Turney",
    "title": "How many stars eventually collide as black holes? The universe has a budget for that - Phys.org",
    "description": "Since the breakthrough in gravitational wave astronomy back in 2015, scientists have been able to detect more than a dozen pairs of closely located black holes—known as binary black holes—by their collisions into each other due to gravity. However, scientists…",
    "url": "https://phys.org/news/2020-02-stars-eventually-collide-black-holes.html",
    "urlToImage": "https://scx2.b-cdn.net/gfx/news/2020/howmanystars.jpg",
    "publishedAt": "2020-02-03T13:58:42Z",
    "content": "Since the breakthrough in gravitational wave astronomy back in 2015, scientists have been able to detect more than a dozen pairs of closely located black holesknown as binary black holesby their collisions into each other due to gravity. However, scientists s… [+2799 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580738322000
}, {
    "source": {
        "id": null,
        "name": "Dailymail.co.uk"
    },
    "author": "By Ian Randall For Mailonline",
    "title": "Waking up to the harsh 'beeping' of an alarm clock can make you MORE groggy during the day - Daily Mail",
    "description": "Researchers from Australia found that gentle, melodic alarms can leave you more alert in the morning while harsh beeping and klaxons make you more groggy.",
    "url": "https://www.dailymail.co.uk/sciencetech/article-7961241/Waking-harsh-beeping-alarm-clock-make-groggy-day.html",
    "urlToImage": "https://i.dailymail.co.uk/1s/2020/02/03/12/24245962-0-image-a-7_1580734778116.jpg",
    "publishedAt": "2020-02-03T13:40:00Z",
    "content": "If your morning routine is less 'up with the lark' and more 'shambolic zombie', you may benefit from switching to a less harsh wake-up call.\r\nResearchers from Australia found that gentle, melodic alarms can leave you more alert in the morning while harsh beep… [+3817 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580737200000
}, {
    "source": {
        "id": null,
        "name": "Theregister.co.uk"
    },
    "author": "Richard Speed",
    "title": "Vulture discovers talons are rubbish for building Lego's International Space Station - The Register",
    "description": "Some assembly required. Just like the real thing",
    "url": "https://www.theregister.co.uk/2020/02/03/lego_iss/",
    "urlToImage": "https://regmedia.co.uk/2020/02/03/lego_iss.jpg",
    "publishedAt": "2020-02-03T12:30:00Z",
    "content": "The Register's resident brick botherer picked up Lego's new International Space Station (ISS). But is it any good?\r\nThe ISS set has its origins in the Danish toy maker's Ideas programme, which has furnished enthusiasts with the likes of the mighty Saturn V se… [+4569 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580733000000
}, {
    "source": {
        "id": "bbc-news",
        "name": "BBC News"
    },
    "author": null,
    "title": "Mercury: How to spot the planet in the night sky in February - BBC News",
    "description": "There'll be a rare chance to see Mercury in the night sky over next couple of weeks - here's how to spot the planet closest to the sun.",
    "url": "https://www.bbc.co.uk/newsround/51354250",
    "urlToImage": "http://c.files.bbci.co.uk/E03D/production/_110750475_gettyimages-529726104.jpg",
    "publishedAt": "2020-02-03T11:48:00Z",
    "content": "Planet Mercury can hardly ever be seen in the night sky, but there'll be a rare chance to see it in the next couple of weeks.\r\nThe planet is really close to the Sun - in fact it's the nearest planet in our solar system to our star - to which means it's usuall… [+941 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580730480000
}, {
    "source": {
        "id": null,
        "name": "Mirror.co.uk"
    },
    "author": "Ryan Merrifield",
    "title": "'Mini Ice Age' warnings for next 30 years with -50C temperatures in coldest areas - Mirror Online",
    "description": "Scientist Valentina Zharkova claims the Sun's forthcoming 'hibernation' will be the worst for 400 years and has already caused -50C temperatures",
    "url": "https://www.mirror.co.uk/news/uk-news/warnings-weather-mini-ice-age-21418120",
    "urlToImage": "https://i2-prod.mirror.co.uk/incoming/article21418136.ece/ALTERNATES/s1200/0_Fitzwilliam-square-winter.jpg",
    "publishedAt": "2020-02-03T01:23:00Z",
    "content": "Cold snaps so severe they could threaten food shortages and plummeting temperatures are a very real possibility over the next 30 years, an expert claims.\r\n With the Sun entering a natural \"hibernation period\" or solar minimum in which it projects less heat at… [+3142 chars]",
    "country": "gb",
    "category": "science",
    "datetime": 1580692980000
}, {
    "source": {
        "id": null,
        "name": "Express.co.uk"
    },
    "author": null,
    "title": "End of the world: NASA’s doomsday plan for planet-destroying event exposed - Express.co.uk",
    "description": "NASA has a plan to save mankind as the end of the world becomes more than just a possibility, a scientist revealed in a sobering interview.",
    "url": "https://www.express.co.uk/news/science/1236868/end-of-the-world-nasa-doomsday-plan-asteroid-meteor-comet-earth-spt",
    "urlToImage": "https://cdn.images.express.co.uk/img/dynamic/151/750x445/1236868.jpg",
    "publishedAt": "2020-02-02T14:22:00Z",
    "content": null,
    "country": "gb",
    "category": "science",
    "datetime": 1580653320000
}

];