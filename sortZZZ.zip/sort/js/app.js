var app = angular.module('zap', []);

app.controller('MainCtrl', function($scope, $filter) {
  $scope.name = 'World';
  $scope.flag = false;
  $scope.search = {
    language: {},
    business_unit: {}
  };
  $scope.languages = [{
    count: 'gb',
    _id: 0
  }, {
    count: 'us',
    _id: 1
  }, {
    count: 'ph',
    _id: 2
  }];
  
  $scope.categor = [{
    name: 'business',
    _id: 1
  }, {
    name: 'entertainment',
    _id: 2
  }, {
    name: 'general',
    _id: 3
  }, {
    name: 'health',
    _id: 4
  }, {
    name: 'science',
    _id: 5
  },{
    name: 'sports',
    _id: 6
  },{
    name: 'technology',
    _id: 7
  }];




  $scope.array = [
    {
    "id": 910,
    "size":"small",
    "language": {
      "_id": "333",
      "name": "Persian",
      "abbreviation": "PE",
      "pet":"Lizard",
      "count":"gb"
    },
    "business_unit": {
      "_id": "2",
      "name": "business",
    }
  }, {
    "id": 909,
    "size":"medium",
    "language": {
      "_id": "456",
      "name": "English",
      "abbreviation": "EN",
      "pet":"bat",
      "count":"us"
    },
    "business_unit": {
      "_id": "3",
      "name": "entertainment"
    }
  }, {
    "id": 908,
    "size":"large",
    "language": {
      "_id": "456",
      "name": "Spanish",
      "abbreviation": "SP",
      "pet":"Fish",
      "count":"gb"
    },
    "business_unit": {
      "_id": "4",
      "name": "general"
    }
  }, {
    "id": 911,
    "size":"small",
    "language": {
      "_id": "343",
      "name": "German",
      "abbreviation": "GE",
      "pet":"Fish",
      "count":"us"
    },
    "business_unit": {
      "_id": "5",
      "name": "science"
    }
  }, {
    "id": 912,
    "language": {
      "_id": "696",
      "name": "Persian",
      "abbreviation": "RU",
      "pet":"Lizard",
      "count":"ph"
    },
    "business_unit": {
      "_id": "6",
      "name": "sports"
    }
  }, {
    "id": 913,
    "language": {
      "_id": "696",
      "name": "Persian",
      "abbreviation": "RU",
      "pet":"Lizard",
      "count":"gb"
    },
    "business_unit": {
      "_id": "7",
      "name": "technology"
    }
  }];
















  $scope.$watch("search", function(n, o) {
    var selected = [];
    for (var language in n.language) {
      if (n.language[language]) {
        selected.push(true);
      }
    }
    for (var unit in n.unit) {
      if (n.unit[unit]) {
        selected.push(true);
      }
    }
    if (selected.length) {
      $scope.search.needFilter = true;
    } else {
      $scope.search.needFilter = false;
    }
  }, true);
}).
filter('myFilter', function() {
  return function(items, search) {
    var filterItems = {
      search: search,
      result: []
    };
    
    if (!search.needFilter) {
      return items;
    }
    
    angular.forEach(items, function(value, key) {
      if (this.search.language[value.language.count] === true && this.search.business_unit[value.business_unit.name] === true) {
        this.result.push(value);
      }
    }, filterItems);
    return filterItems.result;
  };
});